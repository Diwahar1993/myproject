package net.boigroup.cardsSca;

import net.boigroup.bdd.framework.BddRunner;
import net.boigroup.bdd.framework.SequenceBddRunner;
import net.boigroup.cardsSca.steps.Environment;

import java.util.List;

import static net.boigroup.bdd.framework.ConfigLoader.config;


public class CardsScaStepsTest extends BddRunner {

	SequenceBddRunner sequenceStory = new SequenceBddRunner();
	@Override
	protected List<String> storyPaths() {
		return getFeatures();
	}

	public CardsScaStepsTest() throws Throwable{
		new Environment().initDataBackup();
		String getCutOffMeta = config().getString("bdd.SequenceMetaFilter");
		if (!getCutOffMeta.equals("")){
			System.out.println("Testing=" + config().getString("bdd.SequenceMetaFilter"));
			//super.sequenceTest();
			sequenceStory.run();
			new Environment().initDataBackup();
		}
	}

}