package net.boigroup.bdd.framework;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.StringReader;
import java.io.StringWriter;

public class XMLUtils {

    public static String getTagValue(String body, String key, int i) {
        try {
            int startPostion = body.indexOf(key + ">", i) + key.length() + 1;
            int endpos = body.indexOf("</" + key, startPostion);
            return body.substring(startPostion, endpos);
        }
        catch (Exception e) {
            LogUtil.log("exception occured "+e);
            return null;
        }

    }

    public static String getXMLBlockParticularNodeForUniqueKey(String response, String rootNode,String keyTagName,String value) {
        String responseSingleBlock="";
        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = dbf.newDocumentBuilder();
            Document dom = db.parse(new InputSource(new StringReader(response)));

            NodeList listOfNodes = dom.getElementsByTagName(rootNode);

            int length = listOfNodes.getLength();
            for (int i = 0; i < length; i++) {
                if (listOfNodes.item(i).getNodeType() == Node.ELEMENT_NODE) {
                    Element el = (Element) listOfNodes.item(i);
                    if (el.getElementsByTagName(keyTagName).item(0).getTextContent().contains(value)) {
                        responseSingleBlock= nodeToString(listOfNodes.item(i));
                    }
                }
            }
        } catch (Exception e) {
            System.out.println("exception is " + e.getMessage());
        }
        return responseSingleBlock;
    }

    private static String nodeToString(Node node) throws Exception{
        StringWriter sw = new StringWriter();

        Transformer t = TransformerFactory.newInstance().newTransformer();
        t.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
        t.setOutputProperty(OutputKeys.INDENT, "yes");
        t.transform(new DOMSource(node), new StreamResult(sw));

        return sw.toString();
    }

}
