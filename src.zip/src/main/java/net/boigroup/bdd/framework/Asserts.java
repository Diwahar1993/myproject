package net.boigroup.bdd.framework;

import com.google.common.base.Joiner;
import com.google.common.base.Throwables;
import com.google.common.collect.Lists;
import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.hamcrest.StringDescription;
import org.hamcrest.core.IsNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class Asserts {
	private static final List<AssertionError> errors = Lists.newArrayList();
	private static final boolean soft = ConfigLoader.config().getBoolean("assert.soft",false);

	private static Thread hook = null;

	private static final Logger LOG = LoggerFactory.getLogger(Asserts.class);
	private synchronized static void addError(AssertionError e){
		LOG.error("Error in test ",e);
		errors.add(e);
		if (hook == null){
			Runtime.getRuntime().addShutdownHook(new Thread(new Runnable() {				
				@Override
				public void run() {
					checkForErrors();				
				}
			}));
		}	
	}

	public static void assertThat(String reason, boolean assertion) {
		originalAssertThat(reason, assertion, null,null);
	}

	public static <T> void assertThat(String reason, T actual, Matcher<? super T> matcher) {
		originalAssertThat(reason, false, actual, matcher);
	}

	public synchronized static void checkForErrors(){
		if (! errors.isEmpty()){
			throw new AssertionError("Errors during test execution: " + Joiner.on("\n").join(errors));
		}
	}

	private static final <T> void originalAssertThat(String reason, boolean assertion, T actual,Matcher<? super T> matcher){
		try {
			if (actual == null &&  !(matcher instanceof IsNull) ){
				if (!assertion) {
					LogUtil.log(reason);
					Description description = new StringDescription();

					throw new AssertionError(reason);
				}
			} else {
				if (!matcher.matches(actual)) {
					Description description = new StringDescription();
					description.appendText(reason).appendText("\n Expected ").appendDescriptionOf(matcher).appendText("\n Actual ");
					matcher.describeMismatch(actual, description);
					LogUtil.log(reason);
					//LogUtil.log(description.toString());
					throw new AssertionError(description.toString());
				}
			}
		} catch (Throwable e){
			Throwables.propagate(e);
		}
	}
}

