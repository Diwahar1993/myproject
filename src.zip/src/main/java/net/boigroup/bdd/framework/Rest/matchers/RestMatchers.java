//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package net.boigroup.bdd.framework.Rest.matchers;

import net.boigroup.bdd.framework.Rest.Constants.HttpStatus;
import net.boigroup.bdd.framework.Rest.HttpResponse;
import org.hamcrest.Factory;
import org.hamcrest.Matcher;
import org.hamcrest.core.AnyOf;

public class RestMatchers {
    public RestMatchers() {
    }

    @Factory
    public static <T> Matcher<HttpResponse> hasResponseCode(HttpStatus statusCode) {
        return HasReturnCode.hasResponseCode(statusCode);
    }

    @Factory
    public static <T> Matcher<HttpResponse> hasStringInContent(String expected) {
        return HasStringInContent.hasStringInContent(expected);
    }

    @Factory
    public static <T> Matcher<HttpResponse> hasStringsInContent(String... expected) {
        return HasStringInContent.hasStringsInContent(expected);
    }

    public static <T> Matcher<HttpResponse> hasXmlFieldWithValue(String fieldName, String value) {
        String expected = String.format("<%s>%s</%s>", fieldName, value, fieldName);
        return hasStringInContent(expected);
    }

    public static <T> Matcher<HttpResponse> hasJsonFieldWithValue(String fieldName, String value) {
        String expected = String.format("\"%s\" : \"%a\"", fieldName, value);
        return hasStringInContent(expected);
    }

    public static <T> Matcher<HttpResponse> hasFieldWithValue(String fieldName, String value) {
        return AnyOf.anyOf(hasXmlFieldWithValue(fieldName, value), hasJsonFieldWithValue(fieldName, value));
    }
}
