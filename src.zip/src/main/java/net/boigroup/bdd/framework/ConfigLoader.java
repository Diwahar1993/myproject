package net.boigroup.bdd.framework;

import com.google.common.io.Resources;
import org.apache.commons.configuration.*;
import org.apache.commons.configuration.event.ConfigurationListener;
import org.apache.commons.configuration.event.EventSource;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.filefilter.TrueFileFilter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.net.URISyntaxException;
import java.util.Arrays;
import java.util.List;

public class ConfigLoader {

	private static CompositeConfiguration config;
	public static final String PROPS = "test_props";
	public static Configuration config(){
		return getConfig();
	}
		 

	private static Logger LOG = LoggerFactory.getLogger(ConfigLoader.class);

	private static Configuration getConfig(){
		if (config == null){
			PropertiesConfiguration props = new PropertiesConfiguration();
			try {
				File propertiesDirectory = new File(Resources.getResource(PROPS).toURI());
				List<File> files = (List<File>) FileUtils.listFiles(propertiesDirectory, TrueFileFilter.INSTANCE, TrueFileFilter.INSTANCE);

				for (File propFile : files){

					try {
						props.load(propFile);
						LOG.debug("Properties loaded from file {}", propFile);
						//logConfig(props);
					} catch (ConfigurationException e) {
						LOG.error("Error loading file {} {}",propFile, e.getMessage());		
					}

				}
			} catch (IllegalArgumentException | URISyntaxException  e) {
				LOG.error("Errorr loading configuration",e.getMessage());
			}
			
			config = new RuntimeSetterDecorator(
					Arrays.asList(
					new SystemConfiguration(),
					new EnvironmentConfiguration(),
					props
					));
			for (int i =0;i<config.getNumberOfConfigurations();i++){
				//logConfig(config.getConfiguration(i));
	
			}
		}
		
		return config;
	}
	
	/**
	private static void logConfig(Configuration c){
		for (String key : Iterators.toArray(c.getKeys().toString(),String.class)){
			LOG.debug("{} - {} : {}",c.toString().replaceAll(".*commons.configuration.", "").replaceAll("@.*", ""),key,c.getString(key)));
		}		
	} **/

	public static void addEventListener(ConfigurationListener listener){
		((EventSource)getConfig()).addConfigurationListener(listener);
	}
}
