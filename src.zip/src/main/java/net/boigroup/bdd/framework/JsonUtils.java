package net.boigroup.bdd.framework;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.google.gson.stream.JsonReader;
import jxl.Sheet;
import jxl.Workbook;
import net.boigroup.bdd.framework.Rest.HttpResponse;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import java.io.*;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import static net.boigroup.bdd.framework.Asserts.assertThat;
import static org.hamcrest.CoreMatchers.is;

public final class JsonUtils {
    private static final Gson gson = new Gson();

    public  JsonUtils(){}

    public static void isJSONValid(String jsonInString) {
        try {
            gson.fromJson(jsonInString, Object.class);
        } catch(com.google.gson.JsonSyntaxException ex) {
            assertThat("Not a Valid Json!",false );
        }
    }

    public static String getJsonValue1(String json, String key) {
        String[] keyArr = key.split("/");

        ObjectMapper mapper = new ObjectMapper();
        LinkedHashMap<String, Object> baselist = null;
        try {
            baselist = mapper.readValue(json, LinkedHashMap.class);
        } catch (IOException e) {
            e.printStackTrace();
        }
        //Now parse value from List
        String value = null;
        for(int i=0;i<keyArr.length;i++) {
            if (i + 1 == keyArr.length) {
                value = (String) baselist.get(keyArr[i]);
            } else {
                baselist = (LinkedHashMap<String, Object>) baselist.get(keyArr[i]);
            }
        }
        return value;
    }

    public static String getJsonValue(String json, String key) {
        JSONObject jsonObject = JSONObject.fromObject(json);
        json =jsonObject.toString();
        String[] keyArr = key.split("/");

        ObjectMapper mapper = new ObjectMapper();
        LinkedHashMap<String, Object> baselist = null;
        try {
            baselist = mapper.readValue(json, LinkedHashMap.class);
        } catch (IOException e) {
            e.printStackTrace();
        }

        //Now parse value from List
        String value = null;
        for(int i=0;i<keyArr.length;i++) {
            if (i + 1 == keyArr.length) {
                value =  baselist.get(keyArr[i]).toString();
            } else {
                if (isKeyArray(keyArr[i])) {
                    ArrayList<LinkedHashMap<String, Object>> sublist = (ArrayList<LinkedHashMap<String, Object>>) baselist.get(keyArr[i].split("\\[")[0]);
                    baselist = sublist.get(Integer.parseInt(keyArr[i].substring(keyArr[i].indexOf("[")+1,keyArr[i].indexOf("]"))));
                } else {
                    baselist = (LinkedHashMap<String, Object>) baselist.get(keyArr[i]);
                }
            }
        }

        return value;
    }

    private static String getArrayKey(String s) {
        return s.substring(s.indexOf("[")+1,s.indexOf("]"));
    }

    private static boolean isKeyArray(String s) {
        if (s.contains("[")&& s.contains("]"))
            return true;
        else
            return false;
    }

    public static void verifyJsonValue(String response,String expectedvalue,String test) {

        LogUtil.log("Expected Value for " + test + " is : " + expectedvalue);
        LogUtil.log("Actual Value for " + test + " is : " + getJsonValue(response, test));
        assertThat("Value Mistmatched!", getJsonValue(response, test), is(expectedvalue));
    }

    public static void matchJsonResponse(HttpResponse Muleresponse, HttpResponse response,String key, List<String> mapping) {
        if (getJsonArrayListValue(Muleresponse, key).equals(getJsonArrayListValue(response, key))) {
            int validateCount=0;
            if(mapping.get(0).contains("[]")) {
                int i = Integer.parseInt(getJsonArrayListValue(Muleresponse, key));
            }else{

            }
        } else {
            LogUtil.log("Expected JSON Size: " + getJsonArrayListValue(response, key));
            LogUtil.log("Actual JSON Size: " + getJsonArrayListValue(Muleresponse, key));
            assertThat("JSON Response Not Matched", false);
        }
    }

    public static String readJSONTextFile(String folderName,String scenario,String excelFileName,String textFileName){

        // String str = null;
        String basedir = System.getProperty("user.dir").replace("\\target\\classes", "");
        Workbook tcWorkBook;
        String sSheet_Path = basedir + "\\src\\main\\resources\\"+folderName+"\\"+excelFileName+"";
        String lines = "";
        String key_Name = "";
        String fileName = textFileName;

        try {
            File file1 = new File(sSheet_Path);
            tcWorkBook = Workbook.getWorkbook(file1);
            Sheet tcSheet = tcWorkBook.getSheet("DATA");

            /* Reading the excel to get data */
            for (int row = 1; row < tcSheet.getRows(); row++) {

                key_Name = tcSheet.getCell(0,row ).getContents();
                if (scenario.equalsIgnoreCase(key_Name)) {
                    lines = getContentOfTextFile(folderName,textFileName);
                    /* Inserting data in JSON payload */
                    for (int col = 1; col < tcSheet.getColumns(); col++) {
                        String colHeader = tcSheet.getCell(col, 0).getContents();
                        String colHeaderVal = "$-{" + colHeader + "}";
                        String colValue = tcSheet.getCell(col, row).getContents();
                        lines = lines.replace(colHeaderVal, colValue);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return lines;
    }

    public static String getContentOfTextFile (String folderPath,String textFileName)
    {
        String line;
        String lines = "";

        String basedir = System.getProperty("user.dir").replace("\\target\\classes", "");
        String filepath = basedir + "\\src\\main\\resources\\"+folderPath+ "\\" + textFileName;
        try {
            File file = new File(filepath);
            BufferedReader reader = new BufferedReader(new FileReader(file.toString()));

            while ((line = reader.readLine()) != null) {
                lines = lines + line;
            }
            reader.close();
        }catch (Exception e){

        }
        return lines;
    }


    public static String getJsonArrayListValue(HttpResponse muleresponse, String key) {
        JSONObject jsonObject = JSONObject.fromObject(muleresponse.getBody());
        String json =jsonObject.toString();
        String[] keyArr = key.split("/");

        ObjectMapper mapper = new ObjectMapper();
        LinkedHashMap<String, Object> baselist = null;
        try {
            baselist = mapper.readValue(json, LinkedHashMap.class);
        } catch (IOException e) {
            e.printStackTrace();
        }

        //Now parse value from List
        String value = null;
        for(int i=0;i<keyArr.length;i++) {
            if (isKeyArray(keyArr[i])) {
                ArrayList<LinkedHashMap<String, Object>> sublist = (ArrayList<LinkedHashMap<String, Object>>) baselist.get(keyArr[i].split("\\[")[0]);
                value = String.valueOf(sublist.size());
            } else {
                baselist = (LinkedHashMap<String, Object>) baselist.get(keyArr[i]);
            }
        }

        return value;
    }

    public String readTextFileFromPath(String folderName,String textFileName){
        String textContent = "";
        String basedir = System.getProperty("user.dir").replace("\\target\\classes", "");
        String filepath = basedir + "\\src\\main\\resources\\payload\\"+folderName+"\\" + textFileName;
        try {
            File file = new File(filepath);
            BufferedReader reader = new BufferedReader(new FileReader(file.toString()));
            String line;

            while ((line = reader.readLine()) != null) {
                textContent = textContent + line;
            }

            reader.close();
        }catch (Exception e){

        }
        return textContent;
    }



    public static String getValueForKeyTagWhenSearcheTagMatched(String json,String rootTag,String matchTag,String matchValu,String key) {
        String jsonToString="";

        JSONObject fullJsonPayload = JSONObject.fromObject(json);
        JSONArray jsonArrayList = fullJsonPayload.getJSONArray(rootTag);

        //Matching the matchTag and matchValue
        for (int i = 0; i < jsonArrayList.size(); ++i) {
            JSONObject rec = jsonArrayList.getJSONObject(i);
            jsonToString=rec.toString();

            if(jsonToString.contains("\""+matchTag+"\":\""+matchValu+"\"")){
                // System.out.println("jsonToString is- "+jsonToString);
                break;
            }

        }

        String[] keyArr = key.split("/");

        ObjectMapper mapper = new ObjectMapper();
        LinkedHashMap<String, Object> baselist = null;
        try {
            baselist = mapper.readValue(jsonToString, LinkedHashMap.class);
        } catch (IOException e) {
            e.printStackTrace();
        }

        //Now parse value from List
        String returnValue = null;
        for(int i=0;i<keyArr.length;i++) {
            if (i + 1 == keyArr.length) {
                returnValue =  baselist.get(keyArr[i]).toString();
            } else {
                if (isKeyArray(keyArr[i])) {
                    ArrayList<LinkedHashMap<String, Object>> sublist = (ArrayList<LinkedHashMap<String, Object>>) baselist.get(keyArr[i].split("\\[")[0]);
                    baselist = sublist.get(Integer.parseInt(keyArr[i].substring(keyArr[i].indexOf("[")+1,keyArr[i].indexOf("]"))));
                } else {
                    baselist = (LinkedHashMap<String, Object>) baselist.get(keyArr[i]);
                }
            }
        }

        //System.out.println("returnValue is- "+returnValue);
        return returnValue;
    }

    public static void verifyJsonValueUpdated(String response,String rootTag,String  matchTag,String matchValu,String key,String expectedvalue) {

        LogUtil.log("Expected Value for " + key + " is : " + expectedvalue);
        LogUtil.log("Actual Value for " + key + " is : " + getValueForKeyTagWhenSearcheTagMatched(response,rootTag, matchTag, matchValu, key));
        assertThat("Value Mistmatched!", getValueForKeyTagWhenSearcheTagMatched(response,rootTag, matchTag, matchValu, key), is(expectedvalue));
    }

    public static String getJsonArrayValues(String jsonString, String key, int index) {
        JSONObject jsonObject = JSONObject.fromObject(jsonString);
        JSONArray jsonArray = jsonObject.getJSONArray(key);
        String ArrayValue = jsonArray.getString(index);
        return ArrayValue;
    }
    //****************************JSON Formatter***********************************************//

    public static  String jsonFormat(String jsonstring) {
        String jstring = jsonstring.trim();
        JsonReader reader = new JsonReader(new StringReader(jstring));
        reader.setLenient(true);
        JsonParser jsonParser = new JsonParser();
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        JsonElement element = jsonParser.parse(reader);
        jstring =gson.toJson(element);
        return jstring;
    }
}

