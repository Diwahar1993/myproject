package net.boigroup.bdd.framework.Rest;

import net.boigroup.bdd.framework.Rest.impl.HttpTool;
import net.boigroup.bdd.framework.Rest.impl.HttpToolImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.URI;

public final class HttpToolBuilder {
    private int defaultTimeout = 60;
    private URI restHost;
    private String KeyStorePath = null;
    private String KeyStorePassword = null;
    private static final Logger LOG = LoggerFactory.getLogger(HttpToolBuilder.class);


    HttpToolBuilder(URI restHost, String KeyStorePath, String KeyStorePassword) {
        this.restHost = restHost;
        this.KeyStorePassword = KeyStorePassword;
        this.KeyStorePath = KeyStorePath;
    }

    public HttpToolBuilder(URI uri) {
        this.restHost = uri;
    }

    public static HttpToolBuilder newBuilder(URI restHost, String KeyStorePath, String KeyStorePassword) {
        return new HttpToolBuilder(restHost, KeyStorePath, KeyStorePassword);
    }

    public static HttpToolBuilder newBuilder(URI uri) {
        return new HttpToolBuilder(uri);
    }

    public HttpToolBuilder timeout(int sec) {
        this.defaultTimeout = sec;
        return this;
    }

    public HttpTool build() {
        return new HttpToolImpl(this.restHost, this.KeyStorePath, this.KeyStorePassword, this.defaultTimeout);
    }

    public HttpTool builder() {
        return new HttpToolImpl(this.restHost, false,this.defaultTimeout);
    }
}

