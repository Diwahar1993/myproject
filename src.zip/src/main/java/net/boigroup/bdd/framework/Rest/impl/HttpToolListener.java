package net.boigroup.bdd.framework.Rest.impl;

public interface HttpToolListener {
    void onRequest(RequestEvent var1);
}