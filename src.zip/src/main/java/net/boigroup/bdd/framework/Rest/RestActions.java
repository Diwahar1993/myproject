package net.boigroup.bdd.framework.Rest;

import net.boigroup.bdd.framework.ConfigLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.URI;

public class RestActions {
    public static final String BASE_URI_PARAM = "rest.base.uri";
    private static Logger LOG = LoggerFactory.getLogger(RestActions.class);


    public RestActions() {
    }

    public static HttpToolBuilder newBuilder(URI baseHost,String KeystorePath,String KeyStorePass) {
        return HttpToolBuilder.newBuilder(baseHost,KeystorePath,KeyStorePass);
    }

    public static RequestBuilder onHTTPSUri(String uri,String KeystorePath,String KeyStorePass) {
        return newBuilder(URI.create(uri),KeystorePath,KeyStorePass).build().request();
    }

    public static RequestBuilder onHTTPUri(String uri) {
        return newBuilder(URI.create(uri)).builder().request();
    }

    private static HttpToolBuilder newBuilder(URI uri) {
        return HttpToolBuilder.newBuilder(uri);
    }

    public static RequestBuilder onDefaultUri() {
        return onHTTPUri(ConfigLoader.config().getString("rest.base.uri"));
    }

    public static RequestBuilder onUri(String string) {
        return onHTTPUri(string);
    }
}

