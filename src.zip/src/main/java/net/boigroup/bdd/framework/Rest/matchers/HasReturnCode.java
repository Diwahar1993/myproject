package net.boigroup.bdd.framework.Rest.matchers;

import net.boigroup.bdd.framework.Rest.Constants.HttpStatus;
import net.boigroup.bdd.framework.Rest.HttpResponse;
import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.hamcrest.TypeSafeMatcher;

public class HasReturnCode extends TypeSafeMatcher<HttpResponse> {
    private final HttpStatus status;

    public HasReturnCode(HttpStatus status) {
        this.status = status;
    }

    public void describeTo(Description description) {
        description.appendText(this.status.toString());
    }

    protected void describeMismatchSafely(HttpResponse item, Description mismatchDescription) {
        mismatchDescription.appendText(" was ").appendText(item.getResponseCode().toString());
    }

    protected boolean matchesSafely(HttpResponse response) {
        return response.getResponseCode().compareTo(this.status) == 0;
    }

    public static <T> Matcher<HttpResponse> hasResponseCode(HttpStatus statusCode) {
        return new HasReturnCode(statusCode);
    }
}
