package net.boigroup.bdd.framework;

import java.net.*;
import java.util.List;
import java.util.Map;
import java.io.*;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSession;

public class MutualSSlCBSAPI {
    public static class MyHostnameVerifier implements HostnameVerifier {
        public boolean verify(String hostname, SSLSession session) {
            // verification of hostname is switched off
            return true;
        }
    }
    public  String getCBSResponse(String endPoint, String HTTPMethod)  {
        String inputLine= null ;
        StringBuilder Response = new StringBuilder();
        try {
            String basedir = System.getProperty("user.dir") + "/src/main/resources";
           System.setProperty("javax.net.ssl.keyStoreType", "jks");
            System.setProperty("javax.net.ssl.trustStoreType", "jks");
            System.setProperty("javax.net.ssl.keyStore", basedir+"\\input-payload\\CBS_Certificates\\keyStore.jks");
            System.setProperty("javax.net.ssl.trustStore", basedir+"\\input-payload\\CBS_Certificates\\trustStore.jks");
            //System.setProperty("javax.net.debug", "ssl");
            System.setProperty("javax.net.ssl.keyStorePassword", "changeit");
            System.setProperty("javax.net.ssl.trustStorePassword", "changeit");

            String URL_BASE = "https://";

            String host = "CBMRMARCD102";
            String port = "9082";
            URL url = null;

            url = new URL(URL_BASE + host + ':' + port + "/" + endPoint);
            System.out.println("Request URL :" + url);
            // open HTTPS connection
            HttpsURLConnection connection = null;
            connection = (HttpsURLConnection) url.openConnection();
            ((HttpsURLConnection) connection).setHostnameVerifier(new MyHostnameVerifier());
            connection.setRequestMethod(HTTPMethod);
            connection.setRequestProperty("Content-Type", "application/json");
            // execute HTTPS request
            int returnCode = connection.getResponseCode();
            InputStream connectionIn = null;
            if (returnCode == 200)
                connectionIn = connection.getInputStream();
            else
                connectionIn = connection.getErrorStream();
            // print resulting stream
            BufferedReader buffer = new BufferedReader(new InputStreamReader(connectionIn));

            //System.out.println("Request URL :"+ url );
            System.out.println("Response Code :" + returnCode);
            Map<String, List<String>> headers = connection.getHeaderFields();
            System.out.println("Response Headers :" + headers);
            System.out.println("Response :");
            while ((inputLine = buffer.readLine()) != null) {
                System.out.println(inputLine);
                Response.append(inputLine);
            }
            buffer.close();
        }catch (Exception e){
            System.out.println(e);
        }return Response.toString();
    }
    public  String  getCBSResponsePost(String endPoint, String HTTPMethod,String jsonFile)  {
        String inputLine= null ;
        StringBuilder Response = new StringBuilder();

        try {
            String basedir = System.getProperty("user.dir") + "/src/main/resources";
            System.setProperty("javax.net.ssl.keyStoreType", "jks");
            System.setProperty("javax.net.ssl.trustStoreType", "jks");
            System.setProperty("javax.net.ssl.keyStore", basedir+"\\input-payload\\CBS_Certificates\\keyStore.jks");
            System.setProperty("javax.net.ssl.trustStore", basedir+"\\input-payload\\CBS_Certificates\\trustStore.jks");
            //System.setProperty("javax.net.debug", "ssl");
            System.setProperty("javax.net.ssl.keyStorePassword", "changeit");
            System.setProperty("javax.net.ssl.trustStorePassword", "changeit");

            String URL_BASE = "https://";

            String host = "CBMRMARCD102";
            String port = "9082";
            final String HTTP_MODE_POST = "POST";
            // command

            URL url = null;

            url = new URL(URL_BASE + host + ':' + port + "/" + endPoint);
            System.out.println("Request URL :" + url);
            // open HTTPS connection
            HttpsURLConnection connection = null;
            connection = (HttpsURLConnection) url.openConnection();
            ((HttpsURLConnection) connection).setHostnameVerifier(new MyHostnameVerifier());
            connection.setRequestMethod(HTTPMethod);
            connection.setRequestProperty("Content-Type", "application/json");
            if (HTTPMethod.equals(HTTP_MODE_POST)) {
                //connection.setRequestProperty("Content-Type", "application/json");
                // insert json file
                if (jsonFile != null) {
                    connection.setDoOutput(true);
                    OutputStream out = connection.getOutputStream();
                    FileInputStream fileIn = new FileInputStream(basedir+jsonFile);
                    byte[] buffer = new byte[1024];
                    int nbRead;
                    do {
                        nbRead = fileIn.read(buffer);
                        if (nbRead > 0) {
                            out.write(buffer, 0, nbRead);
                        }
                    } while (nbRead >= 0);
                    System.out.println("Request Body : ");
                    System.out.println(out.toString());
                    out.close();
                }
            }
            // execute HTTPS request
            int returnCode = connection.getResponseCode();
            InputStream connectionIn = null;
            if (returnCode == 200)
                connectionIn = connection.getInputStream();
            else
                connectionIn = connection.getErrorStream();
            // print resulting stream
            BufferedReader buffer = new BufferedReader(new InputStreamReader(connectionIn));
            //System.out.println("Request URL :"+ url );
            System.out.println("Response Code :" + returnCode);
            Map<String, List<String>> headers = connection.getHeaderFields();
            System.out.println("Response Headers :" + headers);
            System.out.println("Response :");
            while ((inputLine = buffer.readLine()) != null) {
                System.out.println(inputLine);
          Response.append(inputLine);
            }buffer.close();
        }catch (Exception e){
            System.out.println(e);
        }
        return Response.toString();
    }
}
