package net.boigroup.bdd.framework.Rest.matchers;

import com.google.common.collect.Lists;
import net.boigroup.bdd.framework.Rest.HttpResponse;
import org.hamcrest.Description;
import org.hamcrest.Factory;
import org.hamcrest.Matcher;
import org.hamcrest.TypeSafeMatcher;
import org.hamcrest.core.AllOf;

import java.util.List;

public class HasStringInContent extends TypeSafeMatcher<HttpResponse> {
    private final String expected;

    public HasStringInContent(String expected) {
        this.expected = expected;
    }

    public void describeTo(Description description) {
        description.appendText(this.expected);
    }

    protected void describeMismatchSafely(HttpResponse item, Description mismatchDescription) {
        mismatchDescription.appendText(" was not in ").appendText(item.getBody());
    }

    protected boolean matchesSafely(HttpResponse item) {
        return item.getBody().contains(this.expected);
    }

    @Factory
    public static <T> Matcher<HttpResponse> hasStringInContent(String expected) {
        return new HasStringInContent(expected);
    }

    @Factory
    public static <T> Matcher<HttpResponse> hasStringsInContent(String... expected) {
        List<Matcher<? super HttpResponse>> allStrings = Lists.newArrayList();
        String[] arr$ = expected;
        int len$ = expected.length;

        for(int i$ = 0; i$ < len$; ++i$) {
            String part = arr$[i$];
            allStrings.add(hasStringInContent(part));
        }

        return AllOf.allOf(allStrings);
    }
}
