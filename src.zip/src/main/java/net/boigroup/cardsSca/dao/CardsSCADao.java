package net.boigroup.cardsSca.dao;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Map;

import static net.boigroup.bdd.framework.Asserts.assertThat;

public class CardsSCADao {
	DatabaseDao instance = new DatabaseDao();
	private static final Logger LOG = LoggerFactory.getLogger(CardsSCADao.class);

	String fetch365UserInfo_CIS_USER="SELECT DISTINCT CAP.CHANNEL_ID, USERDETAILS.CIS_CLIENT_NO, USERDETAILS.DATE_OF_BIRTH, USERDETAILS.LOGON_PHONE_NO, USERDETAILS.MOBILE_REG_STATUS, USERDETAILS.ESTMT_REG_STATUS, USERDETAILS.LAST_PAYEE_ADDED, USERDETAILS.LOGON_LAST FROM CHANNEL_ACCOUNT_PROFILE CAP, CHANNEL_USER USERDETAILS WHERE USERDETAILS.CHANNEL_ID = CAP.CHANNEL_ID AND USERDETAILS.CIS_CLIENT_NO='{CIS_USERID}'";
    String VerifyCIS_USER="select * from CHANNEL_USER where CIS_CLIENT_NO='{CIS_USERID}'";
    String fetch365UserInfo_Plappl_USER="SELECT CAP.CHANNEL_ID,USERDETAILS.CIS_CLIENT_NO,USERDETAILS.DATE_OF_BIRTH,USERDETAILS.LOGON_PHONE_NO,USERDETAILS.MOBILE_REG_STATUS,USERDETAILS.ESTMT_REG_STATUS,USERDETAILS.LAST_PAYEE_ADDED,USERDETAILS.LOGON_LAST FROM CHANNEL_USER USERDETAILS JOIN CHANNEL_ACCOUNT_PROFILE CAP On USERDETAILS.CHANNEL_ID = CAP.CHANNEL_ID WHERE CAP.PLATFORM_ID = '{platformId}' AND CAP.APPL_ID = '{applId}' AND USERDETAILS.DATE_OF_BIRTH = '{dob}'";
    String fetch365UserInfo_CreditCardNumber="SELECT CAP.CHANNEL_ID, USERDETAILS.CIS_CLIENT_NO, USERDETAILS.DATE_OF_BIRTH, USERDETAILS.LOGON_PHONE_NO, USERDETAILS.MOBILE_REG_STATUS, USERDETAILS.ESTMT_REG_STATUS, USERDETAILS.LAST_PAYEE_ADDED, USERDETAILS.LOGON_LAST FROM CHANNEL_ACCOUNT_PROFILE CAP, CHANNEL_USER USERDETAILS WHERE USERDETAILS.CHANNEL_ID = CAP.CHANNEL_ID AND CAP.CREDIT_CARD_NUMBER = '{CREDIT_CARD_NUMBER}' AND LOGON_LAST = (SELECT MAX(LOGON_LAST) FROM CHANNEL_ACCOUNT_PROFILE CAP, CHANNEL_USER USERDETAILS WHERE USERDETAILS.CHANNEL_ID = CAP.CHANNEL_ID AND CAP.CREDIT_CARD_NUMBER ='{CREDIT_CARD_NUMBER}')";
    String fetchDebitCardNo = "SELECT CIS_CLIENT_NO,CARD_PAN_HASH,CARD_JURISDICTION,CARD_ISSUE_DATE,NSC,ACCOUNT_NUMBER,FD_CUST_ID,FD_ACCOUNT_ID FROM CHANNEL_DEBIT_CARD_PROFILE where CARD_PAN_HASH='{hashedDebitNo}'";
    String fetchCurrencyList = "SELECT DISTINCT CURRENCY_NAME,CURRENCY_CODE,FRACTION_DIGITS FROM TBL_CURRENCY_CODES ORDER BY {QueryParam}";

	public List<Map<String, Object>> getDebitCardNo(String hashedDebitNo) {
		return instance.runQueryB365Accounts(fetchDebitCardNo.replace("{hashedDebitNo}", hashedDebitNo));

	}
	public List<Map<String, Object>> get365UserinfoByCIS_USER(String CIS_USERID) {
		return instance.runQueryB365Accounts(fetch365UserInfo_CIS_USER.replace("{CIS_USERID}", CIS_USERID));
	}

	public List<Map<String, Object>> VerifyCIS_USER(String cisUserId) {
		return instance.runQueryB365Accounts(VerifyCIS_USER.replace("{CIS_USERID}", cisUserId));
	}

	public List<Map<String, Object>> getValidCurrency(String queryparam) {

		if(queryparam.equals("CURRENCY_CODE ASC")){
			queryparam="CASE WHEN CURRENCY_CODE = 'EUR' THEN 1 WHEN CURRENCY_CODE = 'GBP' THEN 2 WHEN CURRENCY_CODE = 'USD' THEN 3 WHEN CURRENCY_CODE = 'AUD' THEN 4 WHEN CURRENCY_CODE = 'CAD' THEN 5 ELSE 6 END, CURRENCY_CODE ASC";
		}else if (queryparam.equals("CURRENCY_CODE DESC")){
			queryparam="CASE WHEN CURRENCY_CODE = 'EUR' THEN 1 WHEN CURRENCY_CODE = 'GBP' THEN 2 WHEN CURRENCY_CODE = 'USD' THEN 3 WHEN CURRENCY_CODE = 'AUD' THEN 4 WHEN CURRENCY_CODE = 'CAD' THEN 5 ELSE 6 END, CURRENCY_CODE DESC";
		}else if (queryparam.equals("CURRENCY_NAME ASC,CURRENCY_CODE ASC")|(queryparam.equals("CURRENCY_CODE ASC,CURRENCY_NAME ASC"))){
			queryparam="CASE WHEN CURRENCY_CODE = 'EUR' THEN 1 WHEN CURRENCY_CODE = 'GBP' THEN 2 WHEN CURRENCY_CODE = 'USD' THEN 3 WHEN CURRENCY_CODE = 'AUD' THEN 4 WHEN CURRENCY_CODE = 'CAD' THEN 5 ELSE 6 END, CURRENCY_CODE ASC,CURRENCY_NAME ASC";
		}else if (queryparam.equals("CURRENCY_NAME DESC,CURRENCY_CODE DESC")|(queryparam.equals("CURRENCY_CODE DESC,CURRENCY_NAME DESC"))){
			queryparam="CASE WHEN CURRENCY_CODE = 'EUR' THEN 1 WHEN CURRENCY_CODE = 'GBP' THEN 2 WHEN CURRENCY_CODE = 'USD' THEN 3 WHEN CURRENCY_CODE = 'AUD' THEN 4 WHEN CURRENCY_CODE = 'CAD' THEN 5 ELSE 6 END, CURRENCY_CODE DESC,CURRENCY_NAME DESC";
		}else if (queryparam.equals("CURRENCY_NAME ASC,CURRENCY_CODE DESC")|(queryparam.equals("CURRENCY_CODE DESC,CURRENCY_NAME ASC"))){
			queryparam="CASE WHEN CURRENCY_CODE = 'EUR' THEN 1 WHEN CURRENCY_CODE = 'GBP' THEN 2 WHEN CURRENCY_CODE = 'USD' THEN 3 WHEN CURRENCY_CODE = 'AUD' THEN 4 WHEN CURRENCY_CODE = 'CAD' THEN 5 ELSE 6 END, CURRENCY_CODE DESC,CURRENCY_NAME ASC";
		}else if (queryparam.equals("CURRENCY_NAME DESC,CURRENCY_CODE ASC")|(queryparam.equals("CURRENCY_CODE ASC,CURRENCY_NAME DESC"))){
			queryparam="CASE WHEN CURRENCY_CODE = 'EUR' THEN 1 WHEN CURRENCY_CODE = 'GBP' THEN 2 WHEN CURRENCY_CODE = 'USD' THEN 3 WHEN CURRENCY_CODE = 'AUD' THEN 4 WHEN CURRENCY_CODE = 'CAD' THEN 5 ELSE 6 END, CURRENCY_CODE ASC,CURRENCY_NAME DESC";
		}
		return instance.runQueryB365Indicators(fetchCurrencyList.replace("{QueryParam}",queryparam));

	}
	public boolean verifyCisUserId(String cisUserId) {
		//Verify the presence of CIS user in CHANNEL_USER table
		boolean validator;
		List<Map<String, Object>> result = VerifyCIS_USER(cisUserId);
		if (result.size()>0){
			validator=true;
		}else
			validator=false;
		return validator;
	}

	public boolean VerifyPlapplIDandDOB(String PlapplID , String DOB) {
		//Verify the presence of PlapplID user in CHANNEL_USER table
		boolean validator;
		List<Map<String, Object>> result = get365UserinfoByPlapplIDandDOB(PlapplID , DOB);
		if (result.size()>0){
			validator=true;
		}else
			validator=false;
		return validator;
	}

	public boolean VerifyCreditcardNumber(String CreditcardNumber) {
		//Verify the presence of CreditcardNumber user in CHANNEL_USER table
		boolean validator;
		List<Map<String, Object>> result = get365UserinfoByCreditcradNumber(CreditcardNumber);
		if (result.size()>0){
			validator=true;
		}else
			validator=false;
		return validator;
	}

	public List<Map<String, Object>> get365UserinfoByPlapplIDandDOB(String plapplId , String dob) {
		String applId = plapplId.substring(4,16);
		String platformId = plapplId.substring(0,4);
		return instance.runQueryB365Accounts(fetch365UserInfo_Plappl_USER.replace("{applId}", applId).replace("{dob}", dob).replace("{platformId}", platformId));
	}

	public List<Map<String, Object>> get365UserinfoByCreditcradNumber(String CreditcradNumber) {
		return instance.runQueryB365Accounts(fetch365UserInfo_CreditCardNumber.replace("{CREDIT_CARD_NUMBER}", CreditcradNumber));
	}
}
