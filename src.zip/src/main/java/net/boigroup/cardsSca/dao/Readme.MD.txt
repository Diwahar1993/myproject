** AccountDetailDao.java -  File contains SQL queries and method to run those queries related to tables for account details [table: ABT_ACCOUNT_DETAILS].


