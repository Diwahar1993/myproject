package net.boigroup.cardsSca.dao;

import net.boigroup.bdd.framework.DBUtils;
import net.boigroup.bdd.framework.LogUtil;
import net.boigroup.test.framework.db.DbActions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.beans.PropertyVetoException;
import java.sql.*;
import java.util.List;
import java.util.Map;

import static java.lang.String.format;
import static net.boigroup.bdd.framework.ConfigLoader.config;

public class DatabaseDao {
	private static final Logger LOG = LoggerFactory.getLogger(DatabaseDao.class);

	private static final String CONNECTION_STRING_TEMPLATE = "jdbc:oracle:thin:@%s:1521:%s";

	private String abtPool;

	private String backupPool;

	private String abtBackupPool;

	private String paymentPool;

	private String bolPool;

	private String b365AccountsPool;

	private String b365IndicatorsPool;

	private String backupPaymentPool;

	private String AuthenticationPool;

	String environment = config().getString("test.environment");
	String abtschema = config().getString(environment + ".abt.schema");
	String paymentschema = config().getString(environment + ".payment.schema");
	String bolSchema = config().getString(environment + ".bol.schema");

	private static DatabaseDao instance = new DatabaseDao();

	public static DatabaseDao getInstance() {
		return instance;
	}

	public DatabaseDao() {
		abtPool = connString(environment + ".abt.host", environment + ".abt.sessionId");
		backupPool = connString( "ST.backup.host", "ST.backup.sessionId");
		abtBackupPool = connString( environment + ".backup.host", environment + ".backup.sessionId");
		paymentPool = connString(environment + ".payment.host", environment + ".payment.sessionId");
		bolPool = connString(environment +".bol.host", environment +".bol.sessionId");
		b365AccountsPool = connString("b365Accounts.host", "b365Accounts.sessionId");
		b365IndicatorsPool = connString("b365Indicators.host", "b365Indicators.sessionId");
		backupPaymentPool=connString(environment + ".backup.host", environment + ".backup.sessionId");
		AuthenticationPool=connString("autheticationConfigTable.host", "autheticationConfigTable.sessionId");
	}

	public List<Map<String, Object>> runQueryAbt(String sql) {
		return runQueryImpl(abtPool, environment + ".abt.user", environment + ".abt.pass", sql);
	}

	public List<Map<String, Object>> runQueryBackUp(String sql) {
		return runQueryImpl(backupPool,  "ST.backup.user", "ST.backup.pass", sql);
	}

	public List<Map<String, Object>> runQueryABTBackUp(String sql) {
		return runQueryImpl(abtBackupPool,  environment + ".backup.user", environment + ".backup.pass", sql);
	}

	public List<Map<String, Object>> runQueryPayment(String sql) {
		return runQueryImpl(paymentPool, environment + ".payment.user", environment + ".payment.pass", sql);
	}

	public List<Map<String, Object>> runQueryPaymentBackUp(String sql) {
		return runQueryImpl(backupPaymentPool,  environment + ".backup.user", environment + ".backup.pass", sql);
	}

	public List<Map<String, Object>> runQueryBol(String sql) {
		return runQueryImpl(bolPool, environment+".bol.user", environment+".bol.pass", sql);
	}

	public List<Map<String, Object>> runQueryB365Accounts(String sql) {
		return runQueryImpl(b365AccountsPool, "b365Accounts.user", "b365Accounts.pass", sql);
	}

	public List<Map<String, Object>> runQueryB365Indicators(String sql) {
		return runQueryImpl(b365IndicatorsPool, "b365Indicators.user", "b365Indicators.pass", sql);
	}

	public void runUpdateQueryAbt(String sql) {
		runUpdateQueryImpl(abtPool, environment + ".abt.user", environment + ".abt.pass", sql);
	}

	public void runUpdateQueryPayment(String sql) {
		runUpdateQueryImpl(paymentPool, environment + ".payment.user", environment + ".payment.pass", sql);
	}

	public void runUpdateQueryBol(String sql) {
		runUpdateQueryImpl(bolPool, environment +".bol.user", environment +".bol.pass", sql);
	}

	public void runUpdateQueryB365Accounts(String sql) {
		runUpdateQueryImpl(b365AccountsPool, "b365Accounts.user", "b365Accounts.pass", sql);
	}

	public void runUpdateQueryB365Indicators(String sql) {
		runUpdateQueryImpl(b365IndicatorsPool, "b365Indicators.user", "b365Indicators.pass", sql);
	}

	//authentication
	public List<Map<String, Object>> runQuerySCAConfiguration(String sql) {
		return runQueryImpl(AuthenticationPool,"autheticationConfigTable.user", "autheticationConfigTable.pass", sql);
	}

	public List<Map<String, Object>> runQueryImpl(String dataSource, String username, String password, String sql) {
		List<Map<String, Object>> result = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection connection = null;
			connection = DriverManager.getConnection(dataSource, config().getString(username),
					config().getString(password));
			Statement stat = connection.createStatement();
			ResultSet rs = stat.executeQuery(sql);
			LogUtil.log("SQL Query : " + sql);
			result = DbActions.QueryExecutor.asMaps(rs);
			if(result.isEmpty()){
				LogUtil.logAttachment(sql,"No Results found for the Query \n");
			}else {
                if (result.size() > 1) {
                    LogUtil.logCSVAttachment(sql, DBUtils.getCSVFormat(result));
                } else {
                    LogUtil.logAttachment(sql, "\n Results : \n" + DBUtils.getDBTableReportFormatCol(result));
                }
            }
			connection.close();
		} catch (SQLException | ClassNotFoundException e) {
			LogUtil.log("Error running query: \n" + sql + "\n" + e);
		}

		return result;
	}

	public void runUpdateQueryImpl(String dataSource, String username, String password, String sql) {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection connection = null;
			connection = DriverManager.getConnection(dataSource,config().getString(username),
					config().getString(password));
			Statement stat = connection.createStatement();
			LogUtil.log("SQL Query : " + sql);
			stat.executeUpdate(sql);
			connection.close();
		} catch (SQLException | ClassNotFoundException e) {
			LogUtil.log("Error running query: \n" + sql + "\n" + e);
		}
	}

	public void runBulkUpdateQueryImpl(String dataSource, String username, String password, List<String> sql) {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection connection = null;
			connection = DriverManager.getConnection(dataSource,config().getString(username),
					config().getString(password));
			Statement statement = connection.createStatement();

			for (String query : sql) {
				statement.addBatch(query);
			}
			statement.executeBatch();
			statement.close();
			connection.close();
		} catch (SQLException | ClassNotFoundException e) {
			LogUtil.log("Error running query: \n" + sql + "\n" + e);
		}
	}
	private String connString(String host, String sessionId) {
		return format(CONNECTION_STRING_TEMPLATE, config().getString(host), config().getString(sessionId));
	}

	// just for testing purposes
	public static void main(String[] args) throws SQLException, PropertyVetoException {
		LOG.info(instance.runQueryAbt("select * from  psd_user.ATMBRANCHLOCATIONSLIVE ").toString());
		LOG.info(instance.runQueryBol("select * from TEBSEC01 where ROWNUM <= 5").toString());
		LOG.info(instance.runQueryB365Accounts("select * from channel_account_profile where ROWNUM <= 5").toString());
		LOG.info(instance.runQueryB365Indicators("select * from tbl_account where ROWNUM <= 5").toString());
	}

	public void runUpdateQueryAbtBackUp(String sql) {
		runUpdateQueryImpl(abtBackupPool, environment + ".backup.user", environment + ".backup.pass", sql);
	}

    public void runBulkUpdateQueryPayment(List<String> bulkInsertQuery) {
		runBulkUpdateQueryImpl(paymentPool, environment + ".payment.user", environment + ".payment.pass", bulkInsertQuery);
    }
}