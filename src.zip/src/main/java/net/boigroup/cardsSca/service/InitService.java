package net.boigroup.cardsSca.service;

import net.boigroup.bdd.framework.LogUtil;
import net.boigroup.cardsSca.dao.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.SimpleDateFormat;
import java.util.*;

import static net.boigroup.bdd.framework.ConfigLoader.config;

public class InitService {
	private static final Logger LOG = LoggerFactory.getLogger(InitService.class);
	DatabaseDao dao = new DatabaseDao();
	String environment = config().getString("test.environment");
	String schema = config().getString(environment + ".abt.schema");
	String paymentschema = config().getString(environment + ".payment.schema");
	
	public void initaliseDB() {
		LogUtil.log("Deleting the Transaction Table");
		//new TransactionDao().deleteAll();
		LogUtil.log("Deleting the Balance");
	//	new BalanceDao().deletBalanceAll();
		LogUtil.log("Deleting the Account details table");
	//	new AccountDetailDao().deleteAll();
		LogUtil.log("Deleting the Branch");
	//	new BalanceDao().deleteBranchAll();

		LogUtil.log("Inserting the Branch Table");
		loadBranchData();
		LogUtil.log("Inserting the Account details table");
		loadAccountData();
		LogUtil.log("Inserting the Balance Table");
		loadBalanceData();
		LogUtil.log("Inserting the Transaction Table");
		loadTransactionData();
		LogUtil.log("Deleting the Payments table");
		//new CardsSCADao().deleteAll();
		LogUtil.log("Inserting the Payments table");
		//loadPaymentsData();

		LogUtil.log("Deleting the Channel User Status");
		//new AccountDetailDao().deleteChannelUserStatus();
		LogUtil.log("Inserting the Channel User Status Table");
		//loadChannelUserStatus();
		LogUtil.log("Deleting the Channel User Auth Table");
		//new LoginAuthenticationDao().deleteChannelAuthAll();
		LogUtil.log("Inserting the Channel User Auth Table");
		//loadChannelUserAuth();

	}

	private void loadTransactionData() {
		loadShadowTransactions();
		loadPostedTransactions();
	}

	private void loadPostedTransactions() {
		String upQuery = "UPDATE " + config().getString(environment + ".backup.schema")
				+ ".ABT_POSTED_TRANSACTION_BACKUP SET POSTED_DATE=TO_TIMESTAMP('" + get1YearBeforeDate()
				+ "', 'YYYY-MM-DD HH24:MI:SS.FF') WHERE ID=48";
		try {
			dao.runUpdateQueryAbtBackUp(upQuery);
		} catch (Exception e) {
		}
		String query = "INSERT INTO " + schema + ".ABT_POSTED_TRANSACTION (ID, NSC, ACCOUNT_NUMBER, POSTED_DATE, AMOUNT, TXN_CODE, TXN_TYPE, PICN, SOURCE_CODE, SERIAL_NUMBER, EURO_AMOUNT, NARRATIVE_TXT1, EOD_BALANCE, POSTED_TIMESTAMP) SELECT ID, NSC, ACCOUNT_NUMBER, POSTED_DATE, AMOUNT, TXN_CODE, TXN_TYPE, PICN, SOURCE_CODE, SERIAL_NUMBER, EURO_AMOUNT, NARRATIVE_TXT1, EOD_BALANCE, POSTED_TIMESTAMP FROM "
				+ config().getString(environment + ".backup.schema")
				+ ".ABT_POSTED_TRANSACTION_BACKUP".replace("{env.schema}", schema);

		try {
			dao.runUpdateQueryAbt(query);
		} catch (Exception e) {
			LogUtil.log("ERROR : " + e.getMessage());
		}
	}

	private String get1YearBeforeDate() {
		Calendar cal = Calendar.getInstance();
		int date = -364;
		cal.add(Calendar.DATE, date);
		Date dateYear = cal.getTime();
		return formatDate(dateYear);
	}

	private String formatDate(Date date) {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		String format = formatter.format(date);
		return format;
	}

	private void loadShadowTransactions() {
		String query = "INSERT INTO " + schema + ".ABT_CACHED_TRANSACTION (ID, NSC, ACCOUNT_NUMBER, TXN_DATE, AMOUNT, TXN_CODE, TXN_TYPE, PICN, SOURCE_CODE, NARRATIVE_TXT1, TXN_SOURCE, CACHED_TIMESTAMP) SELECT ID, NSC, ACCOUNT_NUMBER, TXN_DATE, AMOUNT, TXN_CODE, TXN_TYPE, PICN, SOURCE_CODE, NARRATIVE_TXT1, TXN_SOURCE, CACHED_TIMESTAMP  FROM "
				+ config().getString(environment + ".backup.schema")
				+ ".ABT_CACHED_TRANSACTION_BACKUP".replace("{env.schema}", schema);
		try {
			dao.runUpdateQueryAbt(query);
		} catch (Exception e) {
			LogUtil.log("ERROR : " + e.getMessage());
		}
	}

	private void loadBalanceData() {
		String query = "INSERT INTO " + schema + ".ABT_ACCOUNT_BALANCE SELECT * FROM "
				+ config().getString(environment + ".backup.schema")
				+ ".ABT_ACCOUNT_BALANCE_BACKUP WHERE ACCOUNT_NUMBER NOT IN ('15143987','82451015')".replace("{env.schema}", schema);
		try {
			dao.runUpdateQueryAbt(query);
		} catch (Exception e) {
			LogUtil.log("ERROR : " + e.getMessage());
		}
	}

	private void loadAccountData() {
		String query = "INSERT INTO " + schema + ".ABT_ACCOUNT_DETAILS SELECT * FROM "
				+ config().getString(environment + ".backup.schema")
				+ ".ABT_ACCOUNT_DETAILS_BACKUP";
		try {
			dao.runUpdateQueryAbt(query);
		} catch (Exception e) {
			LogUtil.log("ERROR : " + e.getMessage());
		}
	}

	private void loadBranchData() {
		String query = "INSERT INTO " + schema + ".ABT_BRANCH_STATUS SELECT * FROM "
				+ config().getString(environment + ".backup.schema")
				+ ".ABT_BRANCH_STATUS_BACKUP";
		try {
			dao.runUpdateQueryAbt(query);
		} catch (Exception e) {
			LogUtil.log("ERROR : " + e.getMessage());
		}

	}

	private void loadPaymentsData() {

		String selBackUpQuery="SELECT * FROM " + config().getString(environment + ".backup.schema") + ".PAYMENT_INSTRUCTION_BACKUP";

		List<Map<String, Object>> selQueryresult = dao.runQueryPaymentBackUp(selBackUpQuery);

		List<String> bulkInsertPaymentQuery = new ArrayList<>();

		for (Map<String, Object> res:selQueryresult) {

			String query = "INSERT INTO PAYMENT_REQUEST (END_TO_END_ID, PYMT_ID, CREATE_TIMESTAMP, CHANNEL_USER_ID, PAYER_IBAN, PAYER_BIC, PAYER_NSC, PAYER_ACC_NO, PAYER_ACC_NAME, PAYER_ACC_SECOND_ID, PAYER_PARENT_NSC, PAYER_CUR, PAYER_CIS_ID, PAYER_JURISD, BENF_BIC, BENF_IBAN, BENF_NSC, BENF_PARENT_FORWARDED_NSC, BENF_ACC_NO, BENF_NAME, BENF_ACC_SECOND_ID, BENF_JUR, PYMT_CUR, PYMT_CONTXT_CODE, PYMT_AMOUNT, PYMT_INSTRUCT_ID, PYMT_DATE, PYMT_BENF_REF, PYMT_UNSTRUCTURED, PYMT_STATUS, PYMT_TRNSFR_TYPE, PYMT_PLATFORM_STATUS, PYMT_TYPE, PYMT_CATEGORY, PYMT_SUBMISSION_ID, MRCHNT_CAT_CODE, MER_CUST_ID, UPDATE_TIMESTAMP, FRD_ID, FRD_SYS_RES, SOURCE_CHANNEL, DESTINATION_CTRY) " +
					"VALUES (" + checkNull(res.get("END_TO_END_ID")) + "," + checkNull(res.get("PYMT_ID")) + "," + checkNull(res.get("CREATE_TIMESTAMP")) + "," + checkNull(res.get("CHANNEL_USER_ID")) + "," + checkNull(res.get("PAYER_IBAN")) + "," + checkNull(res.get("PAYER_BIC")) + "," + checkNull(res.get("PAYER_NSC")) + "," + checkNull(res.get("PAYER_ACC_NO"))
					+ "," + checkNull(res.get("PAYER_ACC_NAME")) + "," + checkNull(res.get("PAYER_ACC_SECOND_ID")) + "," + checkNull(res.get("PAYER_PARENT_NSC"))
					+ "," + checkNull(res.get("PAYER_CUR")) + "," + checkNull(res.get("PAYER_CIS_ID")) + "," + checkNull(res.get("PAYER_JURISD")) + "," + checkNull(res.get("BENF_BIC")) + "," + checkNull(res.get("BENF_IBAN")) + "," + checkNull(res.get("BENF_NSC")) + "," + checkNull(res.get("BENF_PARENT_FORWARDED_NSC")) + "," + checkNull(res.get("BENF_ACC_NO")) + "," + checkNull(res.get("BENF_NAME")) + "," + checkNull(res.get("BENF_ACC_SECOND_ID"))
					+ "," + checkNull(res.get("BENF_JUR")) + "," + checkNull(res.get("PYMT_CUR")) + "," + checkNull(res.get("PYMT_CONTXT_CODE")) + "," + checkNull(res.get("PYMT_AMOUNT")) + "," + checkNull(res.get("PYMT_INSTRUCT_ID")) + "," + checkNull(res.get("PYMT_DATE")) + "," + checkNull(res.get("PYMT_BENF_REF")) + "," + checkNull(res.get("PYMT_UNSTRUCTURED")) + "," + checkNull(res.get("PYMT_STATUS")) + "," + checkNull(res.get("PYMT_TRNSFR_TYPE")) + "," + checkNull(res.get("PYMT_PLATFORM_STATUS")) + "," + checkNull(res.get("PYMT_TYPE"))
					+ "," + checkNull(res.get("PYMT_CATEGORY")) + "," + checkNull(res.get("PYMT_SUBMISSION_ID")) + "," + checkNull(res.get("MRCHNT_CAT_CODE")) + "," + checkNull(res.get("MER_CUST_ID")) + "," + checkNull(res.get("UPDATE_TIMESTAMP")) + "," + checkNull(res.get("FRD_ID")) + "," + checkNull(res.get("FRD_SYS_RES")) + "," + checkNull(res.get("SOURCE_CHANNEL")) + "," + checkNull(res.get("DESTINATION_CTRY")) + ")";
			bulkInsertPaymentQuery.add(query);
		}

		try {
			dao.runBulkUpdateQueryPayment(bulkInsertPaymentQuery);
		} catch (Exception e) {
			LogUtil.log("ERROR : " + e.getMessage());
		}
		String selqueryAddressBckup="SELECT * FROM PAYMENT_ADDRESS_BACKUP";

		List<Map<String, Object>> selQueryAddressresult = dao.runQueryPaymentBackUp(selqueryAddressBckup);
		List<String> bulkInsertAddressQuery = new ArrayList<>();
		for (Map<String, Object> res:selQueryAddressresult) {
			String queryToAddress = "INSERT INTO PAYMENT_ADDRESS (ADDRESS_ID,PYMT_ID,CREATE_TIMESTAMP,ADDRESS_TYPE,ADDRESS_LINE_1,ADDRESS_LINE_2,SUB_DIV1,SUB_DIV2,STREET_NAME,BUILDING_NUM,POST_CODE,TOWN_NAME,COUNTRY) VALUES ("
					+ checkNull(res.get("ADDRESS_ID")) + "," + checkNull(res.get("PYMT_ID")) + "," + checkNull(res.get("CREATE_TIMESTAMP")) + "," + checkNull(res.get("ADDRESS_TYPE")) + "," + checkNull(res.get("ADDRESS_LINE_1")) + "," + checkNull(res.get("ADDRESS_LINE_2")) + "," + checkNull(res.get("SUB_DIV1")) + "," + checkNull(res.get("SUB_DIV2")) + "," + checkNull(res.get("STREET_NAME")) + "," + checkNull(res.get("BUILDING_NUM")) + "," + checkNull(res.get("POST_CODE")) + "," + checkNull(res.get("TOWN_NAME")) + "," + checkNull(res.get("COUNTRY")) + ")";
			bulkInsertAddressQuery.add(queryToAddress);
		}

		try {
			dao.runBulkUpdateQueryPayment(bulkInsertAddressQuery);
		} catch (Exception e) {
			LogUtil.log("ERROR : " + e.getMessage());
		}

	}

	private void loadChannelUserStatus() {
		String selQuery="SELECT * FROM PSD_USER.CHANNEL_USER_STATUS_BACKUP";
		List<Map<String, Object>> result = dao.runQueryBackUp(selQuery);
		for (Map<String, Object> res:result){
			String query = "INSERT INTO CHANNEL_USER_STATUS (CHANNEL_ID, PIN_STATUS, PIN_STATUS_SEQ_NO, CREATED_AT, MODIFIED_AT) VALUES ("+checkNull(res.get("CHANNEL_ID"))+","+checkNull(res.get("PIN_STATUS"))+","+checkNull(res.get("PIN_STATUS_SEQ_NO"))+","+checkNull(res.get("CREATED_AT"))+","+checkNull(res.get("MODIFIED_AT"))+")";
			try {
				if (config().getString("test.environment").equalsIgnoreCase("ST")) {
					dao.runUpdateQueryAbt(query);
				}else{
					dao.runUpdateQueryB365Accounts(query);
				}
			} catch (Exception e) {
				LogUtil.log("ERROR : " + e.getMessage());
			}
		}
	}
	private String checkNull(Object obj){
		return obj==null?null:checkSQLDate(obj.toString());
	}

	private String checkSQLDate(String repVar) {
		return repVar.toString().contains("-") && repVar.toString().contains(":") ?"TO_TIMESTAMP('"+repVar+"', 'YYYY-MM-DD HH24:MI:SS.FF')":"'"+repVar+"'";

	}

	private void loadChannelUserAuth() {
		String selQuery="SELECT * FROM PSD_USER.CHANNEL_USER_AUTH_BACKUP";
		List<Map<String, Object>> result = dao.runQueryBackUp(selQuery);
		for (Map<String, Object> res:result){
			String query = "INSERT INTO CHANNEL_USER_AUTH (CHANNEL_ID, SERIAL_NUM, REG_STATUS, FAIL_COUNT, LOCKED_UPTO, VERSION, LAST_SUCCESSFUL, LAST_FAILED, REGISTERED_AT, DEREG_AT) VALUES ("+checkNull(res.get("CHANNEL_ID"))+","+checkNull(res.get("SERIAL_NUM"))+","+checkNull(res.get("REG_STATUS"))+","+checkNull(res.get("FAIL_COUNT"))+","+checkNull(res.get("LOCKED_UPTO"))+","+checkNull(res.get("VERSION"))+","+checkNull(res.get("LAST_SUCCESSFUL"))+","+checkNull(res.get("LAST_FAILED"))+","+checkNull(res.get("REGISTERED_AT"))+","+checkNull(res.get("DEREG_AT"))+")";
			try {
				if (config().getString("test.environment").equalsIgnoreCase("ST")) {
					dao.runUpdateQueryAbt(query);
				}else{
					dao.runUpdateQueryB365Accounts(query);
				}
			} catch (Exception e) {
				LogUtil.log("ERROR : " + e.getMessage());
			}
		}
	}

	public static void main(String a[]) {
		new InitService().initaliseDB();
	}
}
