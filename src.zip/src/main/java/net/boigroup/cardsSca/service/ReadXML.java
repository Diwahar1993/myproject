package net.boigroup.cardsSca.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.*;
import com.google.gson.stream.JsonReader;

import jxl.Sheet;
import jxl.Workbook;
import net.boigroup.bdd.framework.LogUtil;
import net.sf.json.JSONObject;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import java.io.*;
import java.util.ArrayList;
import java.util.LinkedHashMap;

import static net.boigroup.bdd.framework.ConfigLoader.config;

public class ReadXML {

	private String basedir = System.getProperty("user.dir")
			+"/src/main/resources";
	private static String xml;
	private static String txt;

	public File[] finder(String dirName, String fileName) {
		File dir = new File(dirName);

		return dir.listFiles(new FilenameFilter() {
			public boolean accept(File dir, String filename) {
				return filename.endsWith(fileName + ".xml");
			}
		});

	}

	public String readXML(String fileName,String folderName) {
		//LogUtil.log(fileName);

		for (File file : finder(basedir + "/payload/"+folderName, fileName)) {
			try {
				File fXmlFile = new File(file.getAbsolutePath());
				DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
				DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
				Document doc = dBuilder.parse(fXmlFile);
				DOMSource domSource = new DOMSource(doc);
				StringWriter writer = new StringWriter();
				StreamResult result = new StreamResult(writer);
				TransformerFactory tf = TransformerFactory.newInstance();
				Transformer transformer = tf.newTransformer();
				transformer.transform(domSource, result);
				xml = writer.toString();
			} catch (ParserConfigurationException e) {
				e.printStackTrace();
			} catch (SAXException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			} catch (TransformerConfigurationException e) {
				e.printStackTrace();
			} catch (TransformerException e) {
				e.printStackTrace();
			}

		}

		return xml;
	}

	public  String trim(String input) {

		BufferedReader reader = new BufferedReader(new StringReader(input));

		StringBuffer result = new StringBuffer();

		try {

		String line;

		while ( (line = reader.readLine() ) != null)

		result.append(line.trim());

		return result.toString();

		} catch (IOException e) {

		throw new RuntimeException(e);

		}

		}

	public static String getXmlBlockWithTagName(String payload,String tagName) {
		String tagStart = "<" + tagName + ">";
		String tagEnd = "</" + tagName + ">";
		int start = payload.indexOf(tagStart);
		int end = payload.lastIndexOf(tagEnd);
		String xmlBlockForTag = payload.substring(start, end) + tagEnd;
		return xmlBlockForTag;
	}

	public String XmlTagValueReplace(String payload, String tagName ,String tagValue) {
		LogUtil.log("TagValue  from bdd: " + tagValue);
		String tagStart = "<" + tagName + ">";
		String tagEnd = "</" + tagName + ">";
		int start = payload.indexOf(tagStart);
		int end = payload.lastIndexOf(tagEnd);
		String tagWithVal = payload.substring(start, end + tagName.length() + 3);
		payload=payload.replace(tagWithVal, "<"+tagName+">"+tagValue+"</"+tagName+">");
		LogUtil.log("TagName with Value : " + tagWithVal);
		return payload;
	}

	public static String replaceTagValueWithSameName(String payload, String tagName,String tagValue) {
		String rootTag=tagName.split("/")[0];
		String tagStart = "<" + tagName.split("/")[0] + ">";
		String tagEnd = "</" + tagName.split("/")[0] + ">";
		int start = payload.indexOf(tagStart);
		int end = payload.lastIndexOf(tagEnd);
		String tagWithValue = payload.substring(start, end + rootTag.length()+3 );
		String childTag=tagName.split("/")[1];
		String childTagStart = "<" + childTag + ">";
		String childTagEnd = "</" + childTag + ">";
		int childStart = tagWithValue.indexOf(childTagStart);
		int childEnd = tagWithValue.lastIndexOf(childTagEnd);
		int startTagValue=start+childStart;
		int endTagValue=(((tagName.length()+(2*childTag.length()))+9));
		String tagToBeReplaced=payload.substring(startTagValue,startTagValue+endTagValue);
		payload = payload.replace(tagToBeReplaced,"<"+childTag+">"+tagValue+"</"+childTag+">");
		return payload;
	}


	public  String xmlFormat(String xmlstring){
		xmlstring = xmlstring.replaceAll(">\\s+<", "><");
		Source xmlInput = new StreamSource(new StringReader(xmlstring));
		StringWriter stringWriter = new StringWriter();
		try {
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "no");
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			transformer.setOutputProperty(OutputKeys.DOCTYPE_PUBLIC, "yes");
			transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", String.valueOf(2));
			transformer.transform(xmlInput, new StreamResult(stringWriter));
			String result = stringWriter.toString().trim();
			return  result;
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
	public static String fetchtagNameWithVal(String payload, String tagName){

		String tagStart ="<"+tagName+">";
		String tagEnd="</"+tagName+">";
		int start=payload.indexOf(tagStart);
		int end =payload.lastIndexOf(tagEnd);
		String tagWithVal=payload.substring(start, end+tagName.length()+3);
		LogUtil.log("TagName with Value : "+tagWithVal);
		return tagWithVal;
	}

	public String jsonFormat(String jsonstring) {
		String jstring = jsonstring.trim();
		JsonReader reader = new JsonReader(new StringReader(jstring));
		reader.setLenient(true);
		JsonParser jsonParser = new JsonParser();
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		JsonElement element = jsonParser.parse(reader);
		jstring =gson.toJson(element);
		return jstring;
	}


	public static String getTagWithSameTagName(String payload, String tagName) {
		String rootTag=tagName.split("/")[0];
		String tagStart = "<" + tagName.split("/")[0] + ">";
		String tagEnd = "</" + tagName.split("/")[0] + ">";
		int start = payload.indexOf(tagStart);
		int end = payload.lastIndexOf(tagEnd);
		String tagWithValue = payload.substring(start, end + rootTag.length()+3 );
		String finalPayload=payload.substring(start, end + rootTag.length()+3 );
		String childTag=tagName.split("/")[1];
		String childTagStart = "<" + childTag + ">";
		String childTagEnd = "</" + childTag + ">";
		int childStart = tagWithValue.indexOf(childTagStart);
		int childEnd = tagWithValue.lastIndexOf(childTagEnd);
		int startTagValue=start+childStart;
		int endTagValue=(((tagName.length()+(2*childTag.length()))+9));
		String tagToBeRemoved=payload.substring(startTagValue,startTagValue+endTagValue);
		return tagToBeRemoved;
	}
	public static String readXlsWithSameTagName(String payload, String inputFileName, String outputFileName) {
		String basedir = System.getProperty("user.dir") + "/src/main/resources";
		Workbook tcWorkBook;
		String sheet_Path = basedir + config().getString(inputFileName);
		String lines = "";
		String key_Name = "";
		String finalXmlBlock = "";
		try {
			File file1 = new File(sheet_Path);
			tcWorkBook = Workbook.getWorkbook(file1);
			Sheet tcSheet = tcWorkBook.getSheet("DATA");
			/* Reading the excel to get data */
			for (int row = 1; row < tcSheet.getRows(); row++) {
				key_Name = tcSheet.getCell(0, row).getContents();
				if (payload.equalsIgnoreCase(key_Name)) {
 					String outfilepath = basedir + config().getString(outputFileName);
					String line;
					//String lines = "";
					try {
						File file = new File(outfilepath);
						BufferedReader reader = new BufferedReader(new FileReader(file.toString()));

						while ((line = reader.readLine()) != null) {
							lines = lines + line;
						}
						reader.close();
					} catch (Exception e) {
					}
					String xmlblock = lines;
					/* Inserting data in XML payload */
					for (int col = 1; col < tcSheet.getColumns(); col++) {
						String colHeader = tcSheet.getCell(col, 0).getContents();
						String colHeaderVal = "$-{" + colHeader + "}";
						String colValue = tcSheet.getCell(col, row).getContents();
						if (colValue.equals("NA")) {
							System.out.println("colHeader is NA ******" + colHeader);
							if(!(colHeader.contains("/"))) {
								xmlblock = xmlblock.replace(fetchtagNameWithVal(lines, colHeader), "");
							}
							else {
								xmlblock = xmlblock.replace(ReadXML.getTagWithSameTagName(lines, colHeader), "");
							}

						} else {
							xmlblock = xmlblock.replace(colHeaderVal, colValue);
						}
					}
					finalXmlBlock = finalXmlBlock + xmlblock;
				}
			}
		} catch (Exception e) {
		}
		return finalXmlBlock;
	}

    //***********************Remove XML and JSON*************************************//
	public  String removeJsontagByTagName(String json, String key) {

		JSONObject jsonObject = JSONObject.fromObject(json);
		json = jsonObject.toString();
		String[] keyArr = key.split("/");
		ObjectMapper mapper = new ObjectMapper();
		LinkedHashMap<String, Object> list = null;

		try {
			list = mapper.readValue(json, LinkedHashMap.class);

		} catch (IOException e) {
			e.printStackTrace();
		}

		String finalpayload = "";
		for (int i = 0; i < keyArr.length; i++) {
			if (i + 1 == keyArr.length) {
				list.put(keyArr[i], "").toString();
				list.remove(keyArr[i]);
			}
		}
		GsonBuilder gsonBuilder = new GsonBuilder();
		Gson gson = gsonBuilder.create();
		finalpayload = gson.toJson(list);

		return finalpayload;
	}

	public  String newRemoveJsontagByTagName1(String json, String key) {
		JsonElement jelement = new JsonParser().parse(json);
		JsonObject jObject = jelement.getAsJsonObject();
		jObject.remove(key);
		return jObject.toString();

	}


	public  String newRemoveJsontagByTagName(String json, String key) {
		JsonElement jelement = new JsonParser().parse(json);
		JsonObject jObject = jelement.getAsJsonObject();
		String[] keyArr = key.split("/");

		if(keyArr.length==1){
			jObject.remove(keyArr[0]);
		}
			if(keyArr.length==2) {
				jObject.getAsJsonObject(keyArr[0]).remove(keyArr[1]);
			}if(keyArr.length==3) {
			jObject.getAsJsonObject(keyArr[0]).getAsJsonObject(keyArr[1]).remove(keyArr[2]);
		}
			return jObject.toString();

    }


    public  String removeJsonTagByValue(String jsonString, String tag)
    {
        LogUtil.log(jsonString);
    	jsonString = jsonString.replace(tag,"\"\"");
        String temp = "";
        while (!temp.equals(jsonString)) {
            temp = jsonString;
            jsonString = jsonString.replaceAll("[^\\n]*(\\{(\\n)*\\}|\\\"(\\n)*\\\"|\\[(\\n)*\\])[^\\n]*\\n", "");
			LogUtil.log(jsonString);

		}
        return jsonString;
    }

    public String removeBlockFromResponse(String payload,String Start_target,String End_Target){
        int Start_index = payload.indexOf(Start_target);
        int End_index=payload.indexOf(End_Target);
        String Expected_XML_Block=payload.replace(payload.substring(Start_index,End_index+End_Target.length()),"");
        return Expected_XML_Block;
    }

	private static boolean isKeyArray(String s) {
		if (s.contains("[")&& s.contains("]"))
			return true;
		else
			return false;
	}
}
