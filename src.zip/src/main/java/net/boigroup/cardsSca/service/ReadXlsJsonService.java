package net.boigroup.cardsSca.service;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import jxl.Sheet;
import jxl.Workbook;
import net.sf.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedHashMap;


import static net.boigroup.bdd.framework.ConfigLoader.config;

public class ReadXlsJsonService {
    public static String readXlsJSONFile(String payload, String inputFileName, String outputFileName) {

        String basedir = System.getProperty("user.dir") + "/src/main/resources";
        Workbook tcWorkBook;
        String sheet_Path = basedir + config().getString(inputFileName);
        String lines = "";
        String key_Name = "";
        try {
            File file1 = new File(sheet_Path);
            tcWorkBook = Workbook.getWorkbook(file1);
            Sheet tcSheet = tcWorkBook.getSheet("DATA");

            /* Reading the excel to get data */
            for (int row = 1; row < tcSheet.getRows(); row++) {

                key_Name = tcSheet.getCell(0, row).getContents();
                if (payload.equalsIgnoreCase(key_Name)) {
                    String outfilepath = basedir + config().getString(outputFileName);
                    String line;
                    //String lines = "";
                    try {
                        File file = new File(outfilepath);
                        BufferedReader reader = new BufferedReader(new FileReader(file.toString()));

                        while ((line = reader.readLine()) != null) {
                            lines = lines + line;
                        }
                        reader.close();
                    } catch (Exception e) {

                    }
                    /* Inserting data in JSON payload */
                    for (int col = 1; col < tcSheet.getColumns(); col++) {
                        String colHeader = tcSheet.getCell(col, 0).getContents();
                        String colHeaderVal = "$-{" + colHeader + "}";
                        String colValue = tcSheet.getCell(col, row).getContents();
                        lines = lines.replace(colHeaderVal, colValue);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return lines;
    }

    public  String removeJsontagByTagName(String json, String key) {

        JSONObject jsonObject = JSONObject.fromObject(json);
        json = jsonObject.toString();
        String[] keyArr = key.split("/");
        ObjectMapper mapper = new ObjectMapper();
        LinkedHashMap<String, Object> list = null;

        try {
            list = mapper.readValue(json, LinkedHashMap.class);

        } catch (IOException e) {
            e.printStackTrace();
        }

        String finalpayload = "";
        for (int i = 0; i < keyArr.length; i++) {
            if (i + 1 == keyArr.length) {
                list.put(keyArr[i], "").toString();
                list.remove(keyArr[i]);
            }
        }
        GsonBuilder gsonBuilder = new GsonBuilder();
        Gson gson = gsonBuilder.create();
        finalpayload = gson.toJson(list);

        return finalpayload;
    }


    public  String removeJsonTagByValue(String jsonString, String tag)
    {
        jsonString = jsonString.replace(tag,"\"\"");
        String temp = "";
        while (!temp.equals(jsonString)) {
            temp = jsonString;
            jsonString = jsonString.replaceAll("[^\\n]*(\\{(\\n)*\\}|\\\"(\\n)*\\\"|\\[(\\n)*\\])[^\\n]*\\n", "");
        }
        return jsonString;
    }
}