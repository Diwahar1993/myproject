package net.boigroup.cardsSca.service;

public interface Constants {

	int SUCCESS = 200;
	int CREATED = 201;

	// System API Headers
	String XBOIUSER = "X-BOI-USER";
	String XBOIUSERVAL = "59000037";
	String XBOICHANNEL = "X-BOI-CHANNEL";
	String XBOICHANNELVAL = "B365";
	String XBOIPLATFORM = "X-BOI-PLATFORM";
	String XBOIPLATFORMVAL = "localhost";
	String XCORRELATIONID = "X-CORRELATION-ID";
	String CONTENT_TYPE="Content-Type";
	String CONTENT_TYPE_VAL="application/json";
	String ACCEPT="Accept";
	String ACCEPT_VAL="*/*";

	//Process API Headers
	String XAPISOURCESYSTEM="x-api-source-system";
	String X_API_SOURCE_SYSTEM="B365";
	String XAPISOURCEUSER="x-api-source-user";
	String X_API_SOURCE_USER="59000037";
	String XAPICORRELATIONID="x-api-correlation-id";
	String XAPITRANSACTIONID="x-api-transaction-id";
	String SOURCECLIENTID="client_id";
	String JWSSIGNATURE="x-jws-signature";
	String AUTHORIZATION="Authorization";

// Access Token

	String  GRANT_TYPE= "grant_type";
	String SCOPE = "scope";
	String CLIENT_ID = "client_id";
	String CLIENT_ID_VALUE = "BROADCOM_CREDIT_CLIENT_ID";
	String CLIENT_SECRET = "client_secret";
	String CLIENT_ASSERTION_TYPE = "client_assertion_type";
	String CLIENT_ASSERTION = "client_assertion";
	String  GRANT_TYPE_VALUE= "client_credentials";
	String SCOPE_VALUE = "cards_sca";
	String CLIENT_ASSERTION_TYPE_VALUE = "urn%3Aietf%3Aparams%3Aoauth%3Aclient-assertion-type%3Ajwt-bearer";
	String INVALID_VALUES= "ABCD";
	String CLIENT_ASSERTION_VALUE = "14dc3e5cfe41408d9e9e8f40f3153e01";
	String CLIENT_SECRET_VALUE = "5cD7c37C8e1D4E7Fb800Df3ab9cA68f9";
String TOKEN="token";
	/** API Errors****/
	String NOT_FOUND = "Not Found";
	String BAD_REQUEST = "Bad Request";
	String METHOD_NOT_ALLOWED = "Method Not Allowed";
	String REQUEST_TIMEOUT = "Request timeout";
	String TOO_MANY_REQUEST = "Too many request";
	String INTERNAL_SERVER_ERROR = "Internal server error";
	String SERVICE_UNAVAILABLE = "Service unavailable";
	String UNAUTHORIZED = "Unauthorized";
	String BAD_UNAUTHORIZED="Bad Unauthorized";
	String BAD_GATEWAY="Bad Gateway";
	String NOT_IMPLEMENTED="Not Implemented";
	String DATA_NOT_FOUND = "Data Not Found";
	String NOT_ACCEPTABLE="Not Acceptable";
	String FORBIDDEN="A policy validation error occurred";
	String UNSUPPORTED_MEDIA_TYPE="Unsupported Media Type";

	// Table Names
	String CHANNELACCOUNTPROFILE_TABLE="CHANNEL_ACCOUNT_PROFILE";
	String ABT_ACCOUNT_DETAILS_TABLE="ABT_ACCOUNT_DETAILS";
	String TBL_ACCOUNT_TABLE="TBL_ACCOUNT";
	String CIS_USER_TABLE="CIS_USER";
}