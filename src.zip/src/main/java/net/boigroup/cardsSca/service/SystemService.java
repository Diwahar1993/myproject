package net.boigroup.cardsSca.service;

import net.boigroup.bdd.framework.LogUtil;
import net.boigroup.bdd.framework.Rest.HttpResponse;
import net.boigroup.cardsSca.dao.CardsSCADao;

import javax.xml.bind.DatatypeConverter;
import java.security.MessageDigest;
import java.util.List;
import java.util.Map;

import static net.boigroup.bdd.framework.Asserts.assertThat;
import static net.boigroup.bdd.framework.ConfigLoader.config;
import static net.boigroup.bdd.framework.Rest.matchers.HasStringInContent.hasStringInContent;

public class SystemService {

    private ThreadLocal<ReadXML> readXML = new ThreadLocal<ReadXML>(){
        @Override
        public ReadXML initialValue() {
            return new ReadXML();
        }
    };
    CardsSCADao cardsSCADao = new CardsSCADao();
    CardsSCAService cardsSCAService=new CardsSCAService();
    public String hashDebitCardNo=null;

    public String getCheckBINAPIEndpoint() {
        String endpoint = null;
        endpoint = config().getString("mule.system.api.checkBINAPI.endpoint");
        return endpoint;
    }
    public String getCISUSERAuthEndpoint() {
        String endpoint = null;
        endpoint = config().getString("rest.customerAuthentication.v1.CIS_USER_ID");
        return endpoint;
    }

    public String getPlapplIDEndpoint() {
        String endpoint = null;
        endpoint = config().getString("rest.customerAuthentication.v1.PlapplID");
        return endpoint;
    }

    public String getCreditCardumberEndpoint() {
        String endpoint = null;
        endpoint = config().getString("rest.customerAuthentication.v1.CreditCardNumber");
        return endpoint;
    }
    public String getLegacyDeclickEndpoint() {
        String endpoint = null;
        endpoint = config().getString("de-click.Legacy");
        return endpoint;
    }
    public String getDeclickSystemAPIEndpoint() {
        String endpoint = null;
        endpoint = config().getString("mule.system.api.Declick.endpoint");
        return endpoint;
    }


    public String getpatchCachingEndpoint() {
        String endpoint = null;
        endpoint = config().getString("mule.cache.PATCH.endpoint");
        return endpoint;

    }

    public String getExpAuthenticationEndpoint() {
        String endpoint = null;
        endpoint = config().getString("exp.api.Authentication.endpoint");
        return endpoint;
    }
    public String getCallBackURLAPIEndpoint() {
        String endpoint = null;
        endpoint = config().getString("mule.system.api.getCallBackURL.endpoint");
        return endpoint;
    }
    public String getValidateOTPEndpoint() {
        String endpoint = null;
        endpoint = config().getString("mule.process.api.ValidateOTP.endpoint");
        return endpoint;
    }

    public String getValidateChallengeEndpoint() {
        String endpoint = null;
        endpoint = config().getString("mule.experience.api.ValidateChallenge.endpoint");
        return endpoint;
    }
    public String getCachePOSTEndpoint() {
        String endpoint = null;
        endpoint = config().getString("mule.cache.PUT.endpoint");
        return endpoint;
    }
    public String getCacheGETEndpoint() {
        String endpoint = null;
        endpoint = config().getString("mule.cache.GET.endpoint");
        return endpoint;
    }
    public String getCISUserWithDebitCardNo() {
        String endpoint = null;
        endpoint = config().getString("system.CisUserDebitCard.endpoint");
        return endpoint;
    }
    public String getAuthenticationEndpoint() {
        String endpoint = null;
        endpoint = config().getString("mule.process.api.Authentication.endpoint");
        return endpoint;
    }
    public String getGenerateJWSEndpoint() {
        String endpoint = null;
        endpoint = config().getString("rest.generateJWS.endpoint");
        return endpoint;
    }
    public String getVerifyJWSEndpoint() {
        String endpoint = null;
        endpoint = config().getString("rest.verifyJWS.endpoint");
        return endpoint;
    }
    public String getB365UserInfo_withCISUser(String cisUserId){
        String expectedResponse="";
        List<Map<String, Object>> result = cardsSCADao.get365UserinfoByCIS_USER(cisUserId);
        String dob = result.get(0).get("DATE_OF_BIRTH").toString();
        dob=dob.substring(0,10);
        //lastPayeeAddedDateTime conversion
        String payeeDate="$-LAST_PAYEE_ADDED";
        if (result.get(0).get("LAST_PAYEE_ADDED")!=null){
            payeeDate=result.get(0).get("LAST_PAYEE_ADDED").toString();
            payeeDate = payeeDate.substring(0, 10);
        }
        //lastLogon date conversion
        String lastlogon="$-LOGON_LAST";
        if (result.get(0).get("LOGON_LAST")!=null){
            lastlogon=result.get(0).get("LOGON_LAST").toString();
            lastlogon = lastlogon.substring(0, 19);
        }

        expectedResponse = readXML.get().readXML("CustomerAuthentication_Response_Template", "CustomerAuthenticationAPI");
        expectedResponse=expectedResponse.replace("$-DOB",dob)
        .replace("$-{PayeeDate}",payeeDate)
                .replace("$-{logonLast}",lastlogon);
        expectedResponse=cardsSCAService.convertXmlTemplateWithDBValue(expectedResponse,result.get(0));
        return expectedResponse;
    }

    public String getPlapplIDRequestPayload(String PlapplID , String DOB){
        String RequestPayload="";
        RequestPayload = readXML.get().readXML("CustomerAuthenticationPlapplIDRequest_Template", "CustomerAuthenticationAPI");
        RequestPayload=RequestPayload.replace("$-PlapplID", PlapplID).replace("$-DOB", DOB);
        return RequestPayload;
    }

    public String get365CreditPayload(String creditcardNumber){
        String requestPayload="";
        requestPayload = readXML.get().readXML("CustomerAuthenticationCreditRequest_Template", "CustomerAuthenticationAPI");
        requestPayload=requestPayload.replace("$-CreditcardNumber", creditcardNumber);
        return requestPayload;
    }

    public String get365UserinfoByPlapplIDandDOB(String plapplId , String dob){
        String expectedResponse="";
        String dobFormat = cardsSCAService.dobConversion(dob);
        LogUtil.log(dob);
        List<Map<String, Object>> result = cardsSCADao.get365UserinfoByPlapplIDandDOB(plapplId , dobFormat);
        String DateOfBirth = result.get(0).get("DATE_OF_BIRTH").toString();
        DateOfBirth=DateOfBirth.substring(0,10);
        //lastPayeeAddedDateTime conversion
        String payeeDate="$-LAST_PAYEE_ADDED";
        if (result.get(0).get("LAST_PAYEE_ADDED")!=null){
            payeeDate=result.get(0).get("LAST_PAYEE_ADDED").toString();
            payeeDate = payeeDate.substring(0, 10);
        }
//lastLogon date conversion
        String lastlogon="$-LOGON_LAST";
        if (result.get(0).get("LOGON_LAST")!=null){
            lastlogon=result.get(0).get("LOGON_LAST").toString();
            lastlogon = lastlogon.substring(0, 19);
        }
        expectedResponse = readXML.get().readXML("CustomerAuthentication_Response_Template", "CustomerAuthenticationAPI");
        expectedResponse=expectedResponse.replace("$-DOB",dob).replace("$-{PayeeDate}",payeeDate)
                .replace("$-{logonLast}",lastlogon);
        expectedResponse=cardsSCAService.convertXmlTemplateWithDBValue(expectedResponse,result.get(0));
        return expectedResponse;
    }

    public String get365UserinfoByCreditcardNumber(String CreditcardNumber){
        String expectedResponse="";
        List<Map<String, Object>> result = cardsSCADao.get365UserinfoByCreditcradNumber(CreditcardNumber);
        String dateOfBirth = result.get(0).get("DATE_OF_BIRTH").toString();
        dateOfBirth=dateOfBirth.substring(0,10);
        //lastPayeeAddedDateTime conversion
        String payeeDate="$-LAST_PAYEE_ADDED";
        if (result.get(0).get("LAST_PAYEE_ADDED")!=null){
            payeeDate=result.get(0).get("LAST_PAYEE_ADDED").toString();
            payeeDate = payeeDate.substring(0, 10);
        }
//lastLogon date conversion
        String lastlogon="$-LOGON_LAST";
        if (result.get(0).get("LOGON_LAST")!=null){
            lastlogon=result.get(0).get("LOGON_LAST").toString();
            lastlogon = lastlogon.substring(0, 19);
        }

        expectedResponse = readXML.get().readXML("CustomerAuthentication_Response_Template", "CustomerAuthenticationAPI");
        expectedResponse=expectedResponse.replace("$-DOB",dateOfBirth)
                .replace("$-{PayeeDate}",payeeDate)
                .replace("$-{logonLast}",lastlogon);
        expectedResponse=cardsSCAService.convertXmlTemplateWithDBValue(expectedResponse,result.get(0));
        return expectedResponse;
    }

    public  void verifyValidDebitNo(String debitCardNo) {

       String hashedDebitNo= getSHA256Hash(debitCardNo);
        List<Map<String, Object>> result = cardsSCADao.getDebitCardNo(hashedDebitNo);
        assertThat("Debit Card No is not present in DB !", result.size() > 0);
    }


    public  String verifyCIsUserDebitCardResponse(String debitCardNo) {
        String hashedDebitNo= getSHA256Hash(debitCardNo);
        List<Map<String, Object>> result  = cardsSCADao.getDebitCardNo(hashedDebitNo);
        String cardIssueDate="";
        if (result.get(0).get("CARD_ISSUE_DATE")!=null){
            cardIssueDate=result.get(0).get("CARD_ISSUE_DATE").toString();
            cardIssueDate = cardIssueDate.substring(0, 10);
            LogUtil.log("cardIssueDate:"+cardIssueDate);
        }
        String expectedResponse = readXML.get().readXML("CisUserDebitCardResponse", "CisUserDebitCard");

        expectedResponse=expectedResponse.replace("$-{cardIssueDate}",cardIssueDate).replace("<?xml version=\"1.0\" encoding=\"UTF-8\"?>","");
        expectedResponse=cardsSCAService.convertXmlTemplateWithDBValue(expectedResponse,result.get(0));
        LogUtil.log("Expected response is : "+expectedResponse);

        return expectedResponse;
        }



    public String getSHA256Hash(String debitCardNo ) {
        String result = null;
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(debitCardNo.getBytes("UTF-8"));
            hashDebitCardNo =bytesToHex(hash).toLowerCase();
            LogUtil.log("Hash Value :" +hashDebitCardNo);
            return hashDebitCardNo;
        }catch(Exception ex) {
            ex.printStackTrace();
        }
        return result;
    }
    public String  bytesToHex(byte[] hash) {
        return DatatypeConverter.printHexBinary(hash);
    }

    public String getCurrencyListEndpointWithoutSort() {
        String endpoint = null;
        endpoint = config().getString("system.CurrencyList.endpoint");
        return endpoint;
    }



    public String getCurrencyListEndpoint(String QueryParam) {
        String endpoint = null;
        String params = "";
        String multiQuery = "";
        endpoint = config().getString("system.CurrencyList.endpoint");
        if (QueryParam != "") {
            String[] qp = QueryParam.split(",");

            for (int i = 0; i < qp.length; i++) {
                String[] temp = qp[i].split("_");
                if (!(i == 0)) multiQuery = ",";
                if (temp[1].equalsIgnoreCase("ASC")) params += multiQuery + "+" + temp[0];
                else params += multiQuery + "-" + temp[0];

            }
        }
        endpoint += "?sort=" + params;
        return endpoint;

    }

    public void verifyValidCurrency(String param) {
        List<Map<String, Object>> result = cardsSCADao.getValidCurrency(param);
        assertThat("Currency is not present in DB !", result.size() > 0);
    }

    public String orderQueryParam(String QueryParam) {

        String orderSortQuery ="";
        String multiQuery="";
        if (QueryParam != "") {
            String[] qp = QueryParam.split(",");
            for (int i = 0; i < qp.length; i++) {
                String[] temp = qp[i].split("_");
                if (!(i == 0)) multiQuery = ",";
                orderSortQuery += multiQuery + config().getString(temp[0])+" " + temp[1];

            }

        }
        return orderSortQuery;

    }

    public void verifyExpectedSuccessResponse(HttpResponse response, String param) {

        StringBuilder GetCurrencyListResponse = new StringBuilder();

        List<Map<String, Object>> currencylist = cardsSCADao.getValidCurrency(param);
        LogUtil.log("the size of list is" + currencylist.size());
        String expectedCurrencyListResponse;
        for (int i = 0; i < currencylist.size(); i++) {
            String name = currencylist.get(i).get("CURRENCY_NAME").toString();
            String code = currencylist.get(i).get("CURRENCY_CODE").toString();
            String numericCode = currencylist.get(i).get("FRACTION_DIGITS").toString();

            expectedCurrencyListResponse = readXML.get().readXML("GetCurrencyResponse", "GetCurrencyList");
            expectedCurrencyListResponse = expectedCurrencyListResponse.replace("<?xml version=\"1.0\" encoding=\"UTF-8\"?>", "");
            expectedCurrencyListResponse = expectedCurrencyListResponse.replace("$-NAME", name).replace("$-CODE", code);
            expectedCurrencyListResponse = cardsSCAService.convertXmlTemplateWithDBValue(expectedCurrencyListResponse, currencylist.get(i));
            GetCurrencyListResponse.append(expectedCurrencyListResponse);

        }

        String expectedresponse = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"+ "<ISOCurencyList xmlns=\"http://bankofireland.com/channels/currencyList/\">" + GetCurrencyListResponse.toString() + "</ISOCurencyList>";
        //expectedresponse=readXML.get().xmlFormat(expectedresponse);
        expectedresponse=expectedresponse.replace("<?xml version=\"1.0\" encoding=\"UTF-8\"?>","<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>");
        LogUtil.log("Expected response is:" + expectedresponse);

        assertThat("Unexpected response!! Currency Details is not present",response, hasStringInContent(expectedresponse));

    }

    public String getSoftTokenAuthenticationEndpoint() {
        String endpoint = null;
        endpoint = config().getString("mule.process.api.softTokenAuthentication.endpoint");
        return endpoint;
    }

    public String getBroadcomSystemAdaterCreditEndpoint() {
        String endpoint = null;
        endpoint = config().getString("mule.experience.api.broadcomSystemAdapter.credit.endpoint");
        return endpoint;
    }

    public String getBroadcomSystemAdaterDebitEndpoint() {
        String endpoint = null;
        endpoint = config().getString("mule.experience.api.broadcomSystemAdapter.debit.endpoint");
        return endpoint;
    }

    public String getAccessTokenGenerationSystemAPIEndpoint() {
        String endpoint = null;
        endpoint = config().getString("mule.accessTokenGeneration.SystemAPI");
        return endpoint;
    }

    public String validateAccessTokenSystemAPIEndpoint() {
        String endpoint = null;
        endpoint = config().getString("mule.validateAccessToken.SystemAPI");
        return endpoint;
    }
    public String validateAccessTokenProcessAPIEndpoint() {
        String endpoint = null;
        endpoint = config().getString("mule.validateAccessToken.ProcessAPI");
        return endpoint;
    }

    public String getJWKsSystemAPIEndpoint() {
        String endpoint = null;
        endpoint = config().getString("system.JWKs.SystemAPI");
        return endpoint;
    }

    public String getAccessTokenGenerationProcessAPIEndpoint() {
        String endpoint = null;
        endpoint = config().getString("mule.accessTokenGeneration.ProcessAPI");
        return endpoint;
    }

    public String getAccessTokenGenerationExpAPIEndpoint() {
        String endpoint = null;
        endpoint = config().getString("mule.accessTokenGeneration.ExpAPI");
        return endpoint;
    }
    public String getOCSPProcessAPIEndpoint() {
        String endpoint = null;
        endpoint = config().getString("mule.OCSP.ProcessAPI");
        return endpoint;
    }
    public String getOCSPSystemAPIEndpoint() {
        String endpoint = null;
        endpoint = config().getString("mule.OCSP.SystemAPI");
        return endpoint;
    }


}
