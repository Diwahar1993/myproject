package net.boigroup.cardsSca.service;

import net.boigroup.bdd.framework.JsonUtils;
import net.boigroup.bdd.framework.LogUtil;
import net.boigroup.bdd.framework.Rest.HttpResponse;
import net.boigroup.bdd.framework.Rest.RequestBuilder;
import net.boigroup.bdd.framework.Rest.RestActions;
import net.boigroup.bdd.framework.XMLUtils;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.Map;
import java.util.UUID;

import static net.boigroup.bdd.framework.Asserts.assertThat;
import static net.boigroup.bdd.framework.ConfigLoader.config;
import static net.boigroup.bdd.framework.Rest.matchers.HasStringInContent.hasStringInContent;
import static org.hamcrest.CoreMatchers.is;

public class CardsSCAService implements Constants {

    private String error = null;
    private String channel = null;
    private String XCORRELATIONIDVAL = "";
    private String X_API_CORRELATION_ID = "";
    private String X_API_TRANSACTION_ID = "";

    ThreadLocal<SystemService> systemService = new ThreadLocal<SystemService>() {
        @Override
        public SystemService initialValue() {
            return new SystemService();
        }
    };
    private ThreadLocal<HttpResponse> generateJWSresponse=new ThreadLocal<>();
    public String getError() {
        return error;
    }

    ReadXML readXML = new ReadXML();
    private ThreadLocal<JsonUtils> json = new ThreadLocal<JsonUtils>() {
        @Override
        public JsonUtils initialValue() {
            return new JsonUtils();
        }
    };
    XMLUtils xmlUtils = new XMLUtils();
    public void setError(String error) {
        this.error = error;
    }

    public RequestBuilder defaultRequest() {
        return RestActions.onDefaultUri();
    }

    public boolean hasError() {
        boolean ret = false;
        if (getError() != null && !getError().isEmpty()) {
            ret = true;
        }
        return ret;
    }


/***** Headers ***///

// Common Headers for System API

    public RequestBuilder setHeaders(RequestBuilder request) {
        request.header(XBOIUSER, XBOIUSERVAL);
        if (!hasError() || !getError().equalsIgnoreCase("Unauthorized")) {
            request.header(XBOICHANNEL, XBOICHANNELVAL);
        }
        request.header(XBOIPLATFORM, XBOIPLATFORMVAL);
        XCORRELATIONIDVAL = UUID.randomUUID().toString();
        request.header(XCORRELATIONID, XCORRELATIONIDVAL);
        return request;
    }
// Set headers with Specific User Id

    public RequestBuilder setHeadersForSpecificUserId(RequestBuilder request, String xboiUser) {
        request.header(XBOIUSER, xboiUser);
        if (!hasError() || !getError().equalsIgnoreCase("Unauthorized")) {
            request.header(XBOICHANNEL, XBOICHANNELVAL);
        }
        request.header(XBOIPLATFORM, XBOIPLATFORMVAL);
        XCORRELATIONIDVAL = UUID.randomUUID().toString();
        request.header(XCORRELATIONID, XCORRELATIONIDVAL);

        return request;
    }


// Unauthorised or missing Mandatory Headers
    public RequestBuilder setHeadersUnauthorizeForSpecificUserId(RequestBuilder request, String headersToAdd,
                                                                 String userid) {
        LogUtil.log(headersToAdd);
        if (!hasError() || getError().equalsIgnoreCase("Bad Unauthorized")) {
            if (headersToAdd.contains("XBOIUSER")) {
                request.header(XBOIUSER, userid);
            }
            if (headersToAdd.contains("XBOICHANNEL")) {
                request.header(XBOICHANNEL, XBOICHANNELVAL);
            }
            if (headersToAdd.contains("XBOIPLATFORM")) {
                request.header(XBOIPLATFORM, XBOIPLATFORMVAL);
            }
            if (headersToAdd.contains("XCORRELATIONID")) {
                XCORRELATIONIDVAL = UUID.randomUUID().toString();
                request.header(XCORRELATIONID, XCORRELATIONIDVAL);
            }
        }
        return request;
    }


    public RequestBuilder setHeadersBadUnauthorize(RequestBuilder request, String headersToAdd) {
        LogUtil.log(headersToAdd);
        if (!hasError() || getError().equalsIgnoreCase("Bad Unauthorized")) {
            if (headersToAdd.contains("XBOIUSER")) {
                request.header(XBOIUSER, XBOIUSERVAL);
            }
            if (headersToAdd.contains("XBOICHANNEL")) {
                request.header(XBOICHANNEL, XBOICHANNELVAL);
            }
            if (headersToAdd.contains("XBOIPLATFORM")) {
                request.header(XBOIPLATFORM, XBOIPLATFORMVAL);
            }
            if (headersToAdd.contains("XCORRELATIONID")) {
                XCORRELATIONIDVAL = UUID.randomUUID().toString();
                request.header(XCORRELATIONID, XCORRELATIONIDVAL);
                LogUtil.log("XCORRELATIONID : "+XCORRELATIONIDVAL);
            }
        }
        return request;
    }
    public void verifyCorrrerlationID(HttpResponse response) {
        String expected = response.getHeaders().get(XCORRELATIONID);
        assertThat("Correlation ID mismatch!", expected, is(XCORRELATIONIDVAL));
    }
    public String getJWS(HttpResponse response) {
        String jws = response.getHeaders().get(JWSSIGNATURE);
        return jws;
    }

    public void verifySucessResponseStatusCode(HttpResponse response) {
        assertThat("Unexpected response code!", response.getResponseCode().getCode(), is(SUCCESS));
    }

    public void verifySucessResponseCreatedStatusCode(HttpResponse response) {
//        assertThat("Correlation ID mismatch!", response.getHeaders().get(XCORRELATIONID), is(XCORRELATIONIDVAL));
        assertThat("Unexpected response code!", response.getResponseCode().getCode(), is(CREATED));
    }




    public void verifyErrorResponseStatusCode(HttpResponse response, String error) {
        int expectedcode = 0;

        if (hasError() && getError().equalsIgnoreCase(NOT_FOUND)) {
            expectedcode = 404;
        } else if (hasError() && getError().equalsIgnoreCase(BAD_REQUEST)) {
            expectedcode = 400;
        } else if (hasError() && getError().equalsIgnoreCase(METHOD_NOT_ALLOWED)) {
            expectedcode = 405;
        } else if (hasError() && getError().equalsIgnoreCase(REQUEST_TIMEOUT)) {
            expectedcode = 408;
        } else if (hasError() && getError().equalsIgnoreCase(TOO_MANY_REQUEST)) {
            expectedcode = 429;
        } else if (hasError() && getError().equalsIgnoreCase(INTERNAL_SERVER_ERROR)) {
            expectedcode = 500;
        } else if (hasError() && getError().equalsIgnoreCase(SERVICE_UNAVAILABLE)) {
            expectedcode = 503;
        } else if (hasError() && getError().equalsIgnoreCase(UNAUTHORIZED)) {
            expectedcode = 401;
        } else if (hasError() && getError().equalsIgnoreCase(NOT_IMPLEMENTED)) {
            expectedcode = 501;
        } else if (hasError() && getError().equalsIgnoreCase(DATA_NOT_FOUND)) {
            expectedcode = 404;
        } else if (hasError() && getError().equalsIgnoreCase(BAD_UNAUTHORIZED)) {
            expectedcode = 400;
        } else if (hasError() && getError().equalsIgnoreCase(BAD_GATEWAY)) {
            expectedcode = 502;
        } else if (hasError() && getError().equalsIgnoreCase(NOT_ACCEPTABLE)) {
            expectedcode = 406;
        } else if (hasError() && getError().equalsIgnoreCase(FORBIDDEN)) {
            expectedcode = 403;
        } else if (hasError() && getError().equalsIgnoreCase(UNSUPPORTED_MEDIA_TYPE)) {
            expectedcode = 415;
        }else {
            expectedcode = 404;
        }
        LogUtil.log("Expected response code is " + expectedcode);
        LogUtil.log("Actual response code is " + response.getResponseCode().getCode());
        assertThat("Unexpected response code!", response.getResponseCode().getCode(), is(expectedcode));
    }




    /**** Rest Methods ****/

    public HttpResponse executeGet(RequestBuilder request, String endpoint) {
        HttpResponse response = null;
        LogUtil.log("Endpoint Used : " + endpoint);
        //LogUtil.log("Request : " + request.toString());
        int retryCount = 0;
        while (retryCount != 10 && (response == null || response.getResponseCode().getCode() == 500)) {
            try {
                if (hasError() && getError().equalsIgnoreCase(NOT_FOUND)) {
                    if (endpoint.contains("?")) {
                        endpoint.replace("?", "//?");
                    }
                    response = request.get(endpoint);
                } else if (hasError() && getError().equalsIgnoreCase(BAD_REQUEST)) {
                    response = request.get(endpoint.replace("//", "/"));
                } else if (hasError() && getError().equalsIgnoreCase(METHOD_NOT_ALLOWED)) {
                    response = request.put(endpoint);
                } else if (hasError() && getError().equalsIgnoreCase(REQUEST_TIMEOUT)) {
                    request.timeout(0);
                    response = request.get(endpoint);
                } else if (hasError() && getError().equalsIgnoreCase(TOO_MANY_REQUEST)) {
                    for (int i = 1; i < 10; i++) {
                        response = request.get(endpoint);
                    }
                } else if (hasError() && getError().equalsIgnoreCase(INTERNAL_SERVER_ERROR)) {
                    response = request.get(endpoint);
                } else if (hasError() && getError().equalsIgnoreCase(SERVICE_UNAVAILABLE)) {
                    response = request.get(endpoint);
                } else {
                    response = request.get(endpoint);
                }

                LogUtil.log("Correlation ID of Request : " + XCORRELATIONIDVAL);
                LogUtil.log("Correlation ID of Response : " + response.getHeaders().get(XCORRELATIONID));
                LogUtil.log("Response Status : " + response.getResponseCode().toString());
                LogUtil.log("Response Code : " + response.getResponseCode().getCode());
                LogUtil.log("Response Body : " + response.getBody().toString());

            } catch (Exception e) {
                LogUtil.log("Error while sending request Resending..");
            }
            retryCount++;
        }
        if (response == null) {
            assertThat("Error while sending request Resending as the Response is NULL..", false);
        }
        return response;
    }

    public HttpResponse executePost(RequestBuilder request, String endpoint) {
        HttpResponse response = null;
        LogUtil.log("Endpoint Used : " + endpoint);
        int retryCount = 0;
        while (retryCount != 10 && response == null) {
            try {
                if (hasError() && getError().equalsIgnoreCase(NOT_FOUND)) {
                    if (endpoint.contains("?")) {
                        endpoint.replace("?", "//?");
                    } else {
                        endpoint = endpoint + "//";
                    }
                    response = request.post(endpoint);
                } else if (hasError() && getError().equalsIgnoreCase(BAD_REQUEST)) {
                    response = request.post(endpoint.replace("//", "/"));
                } else if (hasError() && getError().equalsIgnoreCase(METHOD_NOT_ALLOWED)) {
                    response = request.put(endpoint);
                } else if (hasError() && getError().equalsIgnoreCase(REQUEST_TIMEOUT)) {
                    request.timeout(0);
                    response = request.post(endpoint);
                } else if (hasError() && getError().equalsIgnoreCase(TOO_MANY_REQUEST)) {
                    for (int i = 1; i < 10; i++) {
                        response = request.post(endpoint);
                    }
                } else if (hasError() && getError().equalsIgnoreCase(INTERNAL_SERVER_ERROR)) {
                    response = request.post(endpoint);
                } else if (hasError() && getError().equalsIgnoreCase(SERVICE_UNAVAILABLE)) {
                    response = request.post(endpoint);
                }else if (hasError() && getError().equalsIgnoreCase(BAD_UNAUTHORIZED)) {
                    response = request.post(endpoint);
                }
                else {
                    response = request.post(endpoint);
                }

                LogUtil.log("Response Header : " + response.getHeaders());

                LogUtil.log("Correlation ID of Request : " + XCORRELATIONIDVAL);
                LogUtil.log("Correlation ID of Response : " + response.getHeaders().get(XCORRELATIONID));
                LogUtil.log("Response Status : " + response.getResponseCode().toString());
                LogUtil.log("Response Code : " + response.getResponseCode().getCode());
                LogUtil.log("Actual Response Body : " + response.getBody());

            } catch (Exception e) {
                LogUtil.log("Error while sending request Resending..");

            }
            retryCount++;
        }
        if (response == null) {
            assertThat("Error while sending request Resending..", false);
        }
        return response;
    }


    public HttpResponse executePut(RequestBuilder request, String endpoint) {
        HttpResponse response = null;
        LogUtil.log("Endpoint Used : " + endpoint);
        LogUtil.log("Request : " + request.toString());
        int retryCount = 0;
        while (retryCount != 10 && response == null) {
            try {
                if (hasError() && getError().equalsIgnoreCase(NOT_FOUND)) {
                    if (endpoint.contains("?")) {
                        endpoint.replace("?", "//?");
                    } else {
                        endpoint = endpoint + "//";
                    }
                    response = request.put(endpoint);
                } else if (hasError() && getError().equalsIgnoreCase(BAD_REQUEST)) {
                    response = request.put(endpoint.replace("//", "/"));
                } else if (hasError() && getError().equalsIgnoreCase(METHOD_NOT_ALLOWED)) {
                    response = request.put(endpoint);
                } else if (hasError() && getError().equalsIgnoreCase(REQUEST_TIMEOUT)) {
                    request.timeout(0);
                    response = request.put(endpoint);
                } else if (hasError() && getError().equalsIgnoreCase(TOO_MANY_REQUEST)) {
                    for (int i = 1; i < 10; i++) {
                        response = request.put(endpoint);
                    }
                } else if (hasError() && getError().equalsIgnoreCase(INTERNAL_SERVER_ERROR)) {
                    response = request.put(endpoint);
                } else if (hasError() && getError().equalsIgnoreCase(SERVICE_UNAVAILABLE)) {
                    response = request.put(endpoint);
                } else {
                    response = request.put(endpoint);
                }

                LogUtil.log("Correlation ID of Request : " + XCORRELATIONIDVAL);
                LogUtil.log("Correlation ID of Response : " + response.getHeaders().get(XCORRELATIONID));
                LogUtil.log("Response Status : " + response.getResponseCode().toString());
                LogUtil.log("Response Code : " + response.getResponseCode().getCode());

            } catch (Exception e) {
                LogUtil.log("Error while sending request Resending..");
            }
            retryCount++;
        }
        if (response == null) {
            assertThat("Error while sending request Resending..", false);
        }
        return response;
    }

    public HttpResponse executePatch(RequestBuilder request, String endpoint) {
        HttpResponse response = null;
        LogUtil.log("Endpoint Used : " + endpoint);
        LogUtil.log("Request : " + request.toString());
        int retryCount = 0;
        while (retryCount != 10 && response == null) {
            try {
                if (hasError() && getError().equalsIgnoreCase(NOT_FOUND)) {
                    if (endpoint.contains("?")) {
                        endpoint.replace("?", "//?");
                    } else {
                        endpoint = endpoint + "//";
                    }
                    response = request.patch(endpoint);
                } else if (hasError() && getError().equalsIgnoreCase(BAD_REQUEST)) {
                    response = request.patch(endpoint.replace("//", "/"));
                } else if (hasError() && getError().equalsIgnoreCase(METHOD_NOT_ALLOWED)) {
                    response = request.patch(endpoint);
                } else if (hasError() && getError().equalsIgnoreCase(REQUEST_TIMEOUT)) {
                    request.timeout(0);
                    response = request.patch(endpoint);
                } else if (hasError() && getError().equalsIgnoreCase(TOO_MANY_REQUEST)) {
                    for (int i = 1; i < 10; i++) {
                        response = request.patch(endpoint);
                    }
                } else if (hasError() && getError().equalsIgnoreCase(INTERNAL_SERVER_ERROR)) {
                    response = request.patch(endpoint);
                } else if (hasError() && getError().equalsIgnoreCase(SERVICE_UNAVAILABLE)) {
                    response = request.patch(endpoint);
                } else {
                    response = request.patch(endpoint);
                }

                LogUtil.log("Correlation ID of Request : " + XCORRELATIONIDVAL);
                LogUtil.log("Correlation ID of Response : " + response.getHeaders().get(XCORRELATIONID));
                LogUtil.log("Response Status : " + response.getResponseCode().toString());
                LogUtil.log("Response Code : " + response.getResponseCode().getCode());

            } catch (Exception e) {
                LogUtil.log("Error while sending request Resending..");
            }
            retryCount++;
        }
        if (response == null) {
            assertThat("Error while sending request Resending..", false);
        }
        return response;
    }

    public HttpResponse executeDelete(RequestBuilder request, String endpoint) {
        HttpResponse response = null;
        LogUtil.log("Endpoint Used : " + endpoint);
        LogUtil.log("Request : " + request.toString());
        int retryCount = 0;
        while (retryCount != 10 && response == null) {
            try {
                if (hasError() && getError().equalsIgnoreCase(NOT_FOUND)) {
                    if (endpoint.contains("?")) {
                        endpoint.replace("?", "//?");
                    } else {
                        endpoint = endpoint + "//";
                    }
                    response = request.delete(endpoint);
                } else if (hasError() && getError().equalsIgnoreCase(BAD_REQUEST)) {
                    response = request.delete(endpoint.replace("//", "/"));
                } else if (hasError() && getError().equalsIgnoreCase(METHOD_NOT_ALLOWED)) {
                    response = request.delete(endpoint);
                } else if (hasError() && getError().equalsIgnoreCase(REQUEST_TIMEOUT)) {
                    request.timeout(0);
                    response = request.delete(endpoint);
                } else if (hasError() && getError().equalsIgnoreCase(TOO_MANY_REQUEST)) {
                    for (int i = 1; i < 10; i++) {
                        response = request.delete(endpoint);
                    }
                } else if (hasError() && getError().equalsIgnoreCase(INTERNAL_SERVER_ERROR)) {
                    response = request.delete(endpoint);
                } else if (hasError() && getError().equalsIgnoreCase(SERVICE_UNAVAILABLE)) {
                    response = request.delete(endpoint);
                } else {
                    response = request.delete(endpoint);
                }

                LogUtil.log("Correlation ID of Request : " + XCORRELATIONIDVAL);
                LogUtil.log("Correlation ID of Response : " + response.getHeaders().get(XCORRELATIONID));
                LogUtil.log("Response Status : " + response.getResponseCode().toString());
                LogUtil.log("Response Code : " + response.getResponseCode().getCode());

            } catch (Exception e) {
                LogUtil.log("Error while sending request Resending..");
            }
            retryCount++;
        }
        if (response == null) {
            assertThat("Error while sending request Resending..", false);
        }
        return response;
    }

    public String getDate(int year) {
        Calendar cal = Calendar.getInstance();
        if (year < 0) {
            int date = year * 364;
            cal.add(Calendar.DATE, date);
        } else {
            cal.add(Calendar.YEAR, year);
        }
        Date nextYear = cal.getTime();
        return formatDate(nextYear);
    }

    public String formatDate(Date date) {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        String format = formatter.format(date);
        return format;
    }



    public CharSequence getendDateDate() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 1);
        Date nextDate = cal.getTime();
        return formatDate(nextDate);
    }

    public void verifySuccessfulPolicyBypass(HttpResponse response) {
        assertThat("Unexpected response code!", response.getResponseCode().getCode()!=403);
    }


    public String getCurrentDateTimeStamp() {
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss:SSS");
        Date date = new Date();
        return dateFormat.format(date);
    }

    // Reusable Validation Violation for ALL API's

    public void verifyValidationViolationErrorResponse(HttpResponse response, String code, String message) {
        String errorResponse = "<validationViolation>" + "<errorCode>" + code + "</errorCode>" + "<errorText>" + message
                + "</errorText>" + "</validationViolation>";
        LogUtil.log("Expected Response is :" + errorResponse);
        LogUtil.log("Actual Response is :" + response.getBody());
        assertThat("Unexpected response !" + errorResponse, response,
                hasStringInContent(errorResponse));
    }


    public void verifyXSDInvalid(HttpResponse response, String code, String message, String tagName, String tagValue) {
        String errorResponse = "<validationViolation>" + "<errorCode>" + code + "</errorCode>" + "<errorText>"  + message
                + "</errorText>" + "<errorField>" + tagName + "</errorField>" + "<errorValue>" + tagValue + "</errorValue>" + "</validationViolation>";
        LogUtil.log("Expected Response is :" + errorResponse);
        LogUtil.log("Actual Response is :" + response.getBody());
        assertThat("Unexpected response !" + errorResponse, response,
                hasStringInContent(errorResponse));
    }


    public static boolean hasStringNotInContent(HttpResponse response, String deleteStatus) {
        if (response.getBody().contains(deleteStatus)) {
            return false;
        } else {
            return true;
        }

    }

    public String convertXmlTemplateWithDBValue(String XmlTemplate, Map<String, Object> DbResult) {
        String nodeVal = "";
        boolean chk = true;

        for (Map.Entry<String, Object> entry : DbResult.entrySet()) {
            if (entry.getValue() != null) {

                String valData = entry.getValue().toString();
                if (entry.getKey().equalsIgnoreCase("CREDIT_GRADING"))
                    chk = false;
                nodeVal = (valData.equalsIgnoreCase("0") && chk) ? "N" : ((valData.equalsIgnoreCase("1") && chk) ? "Y" : valData);

                XmlTemplate = XmlTemplate.replace("$-" + entry.getKey(), nodeVal.trim());
            } else if (entry.getValue() == null) {
                if (entry.getKey().equalsIgnoreCase("CONSENT_PROVIDED")) {
                    XmlTemplate = XmlTemplate.replace("$-" + entry.getKey(), "Y");
                } else if (XmlTemplate.contains(entry.getKey())) {
                    String tagToBeremoved = XmlTemplate.split(entry.getKey())[1].split(">")[0].replace("</", "");
                    LogUtil.log("tagToBeremoved :" + tagToBeremoved);
                    XmlTemplate = XmlTemplate.replace(readXML.fetchtagNameWithVal(XmlTemplate, tagToBeremoved), "");

                }

            }
        }
        //LogUtil.log("Expecting Response :" +XmlTemplate );
        return XmlTemplate;
    }




    public String convertJurisdiction(String jurCodeInDB) {

        String expectedJur = "";
        switch (jurCodeInDB) {
            case "B":
                expectedJur = "GREAT_BRITAIN";
                break;
            case "S":
                expectedJur = "REPUBLIC_OF_IRELAND";
                break;
            case "N":
                expectedJur = "NORTHERN_IRELAND";

        }
        return expectedJur;
    }




    public String SheduledPaymentDateConversion(String DUE_DATE) {
        try {
            DateFormat formatA = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
            DateFormat formatB = new SimpleDateFormat("yyyy-MM-dd");
            Date date = formatA.parse(DUE_DATE);
            DUE_DATE = formatB.format(date);
            return DUE_DATE;

        } catch (ParseException e) {

        }
        return DUE_DATE;
    }

    public String SheduledPaymentTimeStampConversion(String TIMESTAMP) {
        try {
            DateFormat formatA = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
            DateFormat formatB = new SimpleDateFormat("yyyyMMddHHmmss");
            Date date = formatA.parse(TIMESTAMP);
            TIMESTAMP = formatB.format(date);
            return TIMESTAMP;

        } catch (ParseException e) {

        }
        return TIMESTAMP;
    }




    public int JsonArrayCount(String request,String jsonNode,String JsonArray,int index){
        int Count = 0;
        JSONObject jsonObject =  JSONObject.fromObject(request);
        JSONArray jsonArray = jsonObject.getJSONArray(jsonNode);
        JSONObject jsonObjectInsideArray = JSONObject.fromObject(jsonArray.getString(index));
        JSONArray jsonArrayInsideArray = jsonObjectInsideArray.getJSONArray(JsonArray);
        Count = jsonArrayInsideArray.size();
        LogUtil.log("Count is :"+Count);
        return Count;
    }

    public String getJsonArray(String request,String jsonNode,String JsonArray, int index){
        JSONObject jsonObject =  JSONObject.fromObject(request);
        JSONArray jsonArray = jsonObject.getJSONArray(jsonNode);
        JSONObject jsonObjectInsideArray = JSONObject.fromObject(jsonArray.getString(index));
        JSONArray jsonArrayInsideArray = jsonObjectInsideArray.getJSONArray(JsonArray);
        return jsonArrayInsideArray.toString();
    }

    public static void WriteFile(String fileContent,String filePath,String filename)
    {try {
        String basedir = System.getProperty("user.dir") + "/src/main/resources";
        BufferedWriter writer = new BufferedWriter(new FileWriter(basedir+filePath+filename));
        writer.write(fileContent);
        writer.close();
    }catch (Exception e){
        System.out.println(e);
    }
    }

    public String getAccountNumberFromIBANorSortCodeNumber(String AccountIdentification){
        String AccountNumber = "";
        if (AccountIdentification.length() == 14){
            AccountNumber = AccountIdentification.substring(6,AccountIdentification.length());
        }
        else if (AccountIdentification.length() > 14){
            AccountNumber = AccountIdentification.substring(14,AccountIdentification.length());
        }
        return AccountNumber;
    }

    public String getNSCFromIBANorSortCodeNumber(String AccountIdentification){
        String NSC = "";
        if (AccountIdentification.length() == 14){
            NSC = AccountIdentification.substring(0,6);
        }
        else if (AccountIdentification.length() > 14){
            NSC = AccountIdentification.substring(8,14);
        }
        return NSC;
    }
    //header method
    public RequestBuilder SetFSHeader(RequestBuilder request,String[]input) {
        //Define the String array in the below order
        // |X-CORRELATION-ID |X-BOI-USER|X-BOI-CHANNEL|X-BOI-PLATFORM|
        //eg., String[]inputHeaders={"RANDOM","BOL","source_System",userId};
        //pass "" if you want the header to be removed
        //pass "RANDOM" in array 0 for autogenerated x-api-transaction-Id
        if(input[0].equals("RANDOM")) {
            XCORRELATIONIDVAL = UUID.randomUUID().toString();
            request.header("X-CORRELATION-ID", XCORRELATIONIDVAL);
            LogUtil.log(XCORRELATIONID);
            LogUtil.log(XCORRELATIONIDVAL);
        }else if(!input[0].equals("")){
            request.header(XCORRELATIONID, input[0]);
        }
        if(!input[1].equals("")) { request.header(XBOIUSER, input[1]);}
        if(!input[2].equals("")) { request.header(XBOICHANNEL, input[2]);}
        if(!input[3].equals("")) {request.header(XBOIPLATFORM, XBOIPLATFORMVAL);}
        request.header("Accept", "*/*");
        return request;
    }

    public String fetchtagNameWithVal(String payload, String tagName) {

        String tagStart = "<" + tagName + ">";
        String tagEnd = "</" + tagName + ">";
        int start = payload.indexOf(tagStart);
        int end = payload.lastIndexOf(tagEnd);
        String tagWithVal = payload.substring(start, end + tagName.length() + 3);
        LogUtil.log("TagName with Value : " + tagWithVal);
        return tagWithVal;
    }
    public String fetchTagValue(String tagWithValue){
        String tagStart =  ">";
        String tagEnd = "</";
        int start = tagWithValue.indexOf(tagStart);
        int end = tagWithValue.lastIndexOf(tagEnd);
        String tagValue = tagWithValue.substring(start+1, end);
        LogUtil.log("Tagvalue : " + tagValue);
        return tagValue;
    }
    public String dobConversion(String dob){
        String dateString = "";
        try {

            Date date1 = new SimpleDateFormat("yyyy-MM-dd").parse(dob);
            DateFormat formatData = new SimpleDateFormat("dd-MMM-yy");
            dateString = formatData.format(date1);
        }catch(Exception e) {
            LogUtil.log("Exception is " +e);
        }
            return dateString.toUpperCase();
    }
    public String dateTimeStampConverison(){
        LocalDateTime datetime = LocalDateTime.now();
    DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ISO_LOCAL_DATE_TIME;
    String formattedDate = dateTimeFormatter.format(datetime);
    return formattedDate;
    }
    public String jwsGeneration(String payload,String kid,String privateKey,String detachedStatus){
        LogUtil.log(payload+"\n"+kid+"\n"+privateKey+"\n"+detachedStatus);
        String jws="";
        String jwsRequest=json.get().readTextFileFromPath("JWS", "generateJWS.txt").replace("$-{requestPayload}",payload).replace("$-{detachedStatus}",detachedStatus).replace("$-{kid}",kid).replace("$-{privateKey}",privateKey);
        LogUtil.logAttachment("the generate JWS payload is ",jwsRequest);
        RequestBuilder request = RestActions.onHTTPUri(config().getString("AT.uri"));
        String endpoint=systemService.get().getGenerateJWSEndpoint();
        request = setHeaders(request);
        request.body(jwsRequest.replace("-----BEGIN PRIVATE KEY-----","-----BEGIN PRIVATE KEY-----\n").replace("-----END PRIVATE KEY-----","\n-----END PRIVATE KEY-----"));
        LogUtil.log("the req body is .......\n"+jwsRequest);
        request.contentType("application/xml");
        generateJWSresponse.set(executePost(request, endpoint));
        LogUtil.logAttachment("generate JWS response is ",generateJWSresponse.get().toString());
         jws = xmlUtils.getTagValue(generateJWSresponse.get().getBody(), "jws", 0);
        return jws;
    }
    public String jwsVerification(String responseJws,String responsePayload){
        String jwsRequest=json.get().readTextFileFromPath("JWS", "verifyJWS.txt").replace("$-{jws}",responseJws).replace("$-{responsePayload}",responsePayload);
        LogUtil.logAttachment("the verify JWS payload is ",jwsRequest);
        RequestBuilder request = RestActions.onHTTPUri(config().getString("AT.uri"));
        String endpoint=systemService.get().getVerifyJWSEndpoint();
        request = setHeaders(request);
        LogUtil.log("the req body is .......\n"+jwsRequest);
        request.body(jwsRequest.replace("-----BEGIN PUBLIC KEY-----","-----BEGIN PUBLIC KEY-----\n").replace("-----END PUBLIC KEY-----","\n-----END PUBLIC KEY-----"));
        request.contentType("application/xml");
        generateJWSresponse.set(executePost(request, endpoint));
        LogUtil.logAttachment("generate JWS response is ",generateJWSresponse.get().toString());
        String jwsValueForReq = xmlUtils.getTagValue(generateJWSresponse.get().getBody(), "isJwsValid", 0);
        assertThat("jws is not valid!" ,jwsValueForReq.equals("true"));
        return jwsValueForReq;
    }
}