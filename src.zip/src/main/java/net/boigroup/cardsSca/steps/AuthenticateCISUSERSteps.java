package net.boigroup.cardsSca.steps;

import net.boigroup.bdd.framework.LogUtil;
import net.boigroup.bdd.framework.Rest.HttpResponse;
import net.boigroup.bdd.framework.Rest.RequestBuilder;
import net.boigroup.bdd.framework.Rest.RestActions;
import net.boigroup.bdd.framework.StorySteps;
import net.boigroup.cardsSca.dao.CardsSCADao;
import net.boigroup.cardsSca.service.CardsSCAService;
import net.boigroup.cardsSca.service.ReadXML;
import net.boigroup.cardsSca.service.SystemService;
import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;

import static net.boigroup.bdd.framework.Asserts.assertThat;
import static net.boigroup.bdd.framework.ConfigLoader.config;

@StorySteps
public class AuthenticateCISUSERSteps {
    ReadXML readXML = new ReadXML();
    CardsSCADao cardsSCADao = new CardsSCADao();
    ThreadLocal<SystemService> systemService = new ThreadLocal<SystemService>() {
        @Override
        public SystemService initialValue() {
            return new SystemService();
        }
    };
    private ThreadLocal<String> endpoint = new ThreadLocal<>();
    private ThreadLocal<CardsSCAService> cardsSCAService = new ThreadLocal<CardsSCAService>() {
        @Override
        public CardsSCAService initialValue() {
            return new CardsSCAService();
        }
    };
    private ThreadLocal<HttpResponse> response = new ThreadLocal<>();

    @Given("a valid $CIS_USERID present in CHANNEL_USER table")
    public void verifyCIS_USERID(String cisUserId) {
        Boolean result = cardsSCADao.verifyCisUserId(cisUserId);
        assertThat("CIS_USER not present in DB!", result == true);

    }

    @Given("an invalid $CIS_USERID present in CHANNEL_USER table")
    public void verifyInvalidCIS_USERID(String cisUserId) {
        Boolean result = cardsSCADao.verifyCisUserId(cisUserId);
        assertThat("CIS_USER not present in DB!", result == false);

    }
    @Given("an invalid $CIS_USERID")
    public void invalidCIS_USERID(String cisUserId) {
        LogUtil.log("invalid cisUserID is "+cisUserId);

    }

    @When("I request retrive channel USer details API by $CIS_USERID")
    public void hittingChannelUserDetails(String cisUserId) {
        RequestBuilder request = RestActions.onDefaultUri();
        endpoint.set(systemService.get().getCISUSERAuthEndpoint().replace("{CIS_USER_ID}", cisUserId));
        String[] inputHeaders = {"RANDOM", "BOL", "source_System", "userID"};
        request = cardsSCAService.get().SetFSHeader(request, inputHeaders);
        response.set(cardsSCAService.get().executeGet(request, endpoint.get()));

    }

    @When("I request retrive channel USer details API without $Header by $CIS_USERID")
    public void withoutMandatoryHeader(String Header, String cisUserId) {
        //Setting mandatory header values as null
        String correlationID = "RANDOM";
        String xBoiplatform = "X-BOI-PLATFORM";
        if (Header.equals("X-CORRELATION-ID")) {
            correlationID = "";
        } else if (Header.equals("X-BOI-PLATFORM")) {
            xBoiplatform = "";
        }
        RequestBuilder request = RestActions.onDefaultUri();
        endpoint.set(systemService.get().getCISUSERAuthEndpoint().replace("{CIS_USER_ID}", cisUserId));
        String[] inputHeaders = {correlationID, "", "", xBoiplatform};
        request = cardsSCAService.get().SetFSHeader(request, inputHeaders);
        response.set(cardsSCAService.get().executeGet(request, endpoint.get()));

    }

    @Then("I should get B365 user Details as successful response for $CIS_USERID")
    public void verifyCISUSERsuccessResponse(String cisUserId) {
        cardsSCAService.get().verifySucessResponseStatusCode(response.get());
        String expectedResponse = systemService.get().getB365UserInfo_withCISUser(cisUserId);
        expectedResponse=readXML.xmlFormat(expectedResponse);
        String actualResponse = response.get().getBody().toString();
        actualResponse=readXML.xmlFormat(actualResponse);
        LogUtil.logAttachment("Actual response is" ,actualResponse);
        LogUtil.logAttachment("Expected response is" ,expectedResponse);
        assertThat("Unexpected response !", actualResponse.equals(expectedResponse));

    }

    @Then("Authenticate CISUSER API should return the $customizedError response")
    public void verifyErrorResponseCISUsrDebit(String customizedError) {
        String errorMsg = config().getString(customizedError);
        String[] error = errorMsg.split(":");
        String code = error[0];
        String message = error[1];
        cardsSCAService.get().verifyCorrrerlationID(response.get());
        cardsSCAService.get().verifyErrorResponseStatusCode(response.get(), customizedError);
        cardsSCAService.get().verifyValidationViolationErrorResponse(response.get(),code,message);
    }
    @Then("Authenticate CISUSERAPI should return the $customizedError response")
    public void verifyError(String customizedError) {
        String errorMsg = config().getString(customizedError);
        String[] error = errorMsg.split(":");
        String code = error[0];
        String message = error[1];
        cardsSCAService.get().verifyErrorResponseStatusCode(response.get(), customizedError);
        cardsSCAService.get().verifyValidationViolationErrorResponse(response.get(),code,message);
    }

    @Given("Retrieve Channel User details by CIS UserID API has an $error")
    public void setError(String error) {
        cardsSCAService.get().setError(error);
    }
}
