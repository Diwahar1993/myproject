package net.boigroup.cardsSca.steps;

import net.boigroup.bdd.framework.LogUtil;
import net.boigroup.bdd.framework.Rest.HttpResponse;
import net.boigroup.bdd.framework.Rest.RequestBuilder;
import net.boigroup.bdd.framework.Rest.RestActions;
import net.boigroup.bdd.framework.StorySteps;
import net.boigroup.cardsSca.dao.CardsSCADao;
import net.boigroup.cardsSca.service.CardsSCAService;
import net.boigroup.cardsSca.service.ReadXML;
import net.boigroup.cardsSca.service.SystemService;
import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;

import java.util.List;
import java.util.Map;

import static net.boigroup.bdd.framework.Asserts.assertThat;
import static net.boigroup.bdd.framework.ConfigLoader.config;

@StorySteps
public class PlapplIDandDOBSteps {
	CardsSCADao cardsSCADao = new CardsSCADao();
	private ThreadLocal<String> endpoint = new ThreadLocal<>();
	private ThreadLocal<CardsSCAService> CardsSCAService = new ThreadLocal<net.boigroup.cardsSca.service.CardsSCAService>() {
		@Override
		public net.boigroup.cardsSca.service.CardsSCAService initialValue() {
			return new CardsSCAService();
		}
	};

	ThreadLocal<SystemService> systemService = new ThreadLocal<SystemService>() {
		@Override
		public SystemService initialValue() {
			return new SystemService();
		}


	};
	private ThreadLocal<HttpResponse> response = new ThreadLocal<>();
	private ThreadLocal<String> payload = new ThreadLocal<>();
	ReadXML readXML = new ReadXML();


	@Given("Construct a payload with $PlapplID and $DOB present in CHANNEL_USER table")
	public void constructPlapplIDandDOB(String PlapplID, String DOB) {
		payload.set(readXML.xmlFormat(systemService.get().getPlapplIDRequestPayload(PlapplID, DOB)));
		LogUtil.logAttachment("Expected Payload is ", payload.get().toString());
	}

	@When("I request for retriving the channel USer details API by $PlapplID and $DOB")
	public void requestingChannelUserDetailsbyPlapplID(String PlapplID, String DOB) {
		RequestBuilder request = RestActions.onDefaultUri();
		endpoint.set(systemService.get().getPlapplIDEndpoint());
		request = CardsSCAService.get().setHeaders(request);
		request.body(payload.get());
		request.contentType("application/xml");
		response.set(CardsSCAService.get().executePost(request, endpoint.get()));

	}

	@Then("I should be able to get user Details as successful response for $PlapplID and $DOB")
	public void verifyPlapplID_successResponse(String PlapplID, String DOB) {
		String expectedResponse = systemService.get().get365UserinfoByPlapplIDandDOB(PlapplID, DOB);
	    expectedResponse=readXML.xmlFormat(expectedResponse);
		String actualResponse = response.get().getBody().toString();
		actualResponse=readXML.xmlFormat(actualResponse);
		LogUtil.logAttachment("Expected response is ", expectedResponse);
		LogUtil.logAttachment("Actual response is ", actualResponse);
		assertThat("Unexpected response !", actualResponse.equals(expectedResponse));
		CardsSCAService.get().verifySucessResponseStatusCode(response.get());
		CardsSCAService.get().verifyCorrrerlationID(response.get());


	}

	@Given("Retrieve user details by PlapplID and DOB service has technical $error")
	public void setErroronPlapplIDandDOB(String error) {
		CardsSCAService.get().setError(error);
	}

	@Then("I should get error response from PlapplID and DOB service with $CustomizedError")
	public void verifyErrorPlapplIDandDOB(String CustomizedError) {
		String errorVal = config().getString(CustomizedError);
		String[] error = errorVal.split(":");
		String code = error[0];
		String message = error[1];
		CardsSCAService.get().verifyCorrrerlationID(response.get());
		CardsSCAService.get().verifyErrorResponseStatusCode(response.get(), CustomizedError);
		CardsSCAService.get().verifyValidationViolationErrorResponse(response.get(), code, message);

	}

	@Then("I should be able to get proper error response from CreditcardNumber service with $CustomizedError")
	public void verifyCreditError(String CustomizedError) {
		String errorVal = config().getString(CustomizedError);
		String[] error = errorVal.split(":");
		String code = error[0];
		String message = error[1];
		CardsSCAService.get().verifyErrorResponseStatusCode(response.get(), CustomizedError);
		CardsSCAService.get().verifyValidationViolationErrorResponse(response.get(), code, message);

	}

	@When("I request to retrive channel USer details API without $Header by $PlapplID")
	public void WithoutPlapplIDMandatoryHeader(String Header, String PlapplID) {
		//Setting mandatory header values as null
		String correlationID = "RANDOM";
		String xBoiplatform = "X-BOI-PLATFORM";
		if (Header.equals("X-CORRELATION-ID")) {
			correlationID = "";
		} else if (Header.equals("X-BOI-PLATFORM")) {
			xBoiplatform = "";
		}
		RequestBuilder request = RestActions.onDefaultUri();
		endpoint.set(systemService.get().getPlapplIDEndpoint());
		String[] inputHeaders = {correlationID, "", "", xBoiplatform};
		request = CardsSCAService.get().SetFSHeader(request, inputHeaders);
		request.body(payload.get());
		request.contentType("application/xml");
		response.set(CardsSCAService.get().executePost(request, endpoint.get()));

	}

	@Then("Service will return XSD validation $customizedError response with $tagName and $tagValue")
	public void verifyXSDErrorResponseplappl(String customizedError, String tagName, String tagValue ) {
		String errorMsg = config().getString(customizedError);
		String tagvalue1 = config().getString(tagValue);
		String[] error = errorMsg.split(":");
		String code = error[0];
		String message = error[1];
		CardsSCAService.get().verifyCorrrerlationID(response.get());
		CardsSCAService.get().verifyErrorResponseStatusCode(response.get(), customizedError);
		CardsSCAService.get().verifyXSDInvalid(response.get(),code,message,tagName,tagvalue1);
	}

	@Then("the Service will return XSDvalidation error with invalid $PlapplID returns $CustomizedError response with $tagName and $tagValue")
	public void verifyXSDErrorResponsePlapplID(String PlapplID , String customizedError, String tagName, String tagValue ) {
		String errorMsg = config().getString(customizedError);
		String[] error = errorMsg.split(":");
		String code = error[0];
		String message = error[1];
		CardsSCAService.get().verifyCorrrerlationID(response.get());
		CardsSCAService.get().verifyErrorResponseStatusCode(response.get(), customizedError);
		CardsSCAService.get().verifyXSDInvalid(response.get(),code,message,tagName,PlapplID);
	}

	}