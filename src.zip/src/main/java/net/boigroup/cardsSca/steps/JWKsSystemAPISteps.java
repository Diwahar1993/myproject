package net.boigroup.cardsSca.steps;

import net.boigroup.bdd.framework.JsonUtils;
import net.boigroup.bdd.framework.LogUtil;
import net.boigroup.bdd.framework.Rest.HttpResponse;
import net.boigroup.bdd.framework.Rest.RequestBuilder;
import net.boigroup.bdd.framework.Rest.RestActions;
import net.boigroup.bdd.framework.StorySteps;
import net.boigroup.cardsSca.service.CardsSCAService;
import net.boigroup.cardsSca.service.MuleService;
import net.boigroup.cardsSca.service.ReadXML;
import net.boigroup.cardsSca.service.SystemService;
import org.jbehave.core.annotations.Alias;
import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;

import static net.boigroup.bdd.framework.Asserts.assertThat;
import static net.boigroup.bdd.framework.ConfigLoader.config;


@StorySteps
public class JWKsSystemAPISteps {
    ThreadLocal<CardsSCAService> cardsSCAService = new ThreadLocal<CardsSCAService>() {
        @Override
        public CardsSCAService initialValue() {
            return new CardsSCAService();
        }
    };
    ThreadLocal<MuleService> muleService = new ThreadLocal<MuleService>() {
        @Override
        public MuleService initialValue() {
            return new MuleService();
        }
    };
    ThreadLocal<SystemService> systemService = new ThreadLocal<SystemService>() {
        @Override
        public SystemService initialValue() {
            return new SystemService();
        }
    };

    public ThreadLocal<HttpResponse> response = new ThreadLocal<HttpResponse>();
    private ThreadLocal<String> endpoint = new ThreadLocal<>();
    private ThreadLocal<String> requestPayload = new ThreadLocal<>();
    public ThreadLocal<String> responsePayload = new ThreadLocal<>();

    @Given("User Requesting JWKs System API")

    public void requestPayload(){
        cardsSCAService.get().setError(null);
    }


    @When("I request JWKs System API to get the response with $domainId")
    public void requestJWKsService(String domainId) {
        RequestBuilder request = RestActions.onHTTPUri(config().getString("mule.caching.uri"));
        endpoint.set(systemService.get().getJWKsSystemAPIEndpoint().replace("{domain-id}",domainId));
        request= muleService.get().setMuleHeaders(request);
        request.contentType("application/json");
        response.set(cardsSCAService.get().executeGet(request, endpoint.get()));
        LogUtil.logAttachment("Actual Response is ", response.get().getBody());
    }

    @Then("I should get success response when requesting the API")
    public void verifySuccessResponse() {
        cardsSCAService.get().verifySucessResponseStatusCode(response.get());

    }

    @When("I request JWKs system API without one or more mandatory headers $headersToAdd with $domainId")
    public void withoutMandatoryHeader(String headersToAdd,String domainId) {
        RequestBuilder request = RestActions.onHTTPUri(config().getString("mule.caching.uri"));
        request = muleService.get().setMuleHeadersUnauthorize(request, headersToAdd);
        endpoint.set(systemService.get().getJWKsSystemAPIEndpoint().replace("{domain-id}",domainId));
        response.set(cardsSCAService.get().executeGet(request, endpoint.get()));
    }

    @Then("JWKs API will return error response with $customizedError")
    public void verifyErrorResponse(String customizedError) {
        String ErrorCodemessage = config().getString(customizedError);
        String[] error = ErrorCodemessage.split(":");
        String api = error[0];
        String code = error[1];
        String type = error[2];
        String summary = error[3];
        String description = error[4];
        String errordetail = config().getString(description);
        LogUtil.log(errordetail);
        cardsSCAService.get().verifyErrorResponseStatusCode(response.get(), customizedError);
        muleService.get().verifyMuleErrorMessagesAPI(response.get(), endpoint.get(), api, code, type, summary, errordetail);
    }

    @Given("JWKs API has technical $error")
    public void setJWKsErrorInService(String error) {
        cardsSCAService.get().setError(error);
    }

    }