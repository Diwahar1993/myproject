package net.boigroup.cardsSca.steps;

import net.boigroup.bdd.framework.*;
import net.boigroup.bdd.framework.Rest.HttpResponse;
import net.boigroup.bdd.framework.Rest.RequestBuilder;
import net.boigroup.bdd.framework.Rest.RestActions;
import net.boigroup.cardsSca.service.CardsSCAService;
import net.boigroup.cardsSca.service.MuleService;
import net.boigroup.cardsSca.service.SystemService;
import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;

import static net.boigroup.bdd.framework.Asserts.assertThat;
import static net.boigroup.bdd.framework.ConfigLoader.config;

@StorySteps
public class DeclickSystemAPISteps {
    ThreadLocal<SystemService> systemService = new ThreadLocal<SystemService>() {
        @Override
        public SystemService initialValue() {
            return new SystemService();
        }
    };
    XMLUtils xmlUtils = new XMLUtils();
    ThreadLocal<MuleService> muleService = new ThreadLocal<MuleService>() {
        @Override
        public MuleService initialValue() {
            return new MuleService();
        }
    };
    private ThreadLocal<String> endpoint = new ThreadLocal<>();
    private ThreadLocal<CardsSCAService> cardsSCAService = new ThreadLocal<CardsSCAService>() {
        @Override
        public CardsSCAService initialValue() {
            return new CardsSCAService();
        }
    };
    private ThreadLocal<HttpResponse> declickresponse = new ThreadLocal<>();
    private ThreadLocal<HttpResponse> response = new ThreadLocal<>();
    private ThreadLocal<JsonUtils> json = new ThreadLocal<JsonUtils>() {
        @Override
        public JsonUtils initialValue() {
            return new JsonUtils();
        }
    };
    private ThreadLocal<String> Payload = new ThreadLocal<>();

    @Given("a $creditCardNo with PLAPPL_ID  and DOB")
    public void verifyLegacyDeclick(String creditCardNo) {
        RequestBuilder request = RestActions.onHTTPUri("http://172.31.33.231:8080");
        endpoint.set(systemService.get().getLegacyDeclickEndpoint().replace("{CreditCard}", creditCardNo));
        declickresponse.set(cardsSCAService.get().executeGet(request, endpoint.get()));
        LogUtil.logAttachment("DeclickResponse", declickresponse.get().getBody());

    }

    @Given("set payload with $creditCardNo")
    public void setPayload(String creditCardNo) {
        String requestPayload = json.get().readTextFileFromPath("DeclickSystemAPI", "DeclickSystemAPIRequestTemplate.txt");
        requestPayload = requestPayload.replace("{cardnumber}", creditCardNo);
        requestPayload = json.get().jsonFormat(requestPayload);
        Payload.set(requestPayload);
        LogUtil.logAttachment("Request Payload is",requestPayload);
    }

    @When("I request Declick System API with $creditCardNo")
    public void declickSystemAPI(String creditCardNo) {
        RequestBuilder request = RestActions.onHTTPUri(config().getString("mule.customerProp.url"));
        endpoint.set(systemService.get().getDeclickSystemAPIEndpoint());
        request = muleService.get().setMuleHeaders(request);
        request.body(Payload.get());
        request.contentType("application/json");
        response.set(cardsSCAService.get().executePost(request, endpoint.get()));
        LogUtil.logAttachment("Actual Response is" , response.get().getBody());

    }

    @Then("I should get success response with required fields for $creditCardNo")
    public void verifySuccessResponse(String creditCardNo) {
        cardsSCAService.get().verifySucessResponseStatusCode(response.get());
        muleService.get().muleVerifyCorrrerlationID(response.get());
        String declickResponse = declickresponse.get().getBody().toString();
        //fetch the CC block
        String ccBlock = xmlUtils.getXMLBlockParticularNodeForUniqueKey(declickResponse, "ns2:creditcards", "ns2:creditCardNumber", creditCardNo);
        LogUtil.log("CC_block is \n" + ccBlock);
//getting tag values from legacy declick
        String plaplId = xmlUtils.getTagValue(declickResponse, "ns2:PlApplId", 0);
        String dob = xmlUtils.getTagValue(ccBlock, "ns2:cardHolderBirthDate", 0);
        String currency = xmlUtils.getTagValue(declickResponse, "ns2:currencyNumeric", 0);


        String isActivePrimaryCard = xmlUtils.getTagValue(ccBlock, "ns2:isActivePrimaryCard", 0);



        String muleDeclickResponse = response.get().getBody().toString();
//getting tag values from Mule System API
        String ccNo = JsonUtils.getJsonValue(muleDeclickResponse, "card/identifier/primaryAccountNumber");
        String mulePlaplID = JsonUtils.getJsonValue(muleDeclickResponse, "creditCardAccount/identifier/plapplId");
        String muleDOB = JsonUtils.getJsonValue(muleDeclickResponse, "person/general/dateOfBirth");
        String muleCurrency="";
        if(currency!=null) {
            muleCurrency = JsonUtils.getJsonValue(muleDeclickResponse, "account/general/accountCurrency");
            assertThat("incorrect currency!", currency.equals(muleCurrency));
        }
        String muleisActivePrimaryCard = JsonUtils.getJsonValue(muleDeclickResponse, "card/general/isActivePrimaryCard");


///Asserting the response
        assertThat("incorrect plapplId!", plaplId.equals(mulePlaplID));
        assertThat("incorrect DOB!", dob.equals(muleDOB));


        assertThat("incorrect Active Status!", isActivePrimaryCard.equals(muleisActivePrimaryCard));
        assertThat("incorrect creditCardNo!", ccNo.equals(creditCardNo));
//minimum Balance field
        String bal = xmlUtils.getTagValue(declickResponse, "ns2:previousBalance", 0);
        float mulePrevBal=0;
        if(bal!=null) {
           float prevBal = Float.parseFloat(bal);
            mulePrevBal = Float.parseFloat(JsonUtils.getJsonValue(muleDeclickResponse, "creditCardAccount/monetaryAmount/creditUsedAmount"));
           assertThat("incorrect PrevBal!", prevBal == mulePrevBal);
       }
       //credit limit amount
        String creditLimitAmt = xmlUtils.getTagValue(declickResponse, "ns2:creditLimit", 0);
        float muleCreditLimit=0;
       if(creditLimitAmt!=null) {
            float creditLimit = Float.parseFloat(creditLimitAmt);
            muleCreditLimit = Float.parseFloat(JsonUtils.getJsonValue(muleDeclickResponse, "account/monetaryAmount/creditCardLimitAmount"));
            assertThat("incorrect creditLimit!", creditLimit == muleCreditLimit);
        }
        LogUtil.log("\n ****Legacy Declick tag values**** \n+plaplid -->" + plaplId + "\n" + "DOB -->" + dob + "\n" + "currency -->" + currency + "\n" + "creditlimit -->" + creditLimitAmt + "\n" + "PrevBal -->" + bal + "\n" + "cardActiveStatus -->" + isActivePrimaryCard + "\n");
        LogUtil.log("\n ****Declick System API tag values**** \n" + "plaplid -->" + mulePlaplID + "\n" + "DOB -->" + muleDOB + "\n" + "currency -->" + muleCurrency + "\n" + "creditlimit -->" + muleCreditLimit + "\n" + "PrevBal -->" + mulePrevBal + "\n" + "cardActiveStatus -->" + muleisActivePrimaryCard + "\n");

    }
    @Given("Declick System API has technical $error")
    public void setErrorInService(String error) {
        cardsSCAService.get().setError(error);
    }

    @Then("Declick System API will return error response with $customizedError")
    public void verifyErrorResponse(String customizedError) {
        String ErrorCodemessage = config().getString(customizedError);
        String[] error = ErrorCodemessage.split(":");
        String api = error[0];
        String code = error[1];
        String type = error[2];
        String summary = error[3];
        String description = error[4];
        String errordetail = config().getString(description);
        LogUtil.log(errordetail);
        cardsSCAService.get().verifyErrorResponseStatusCode(response.get(), customizedError);
        muleService.get().muleVerifyCorrrerlationID(response.get());
        muleService.get().verifyMuleErrorMessagesAPI(response.get(), endpoint.get(), api, code, type, summary, errordetail);
    }
    @When("I request DeclickSystemAPI without one or more mandatory headers $headersToAdd")
    public void withoutMandatoryHeader( String headersToAdd) {
        RequestBuilder request = RestActions.onHTTPUri(config().getString("mule.customerProp.url"));
        endpoint.set(systemService.get().getDeclickSystemAPIEndpoint());
        request = muleService.get().setMuleHeadersUnauthorize(request, headersToAdd);
        request.body(Payload.get());
        request.contentType("application/json");
        response.set(cardsSCAService.get().executePost(request, endpoint.get()));
        LogUtil.logAttachment("Actual Response is ", response.get().getBody());
    }
}
