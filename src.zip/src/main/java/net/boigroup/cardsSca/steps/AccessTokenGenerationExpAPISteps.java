package net.boigroup.cardsSca.steps;

import net.boigroup.bdd.framework.JsonUtils;
import net.boigroup.bdd.framework.LogUtil;
import net.boigroup.bdd.framework.Rest.HttpResponse;
import net.boigroup.bdd.framework.Rest.RequestBuilder;
import net.boigroup.bdd.framework.Rest.RestActions;
import net.boigroup.bdd.framework.StorySteps;
import net.boigroup.bdd.framework.XMLUtils;
import net.boigroup.cardsSca.service.CardsSCAService;
import net.boigroup.cardsSca.service.MuleService;
import net.boigroup.cardsSca.service.ReadXML;
import net.boigroup.cardsSca.service.SystemService;
import org.jbehave.core.annotations.Alias;
import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;

import java.time.Instant;

import static net.boigroup.bdd.framework.Asserts.assertThat;
import static net.boigroup.bdd.framework.ConfigLoader.config;


@StorySteps
public class AccessTokenGenerationExpAPISteps {
    ThreadLocal<CardsSCAService> cardsSCAService = new ThreadLocal<CardsSCAService>() {
        @Override
        public CardsSCAService initialValue() {
            return new CardsSCAService();
        }
    };
    ThreadLocal<MuleService> muleService = new ThreadLocal<MuleService>() {
        @Override
        public MuleService initialValue() {
            return new MuleService();
        }
    };
    ThreadLocal<SystemService> systemService = new ThreadLocal<SystemService>() {
        @Override
        public SystemService initialValue() {
            return new SystemService();
        }
    };
    ThreadLocal<ReadXML> xml = new ThreadLocal<ReadXML>() {
        @Override
        public ReadXML initialValue() {
            return new ReadXML();
        }
    };
    ThreadLocal<JsonUtils> jsonUtils = new ThreadLocal<JsonUtils>() {
        @Override
        public JsonUtils initialValue() {
            return new JsonUtils();
        }
    };
    public ThreadLocal<HttpResponse> response = new ThreadLocal<HttpResponse>();
    private ThreadLocal<String> endpoint = new ThreadLocal<>();
    private ThreadLocal<String> requestPayload = new ThreadLocal<>();
    public ThreadLocal<String> responsePayload = new ThreadLocal<>();
    private ThreadLocal<String> accessTokenreqPayload = new ThreadLocal<>();
    XMLUtils xmlUtils = new XMLUtils();
    private ThreadLocal<HttpResponse> generateJWSresponse=new ThreadLocal<>();
    private ThreadLocal<String> jwsReq = new ThreadLocal<>();
    private ThreadLocal<JsonUtils> json = new ThreadLocal<JsonUtils>() {
        @Override
        public JsonUtils initialValue() {
            return new JsonUtils();
        }
    };

    @Given("User Requesting the Generate Access Token Experience API")
    public void constructRequestPayload() {
        cardsSCAService.get().setError(null);
        long IAT = Instant.now().getEpochSecond();
        LogUtil.log("current time in Unix "+IAT);
        String unixTime = Long.toString(IAT);
        String accessTokenPayload=json.get().readTextFileFromPath("AccessToken", "accessTokenPayloadTemp.txt").replace("{time}",unixTime);
        accessTokenreqPayload.set(accessTokenPayload);
        LogUtil.log("payload is "+accessTokenreqPayload.get());
        LogUtil.logAttachment("the accesstoken payload is ",accessTokenPayload);

    }
    @Given("User Requesting the Generate Access Token Experience API with IAT range $iatRange")
    public void constructRequestPayloadOutofIATRange(String iatRange) {
        cardsSCAService.get().setError(null);
        String accessTokenPayload="";
        if(iatRange.equals("greater than 300")) {
            accessTokenPayload = json.get().readTextFileFromPath("AccessToken", "accessTokenPayloadTemp.txt").replace("{time}", Long.toString(Instant.now().getEpochSecond() + 310));
        }else if(iatRange.equals("less than 300")) {
            accessTokenPayload = json.get().readTextFileFromPath("AccessToken", "accessTokenPayloadTemp.txt").replace("{time}", Long.toString(Instant.now().getEpochSecond() - 310));
        }
            else if(iatRange.equals("pastDate")) {
            accessTokenPayload = json.get().readTextFileFromPath("AccessToken", "accessTokenPayloadTemp.txt").replace("{time}", Long.toString(Instant.now().getEpochSecond() -86400));

        }else if(iatRange.equals("futureDate")) {
            accessTokenPayload = json.get().readTextFileFromPath("AccessToken", "accessTokenPayloadTemp.txt").replace("{time}", Long.toString(Instant.now().getEpochSecond() +86400));

        }
        accessTokenreqPayload.set(accessTokenPayload);
        LogUtil.log("payload is "+accessTokenreqPayload.get());
        LogUtil.logAttachment("the accesstoken payload is ",accessTokenPayload);

    }

    @Given("Generate Access Token Experience API has technical $error")
    public void setErrorInService(String error) {
        cardsSCAService.get().setError(error);
    }
    @Then("wait for 300 seconds")
    public void waitTime()throws InterruptedException {
        Thread.sleep(300000);
    }

    @When("I request the Generate Access Token Experience API with valid $clientId and $client_assertion")
    public void requestTokenGenerationService(String clientId,String client_assertion) {
        clientId =config().getString(clientId);
        client_assertion =jwsReq.get();
        LogUtil.log(client_assertion);
        RequestBuilder request = RestActions.onHTTPUri(config().getString("experience.uri"));
        endpoint.set(systemService.get().getAccessTokenGenerationExpAPIEndpoint());
        LogUtil.log("************ header below*******");
        request= muleService.get().setAccessTokenRequest(request,clientId,client_assertion);
        request.contentType("application/x-www-form-urlencoded");
        request = muleService.get().setExperienceAPIAuthHeaders(request,clientId);
        response.set(cardsSCAService.get().executePost(request, endpoint.get()));
        LogUtil.logAttachment("Actual Response is ", response.get().getBody());
    }
    @When("I request the  Access Token Experience API with valid $clientId and $client_assertion without mandatory header $headersToAdd")
    public void requestTokenGenerationServicewithoutHeader(String clientId,String client_assertion,String headersToAdd) {
        clientId =config().getString(clientId);
        client_assertion =config().getString(client_assertion);
        LogUtil.log("client id is "+clientId);
        LogUtil.log("client_assertion is "+client_assertion);
        RequestBuilder request = RestActions.onHTTPUri(config().getString("experience.uri"));
        endpoint.set(systemService.get().getAccessTokenGenerationExpAPIEndpoint());
        request= muleService.get().setMuleHeadersUnauthorize(request,headersToAdd);
        request= muleService.get().setAccessTokenRequest(request,clientId,client_assertion);
        request.contentType("application/x-www-form-urlencoded");
        response.set(cardsSCAService.get().executePost(request, endpoint.get()));
        LogUtil.logAttachment("Actual Response is ", response.get().getBody());
    }

    @When("I request the Generate Access Token Experience API with incorrect Method $clientId and $client_assertion")
    public void requestTokenGenerationServiceincorMethod(String clientId,String client_assertion) {
        clientId =config().getString(clientId);
        client_assertion =config().getString(client_assertion);
        RequestBuilder request = RestActions.onHTTPUri(config().getString("experience.uri"));
        endpoint.set(systemService.get().getAccessTokenGenerationExpAPIEndpoint());
        request= muleService.get().setAccessTokenRequest(request,clientId,client_assertion);
        request.contentType("application/x-www-form-urlencoded");
        request = muleService.get().setExperienceAPIAuthHeaders(request,clientId);
        response.set(cardsSCAService.get().executePut(request, endpoint.get()));
        LogUtil.logAttachment("Actual Response is ", response.get().getBody());
    }

    @When("I request the  Access Token Experience API with valid $clientId and $client_assertion and $removeTags")
    public void requestTokenGenerationServicewithoutMandtory(String clientId,String client_assertion,String removeTags ) {
        clientId =config().getString(clientId);
        client_assertion =config().getString(client_assertion);
        RequestBuilder request = RestActions.onHTTPUri(config().getString("experience.uri"));
        endpoint.set(systemService.get().getAccessTokenGenerationExpAPIEndpoint());
        request= muleService.get().setAccessTokenRequest(request,clientId,client_assertion,removeTags);
        LogUtil.log("Request Passed :"+request.toString());
        request.contentType("application/x-www-form-urlencoded");
        request = muleService.get().setExperienceAPIAuthHeaders(request,clientId);
        response.set(cardsSCAService.get().executePost(request, endpoint.get()));
        LogUtil.logAttachment("Actual Response is ", response.get().getBody());
    }

    @Then("Experience API Generate Access Token API should return success response with Valid access token")
    public void verifySuccessResponseprocessGenerateToken() {
        cardsSCAService.get().verifySucessResponseStatusCode(response.get());
        muleService.get().verifyMuleCorrrerlationID(response.get());

        String accessToken = JsonUtils.getJsonValue(response.get().getBody(), "access_token");
        LogUtil.log("AccessToken:" + accessToken);
        responsePayload.set(jsonUtils.get().readTextFileFromPath("AccessTokenGenerationProcessAPI", "accessTokenGenerationExpResponse.txt"));
        responsePayload.set(responsePayload.get().replace("$-{access_token}", accessToken));
        String responseaccessToken = JsonUtils.getJsonValue(responsePayload.get(), "access_token");
        assertThat("Access Token Mismatched!", responseaccessToken.equals(accessToken));
    }

    @Then("Generate Access token Experience API service should get error response with $customizedError")
    public void verifyProcessErrorResponseAccessToken(String customizedError) {
        String ErrorCodemessage = config().getString(customizedError);

        if (customizedError.endsWith("MethodNotAllowed")) {
            cardsSCAService.get().verifyErrorResponseStatusCode(response.get(), customizedError);
            muleService.get().verifyMuleCorrrerlationID(response.get());

        } else {
            cardsSCAService.get().verifyErrorResponseStatusCode(response.get(), customizedError);
            String[] error = ErrorCodemessage.split(":");
            String api = error[0];
            String code = error[1];
            String type = error[2];
            String summary = error[3];
            String description = error[4];
            String errordetail = config().getString(description);
            LogUtil.log(errordetail);


            if (customizedError.endsWith("MissingSourceSystem")) {
                cardsSCAService.get().verifyErrorResponseStatusCode(response.get(), customizedError);
                muleService.get().verifyMuleErrorMessagesAPI(response.get(), endpoint.get(), api, code, type, summary, errordetail);

            }else if (customizedError.endsWith("correlationidnotPassed")) {
                cardsSCAService.get().verifyErrorResponseStatusCode(response.get(), customizedError);
                muleService.get().verifyMuleErrorMessagesAPI(response.get(), endpoint.get(), api, code, type, summary, errordetail);

            } else {

                cardsSCAService.get().verifyErrorResponseStatusCode(response.get(), customizedError);
                muleService.get().verifyMuleCorrrerlationID(response.get());
                muleService.get().verifyMuleErrorMessagesAPI(response.get(), endpoint.get(), api, code, type, summary, errordetail);

            }
        }
    }
    @Given("generate client assertion for $clientId with kid,payload and privatekey")
    public void generateJWS(String clientId) {
        LogUtil.log("client is "+clientId);
        String detachedStatus="False";
        String kid="";
        String privateKey="";
        if(clientId.equals("Broadcom_Credit_ClientId")){
            kid=config().getString("Credit_key_Id");
            privateKey=config().getString("Credit_privateKey");
        }else if (clientId.equals("Broadcom_Debit_ClientId")){
            kid=config().getString("Debit_key_Id");
            privateKey=config().getString("Debit_privateKey");
        }else if (clientId.equals("kidPrivateKeySwap")){
            kid=config().getString("Credit_key_Id");
            privateKey=config().getString("Debit_privateKey");
        }
        LogUtil.log("kid is "+kid);
        LogUtil.log("private key is "+privateKey);
        LogUtil.log("payload is "+accessTokenreqPayload.get().toString());
        String jwsValueForReq=cardsSCAService.get().jwsGeneration(accessTokenreqPayload.get().toString(),kid,privateKey,detachedStatus);
        jwsReq.set(jwsValueForReq);
        muleService.get().setJWS(jwsValueForReq);
        muleService.get().setClientAssertion(jwsValueForReq);
    }

}