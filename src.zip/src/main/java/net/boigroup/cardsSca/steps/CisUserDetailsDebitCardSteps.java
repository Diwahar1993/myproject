package net.boigroup.cardsSca.steps;

import net.boigroup.bdd.framework.LogUtil;
import net.boigroup.bdd.framework.Rest.HttpResponse;
import net.boigroup.bdd.framework.Rest.RequestBuilder;
import net.boigroup.bdd.framework.Rest.RestActions;
import net.boigroup.bdd.framework.StorySteps;
import net.boigroup.cardsSca.service.CardsSCAService;
import net.boigroup.cardsSca.service.ReadXML;
import net.boigroup.cardsSca.service.SystemService;
import org.jbehave.core.annotations.*;

import static net.boigroup.bdd.framework.Asserts.assertThat;
import static net.boigroup.bdd.framework.ConfigLoader.config;
import static net.boigroup.bdd.framework.Rest.matchers.HasStringInContent.hasStringInContent;

@StorySteps
public class CisUserDetailsDebitCardSteps {

    private ThreadLocal<CardsSCAService> cardsSCAService = new ThreadLocal<CardsSCAService>() {
        @Override
        public CardsSCAService initialValue() {
            return new CardsSCAService();
        }
    };

    private ThreadLocal<SystemService> systemService = new ThreadLocal<SystemService>(){
        @Override
        public SystemService initialValue() {
            return new SystemService();
        }
    };

    private ThreadLocal<ReadXML> readXML = new ThreadLocal<ReadXML>(){
        @Override
        public ReadXML initialValue() {
            return new ReadXML();
        }
    };

    ThreadLocal<String> expectedRequest= new ThreadLocal<>()  ;
    public ThreadLocal<HttpResponse> response = new ThreadLocal<HttpResponse>();
    ThreadLocal<String> endpoint= new ThreadLocal<>()  ;

    @Given("User Requesting the Service with Valid Payload has Debit Card Number $debitCardNo")
    public void verifyValidDebitCard(String debitCardNo) {
        systemService.get().verifyValidDebitNo(debitCardNo);
        cardsSCAService.get().setError(null);
        String inputPayload=readXML.get().readXML("CisUserDebitCardRequest","CisUserDebitCard");
        inputPayload=inputPayload.replace("$-{cardNumber}", debitCardNo);
        inputPayload= readXML.get().xmlFormat(inputPayload);
        expectedRequest.set(inputPayload);
        LogUtil.logAttachment("Request Payload: ",expectedRequest.get());
    }

    @Given("User Requesting the Payload with invalid Debit Card Number $debitCardNo")
    public void verifyInValidDebitCard(String debitCardNo) {
        cardsSCAService.get().setError(null);
        String inputPayload=readXML.get().readXML("CisUserDebitCardRequest","CisUserDebitCard");
        inputPayload=inputPayload.replace("$-{cardNumber}", debitCardNo);
        inputPayload= readXML.get().xmlFormat(inputPayload);
        expectedRequest.set(inputPayload);
        LogUtil.logAttachment("Request Payload: ",expectedRequest.get());
    }

    @Given("Get CIS User Details with Debit Card No Service has technical $error")
    public void cisUserHasError(String error) {
        cardsSCAService.get().setError(error);
    }

    @When("Requesting the CIS User Details Service with request Payload")
    public void requestCISUserDetailsDebitCradNo() {
        RequestBuilder request = cardsSCAService.get().defaultRequest();
         endpoint.set(systemService.get().getCISUserWithDebitCardNo());
        String[] inputHeaders = {"RANDOM", "B365", "source_System", "userID"};
        request = cardsSCAService.get().SetFSHeader(request, inputHeaders);
        request.body(expectedRequest.get());
        request = request.contentType("application/xml");
        LogUtil.logAttachment("Request Payload: ",expectedRequest.get());
        response.set(cardsSCAService.get().executePost(request, endpoint.get()));

    }

    @When("I request Debit card API without one or more mandatory headers $headersToAdd")
    public void withoutMandatoryHeader(String headersToAdd) {
        RequestBuilder request = cardsSCAService.get().defaultRequest();
        endpoint.set(systemService.get().getCISUserWithDebitCardNo());
        request = cardsSCAService.get().setHeadersBadUnauthorize(request, headersToAdd);
        request.body(expectedRequest.get());
        request = request.contentType("application/xml");
        LogUtil.logAttachment("Request Payload: ",expectedRequest.get());
        response.set(cardsSCAService.get().executePost(request, endpoint.get()));
    }

    @Then("It should return the suceess response with valid details for $debitCardNo")
    public void VerifysuccessResponseGetCISUser(String debitCardNo ) {
        cardsSCAService.get().verifySucessResponseStatusCode(response.get());
        cardsSCAService.get().verifyCorrrerlationID(response.get());
        String expectedResponse = systemService.get().verifyCIsUserDebitCardResponse(debitCardNo);
        //expectedResponse=readXML.get().xmlFormat(expectedResponse);;
        String actualResponse = response.get().getBody();
        //actualResponse=readXML.get().xmlFormat(actualResponse);
        //actualResponse=actualResponse.replace("<?xml version=\"1.0\" encoding=\"UTF-8\"?>","");

        LogUtil.logAttachment("Expected response is ", expectedResponse);
        LogUtil.logAttachment("Actual response is ", actualResponse);
        assertThat("Unexpected response!", !actualResponse.contains(expectedResponse));

    }

    @Then("It should return the $customizedError response")
    public void verifyErrorResponseCISUsrDebit(String customizedError) {
        String errorMsg = config().getString(customizedError);
        String[] error = errorMsg.split(":");
        String code = error[0];
        String message = error[1];
        cardsSCAService.get().verifyCorrrerlationID(response.get());
        cardsSCAService.get().verifyErrorResponseStatusCode(response.get(), customizedError);
        cardsSCAService.get().verifyValidationViolationErrorResponse(response.get(),code,message);
    }

    @Then("It should return the $customizedError response without correlationID")
    public void verifyErrorResponseCISUsrDebitwithoutCorr(String customizedError) {
        String errorMsg = config().getString(customizedError);
        String[] error = errorMsg.split(":");
        String code = error[0];
        String message = error[1];
        cardsSCAService.get().verifyErrorResponseStatusCode(response.get(), customizedError);
        cardsSCAService.get().verifyValidationViolationErrorResponse(response.get(),code,message);
    }

    @Then("It should return XSD validation $customizedError response with $tagName and $tagValue")
    public void verifyXSDErrorResponseCISUsrDebit(String customizedError, String tagName, String tagValue ) {
        String errorMsg = config().getString(customizedError);
        String[] error = errorMsg.split(":");
        String code = error[0];
        String message = error[1];
        cardsSCAService.get().verifyCorrrerlationID(response.get());
        cardsSCAService.get().verifyErrorResponseStatusCode(response.get(), customizedError);
        cardsSCAService.get().verifyXSDInvalid(response.get(),code,message,tagName,tagValue);
    }


}
