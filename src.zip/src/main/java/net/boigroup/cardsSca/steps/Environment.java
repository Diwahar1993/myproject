package net.boigroup.cardsSca.steps;

import net.boigroup.bdd.framework.LogUtil;
import net.boigroup.bdd.framework.StorySteps;

import static net.boigroup.bdd.framework.ConfigLoader.config;

@StorySteps
public class Environment {

	public void initDataBackup() {
		// setting the endpoint URL
		String env = config().getString("test.environment");
		String uri = config().getString(env + ".uri");
		LogUtil.log("test.environment : ");
		LogUtil.log(uri);
		config().setProperty("rest.base.uri", uri);


		// Reverting the database to test data setup from SQL file
		//new InitService().initaliseDB();
	}
}
