package net.boigroup.cardsSca.steps;

import net.boigroup.bdd.framework.JsonUtils;
import net.boigroup.bdd.framework.LogUtil;
import net.boigroup.bdd.framework.Rest.HttpResponse;
import net.boigroup.bdd.framework.Rest.RequestBuilder;
import net.boigroup.bdd.framework.Rest.RestActions;
import net.boigroup.bdd.framework.StorySteps;
import net.boigroup.cardsSca.dao.CardsSCADao;
import net.boigroup.cardsSca.service.CardsSCAService;
import net.boigroup.cardsSca.service.MuleService;
import net.boigroup.cardsSca.service.ReadXML;
import net.boigroup.cardsSca.service.SystemService;
import org.jbehave.core.annotations.Alias;
import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;

import static net.boigroup.bdd.framework.Asserts.assertThat;
import static net.boigroup.bdd.framework.ConfigLoader.config;

@StorySteps
public class CachingPatchSteps {
    CardsSCADao cardsSCADao = new CardsSCADao();
    private ThreadLocal<String> endpoint = new ThreadLocal<>();
    private ThreadLocal<CardsSCAService> cardsSCAService = new ThreadLocal<CardsSCAService>() {
        @Override
        public CardsSCAService initialValue() {
            return new CardsSCAService();
        }
    };

    ThreadLocal<SystemService> systemService = new ThreadLocal<SystemService>() {
        @Override
        public SystemService initialValue() {
            return new SystemService();
        }


    };
    ThreadLocal<ReadXML> xml = new ThreadLocal<ReadXML>() {
        @Override
        public ReadXML initialValue() {
            return new ReadXML();
        }
    };
    ReadXML readXML = new ReadXML();
    private ThreadLocal<HttpResponse> response = new ThreadLocal<>();
    private ThreadLocal<String> payload = new ThreadLocal<>();
    private ThreadLocal<JsonUtils> json = new ThreadLocal<JsonUtils>() {
        @Override
        public JsonUtils initialValue() {
            return new JsonUtils();
        }
    };
    ThreadLocal<MuleService> muleService = new ThreadLocal<MuleService>() {
        @Override
        public MuleService initialValue() {
            return new MuleService();
        }
    };


    //Patch API

    @Given("User should construct the payload for cache patch for $mappingKeyUpdate")
    public void patchCaching(String mappingKeyUpdate ) {
        String patchPayload="";
        patchPayload = ReadXML.readXlsWithSameTagName(mappingKeyUpdate, "filepath.validateOTP.storedcacheInfo", "filepath.validateOTP.pockRequestTemplate");
        patchPayload = xml.get().jsonFormat(patchPayload);
        payload.set(patchPayload);
        LogUtil.logAttachment("Patch request payload is",payload.get());

    }

    @Given("User should be able to construct the payload for cache patch for $mappingKeyUpdate")
    public void bcReqpatchCaching(String mappingKeyUpdate ) {
        String patchPayload="";
        patchPayload = ReadXML.readXlsWithSameTagName(mappingKeyUpdate, "filepath.validateOTP.storedcacheInfo", "filepath.validateOTP.bc_reqRequestTemplate");
        patchPayload = xml.get().jsonFormat(patchPayload).replace("{status}","pending");;
        payload.set(patchPayload);
        LogUtil.logAttachment("Patch request payload is",payload.get());

    }

    @Given("User is created with pock cache object for $KeyID and domainId $domainId")
    public void storePockInformationinCache(String keyID,String domainId) {
        String patchCache="";
        patchCache = ReadXML.readXlsWithSameTagName(keyID, "filepath.validateOTP.storedcacheInfo", "filepath.validateOTP.pockRequestTemplate");
        patchCache = xml.get().jsonFormat(patchCache);
        LogUtil.logAttachment("Pock_transactionId request payload is",patchCache);
        RequestBuilder request = RestActions.onHTTPUri(config().getString("mule.caching.uri"));
        LogUtil.log(config().getString("mule.caching.uri"));
        endpoint.set(systemService.get().getCachePOSTEndpoint().replace("{domain-id}",domainId));
        request = muleService.get().setMuleHeaders(request);
        request.body(patchCache);
        request.contentType("application/json");
        response.set(cardsSCAService.get().executePut(request, endpoint.get()));
        //LogUtil.logAttachment("Actual Response is" , response.get().getBody());

    }

    @Given("User should be created with bcRequest cache object for $KeyID and domainId $domainId")
    @Alias("User is stored with values for $keyID and domainId $domainId")
    public void storebcRequest(String keyID , String domainId) {
        String bcReqCache="";
        bcReqCache = ReadXML.readXlsWithSameTagName(keyID, "filepath.validateOTP.storedcacheInfo", "filepath.validateOTP.bc_reqRequestTemplate");
        bcReqCache = xml.get().jsonFormat(bcReqCache).replace("{status}","pending");
        payload.set(bcReqCache);
        LogUtil.logAttachment("bcRequest_transactionId request payload is",bcReqCache);
        RequestBuilder request = RestActions.onHTTPUri(config().getString("mule.caching.uri"));
        endpoint.set(systemService.get().getCachePOSTEndpoint().replace("{domain-id}",domainId));
        request = muleService.get().setMuleHeaders(request);
        request.body(bcReqCache);
        request.contentType("application/json");
        response.set(cardsSCAService.get().executePut(request, endpoint.get()));
        //LogUtil.logAttachment("Actual Response is" , response.get().getBody());
    }

    @When("User request Patch API service with $domainId,$keyID and request payload")
    public void patchAPI(String domainId,String keyID) {
        RequestBuilder request = RestActions.onHTTPUri(config().getString("mule.caching.uri"));
        endpoint.set(systemService.get().getpatchCachingEndpoint().replace("{key-id}",keyID).replace("{domain-id}",domainId));
        request = muleService.get().setMuleHeaders(request);
        request.body(payload.get());
        LogUtil.logAttachment("Payload", payload.get());
        request.contentType("application/json");
        response.set(cardsSCAService.get().executePatch(request, endpoint.get()));
        LogUtil.logAttachment("Actual Response is", response.get().getBody());
    }

    @Then ("Retrieve API should hold the updated $tag with $tagValue for $keyID and $domainId")
    public void retrieveCacheAPI (String tag, String tagValue , String keyID,String domainId) {
        RequestBuilder request = RestActions.onHTTPUri(config().getString("mule.caching.uri"));
        endpoint.set(systemService.get().getCacheGETEndpoint().replace("{key-id}",keyID).replace("{domain-id}",domainId));
        request = muleService.get().setMuleHeaders(request);
        response.set(cardsSCAService.get().executeGet(request, endpoint.get()));
        LogUtil.logAttachment("Actual Response is" , response.get().getBody());
        String getCacheResponse=response.get().getBody().toString();
        String tagName = JsonUtils.getJsonValue(getCacheResponse, "value/" +tag);
        LogUtil.log("The Value of " +tag +"is " +tagName);
        LogUtil.log("Expected tagValue is " +tagValue);
        assertThat("value is not updated!", tagName.equals(tagValue));

    }

    @Given("Caching API has technical $error")
    public void setcachingErrorInService(String error) {
        cardsSCAService.get().setError(error);
    }

    @When("I request cachingAPI with $keyID,$domainId provided and without one or more mandatory headers $headersToAdd")
    public void withoutMandatoryHeader(String keyID,String domainId, String headersToAdd) {
        RequestBuilder request = RestActions.onHTTPUri(config().getString("mule.caching.uri"));
        request = muleService.get().setMuleHeadersUnauthorize(request, headersToAdd);
        endpoint.set(systemService.get().getpatchCachingEndpoint().replace("{key-id}", keyID).replace("{domain-id}",domainId));
        response.set(cardsSCAService.get().executePatch(request, endpoint.get()));
    }

    @When("I request PostcachingAPI with $keyID,$domainId provided and without one or more mandatory headers $headersToAdd")
    public void withoutPostMandatoryHeader(String keyID,String domainId, String headersToAdd) {
        RequestBuilder request = RestActions.onHTTPUri(config().getString("mule.caching.uri"));
        request = muleService.get().setMuleHeadersUnauthorize(request, headersToAdd);
        endpoint.set(systemService.get().getCachePOSTEndpoint().replace("{key-id}", keyID).replace("{domain-id}",domainId));
        response.set(cardsSCAService.get().executePut(request, endpoint.get()));
    }

    @When("I request GetcachingAPI with $keyID,$domainId provided and without one or more mandatory headers $headersToAdd")
    public void withoutgetMandatoryHeader(String keyID, String domainId, String headersToAdd) {
        RequestBuilder request = RestActions.onHTTPUri(config().getString("mule.caching.uri"));
        request = muleService.get().setMuleHeadersUnauthorize(request, headersToAdd);
        endpoint.set(systemService.get().getCacheGETEndpoint().replace("{key-id}", keyID).replace("{domain-id}",domainId));
        response.set(cardsSCAService.get().executeGet(request, endpoint.get()));
    }

    @Then("caching API will return error response with $customizedError")
    public void verifyErrorResponse(String customizedError) {
        String ErrorCodemessage = config().getString(customizedError);
        String[] error = ErrorCodemessage.split(":");
        String api = error[0];
        String code = error[1];
        String type = error[2];
        String summary = error[3];
        String description = error[4];
        String errordetail = config().getString(description);
        LogUtil.log(errordetail);
        cardsSCAService.get().verifyErrorResponseStatusCode(response.get(), customizedError);
//        muleService.get().muleVerifyCorrrerlationID(response.get());
        muleService.get().verifyMuleErrorMessagesAPI(response.get(), endpoint.get(), api, code, type, summary, errordetail);
    }

    //Post Cache

    @Given("User should construct the payload for Post cache for $mappingKeyUpdate")
    public void postCaching(String mappingKeyUpdate ) {
        String postPayload="";
        postPayload = ReadXML.readXlsWithSameTagName(mappingKeyUpdate, "filepath.validateOTP.storedcacheInfo", "filepath.validateOTP.pockRequestTemplate");
        postPayload = xml.get().jsonFormat(postPayload);
        payload.set(postPayload);
        LogUtil.logAttachment("Post request payload is",payload.get());

    }

    @Given("User should construct the payload with entryTTL for Post cache for $mappingKeyUpdate")
    public void postCachingWithEntryTTL(String mappingKeyUpdate ) {
        String postPayload="";
        postPayload = ReadXML.readXlsWithSameTagName(mappingKeyUpdate, "filepath.validateOTP.storedcacheInfo", "filepath.validateOTP.pockRequestwithTTLTemplate");
        postPayload = xml.get().jsonFormat(postPayload);
        payload.set(postPayload);
        LogUtil.logAttachment("Post request payload is",payload.get());

    }

    @When("User request Post API service with $keyID,$domainId and request payload")
    public void postAPI(String keyID, String domainId) {
        RequestBuilder request = RestActions.onHTTPUri(config().getString("mule.caching.uri"));
        endpoint.set(systemService.get().getCachePOSTEndpoint().replace("{key-id}" ,keyID).replace("{domain-id}",domainId));
        request = muleService.get().setMuleHeaders(request);
        request.body(payload.get());
        LogUtil.logAttachment("Payload", payload.get());
        request.contentType("application/json");
        response.set(cardsSCAService.get().executePut(request, endpoint.get()));
        //LogUtil.logAttachment("Actual Response is", response.get().getBody());
    }

    @Then("User should be able to get the successful response for $keyID")
    public void verifyPostsuccessResponse() {
        cardsSCAService.get().verifySucessResponseCreatedStatusCode(response.get());
//        cardsSCAService.get().verifyCorrrerlationID(response.get());
    }

    @Then ("User should be able to retrieve the stored value for $keyID and $domainId")
    public void retrieveStoredAPI (String keyID , String domainId) {
        RequestBuilder request = RestActions.onHTTPUri(config().getString("mule.caching.uri"));
        endpoint.set(systemService.get().getCacheGETEndpoint().replace("{key-id}", keyID).replace("{domain-id}",domainId));
        request = muleService.get().setMuleHeaders(request);
        response.set(cardsSCAService.get().executeGet(request, endpoint.get()));
        LogUtil.logAttachment("Actual Response is", response.get().getBody());
        String storedValues = JsonUtils.getJsonValue(payload.get(), "value");
        storedValues = xml.get().jsonFormat(storedValues);
        LogUtil.log("stored values is " + storedValues);
        String getCacheResponse=response.get().getBody().toString();
        getCacheResponse=JsonUtils.getJsonValue(getCacheResponse, "value");
        getCacheResponse=xml.get().jsonFormat(getCacheResponse);
        LogUtil.log("get cache value is " +getCacheResponse);
        assertThat("Unexpected response !", getCacheResponse.equals(storedValues));
    }


    //Get

    @Given ("User has no stroed value for $keyID")
    public void noStoredValue(String keyID){
        LogUtil.log("Given keyID "  +keyID +"has no stored value");
    }

    @When ("I request get cache API for given $keyID and $domainId")
    @Alias("I request get cache API with the same $keyID and $domainId again")
    public void getStoredAPI (String keyID , String domainId) {
        RequestBuilder request = RestActions.onHTTPUri(config().getString("mule.caching.uri"));
        endpoint.set(systemService.get().getCacheGETEndpoint().replace("{key-id}", keyID).replace("{domain-id}",domainId));
        request = muleService.get().setMuleHeaders(request);
        response.set(cardsSCAService.get().executeGet(request, endpoint.get()));
        LogUtil.logAttachment("Actual Response is", response.get().getBody());
        String getCacheResponse=response.get().getBody().toString();

    }




}
