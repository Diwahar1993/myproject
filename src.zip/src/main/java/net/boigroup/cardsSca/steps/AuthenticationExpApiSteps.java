package net.boigroup.cardsSca.steps;

import net.boigroup.bdd.framework.JsonUtils;
import net.boigroup.bdd.framework.LogUtil;
import net.boigroup.bdd.framework.Rest.HttpResponse;
import net.boigroup.bdd.framework.Rest.RequestBuilder;
import net.boigroup.bdd.framework.Rest.RestActions;
import net.boigroup.bdd.framework.StorySteps;
import net.boigroup.bdd.framework.XMLUtils;
import net.boigroup.cardsSca.service.CardsSCAService;
import net.boigroup.cardsSca.service.MuleService;
import net.boigroup.cardsSca.service.ReadXML;
import net.boigroup.cardsSca.service.SystemService;
import org.jbehave.core.annotations.*;

import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.OffsetDateTime;
import java.util.UUID;

import static net.boigroup.bdd.framework.Asserts.assertThat;
import static net.boigroup.bdd.framework.ConfigLoader.config;
import static net.boigroup.bdd.framework.Rest.matchers.HasStringInContent.hasStringInContent;

@StorySteps
public class AuthenticationExpApiSteps {

    private ThreadLocal<CardsSCAService> cardsSCAService = new ThreadLocal<CardsSCAService>() {
        @Override
        public CardsSCAService initialValue() {
            return new CardsSCAService();
        }
    };

    ThreadLocal<MuleService> muleService = new ThreadLocal<MuleService>() {
        @Override
        public MuleService initialValue() {
            return new MuleService();
        }
    };
    private ThreadLocal<ReadXML> readXML = new ThreadLocal<ReadXML>(){
        @Override
        public ReadXML initialValue() {
            return new ReadXML();
        }
    };
    ThreadLocal<SystemService> systemService = new ThreadLocal<SystemService>() {
        @Override
        public SystemService initialValue() {
            return new SystemService();
        }
    };
    ThreadLocal<String> expectedRequest= new ThreadLocal<>()  ;

    public ThreadLocal<HttpResponse> response = new ThreadLocal<HttpResponse>();
    private ThreadLocal<HttpResponse> generateJWSresponse=new ThreadLocal<>();
    private ThreadLocal<String> jwsReq = new ThreadLocal<>();
    private ThreadLocal<String> accessToken = new ThreadLocal<>();
    XMLUtils xmlUtils = new XMLUtils();
    ThreadLocal<String> endpoint= new ThreadLocal<>()  ;
    private ThreadLocal<JsonUtils> json = new ThreadLocal<JsonUtils>() {
        @Override
        public JsonUtils initialValue() {
            return new JsonUtils();
        }
    };
    private ThreadLocal<String> accessTokenreqPayload = new ThreadLocal<>();
   // String transactionId ="";


    @Given("Construct the Valid the Authenticate Experience API $payload with $transactionId")
    public void constructExpAuthenticationPayload(String payload,String transactionId ) {
        cardsSCAService.get().setError(null);
        String currentRequestTimestamp = cardsSCAService.get().dateTimeStampConverison();
         //transactionId=UUID.randomUUID().toString();
        String requestPayload = readXML.get().readXlsWithSameTagName(payload, "Exp.Authentication.Request.xls", "Exp.Authentication.request");
        requestPayload= requestPayload.replace("{requestTimestamp}",currentRequestTimestamp);
        expectedRequest.set(readXML.get().jsonFormat(requestPayload));
        LogUtil.logAttachment("Request Payload is",expectedRequest.get());
    }
    //generate JWS call
    @Given("generate $detached JWS for authentication request payload for client $client")
    public void generateJWS(String status,String client) {
        String detachedStatus="false";
        String kid="";
        String privateKey="";
        if(status.equals("detached")){
            detachedStatus="true";
        }
        if(client.equals("credit")){
            kid=config().getString("Credit_key_Id");
            privateKey=config().getString("Credit_privateKey");
        }else if (client.equals("debit")){
            kid=config().getString("Debit_key_Id");
            privateKey=config().getString("Debit_privateKey");
        }else if (client.equals("kidPrivateKeySwap")){
            kid=config().getString("Credit_key_Id");
            privateKey=config().getString("Debit_privateKey");
        }
        String jwsValueForReq=cardsSCAService.get().jwsGeneration(expectedRequest.get().toString(),kid,privateKey,detachedStatus);
        jwsReq.set(jwsValueForReq);
        muleService.get().setJWS(jwsValueForReq);
    }
    //verify jws in response
    @Then("jws returned in authenticationResponse should be verified successfully")
    public void verifyJWSResponse() {
        String responseJws=cardsSCAService.get().getJWS(response.get());
        LogUtil.log("jws returned in response is \n"+responseJws);
        cardsSCAService.get().jwsVerification(responseJws,response.get().getBody());


    }
    //Access Token Generation
    @Given ("generate access Token for authentication request with valid $clientId and $client_assertion")
    public void generateAceessToken(String clientId,String client_assertion){
        clientId =config().getString(clientId);
        client_assertion =config().getString(client_assertion);
        RequestBuilder request = RestActions.onHTTPUri(config().getString("experience.uri"));
        endpoint.set(systemService.get().getAccessTokenGenerationExpAPIEndpoint());
        request= muleService.get().setAccessTokenRequest(request,clientId,client_assertion);
        request.contentType("application/x-www-form-urlencoded");
        request = muleService.get().setExperienceAPIAuthHeaders(request,clientId);
        response.set(cardsSCAService.get().executePost(request, endpoint.get()));
        LogUtil.logAttachment("Actual Response is ", response.get().getBody());
        String accesstoken = JsonUtils.getJsonValue(response.get().getBody(), "access_token");
        LogUtil.log("access token is "+accesstoken);
        accessToken.set("Bearer"+" "+accesstoken);
        muleService.get().setClientAssertion(accessToken.get());
        muleService.get().setClientId(clientId);

    }
    @Given("Authenticate Experience API has technical $error")
    public void setErrorInService(String error) {
        cardsSCAService.get().setError(error);
    }

    @Given("User request the Authentication Experience API with $payload without tags $tagValueRemoved")
    public void requestAuthenExpAPI(String payload,String tagValueRemoved) {
        cardsSCAService.get().setError(null);
        String currentRequestTimestamp = cardsSCAService.get().dateTimeStampConverison();
       // transactionId=UUID.randomUUID().toString();
        String requestPayload = readXML.get().readXlsWithSameTagName(payload, "Exp.Authentication.Request.xls", "Exp.Authentication.request");
        requestPayload= requestPayload.replace("{requestTimestamp}",currentRequestTimestamp);
        //String valueRemove=JsonUtils.getJsonValue(requestPayload, tagValueRemoved);
        requestPayload=readXML.get().newRemoveJsontagByTagName(requestPayload,tagValueRemoved);
        requestPayload =readXML.get().jsonFormat(requestPayload);

        expectedRequest.set(requestPayload);
        LogUtil.logAttachment ("Authentication Request Payload : ", expectedRequest.get());

        }


    @When("Requesting the Authenticate Experience API with valid payload with $client_id")
    public void requestAuthenticationExpApi(String client_id ) {
        client_id =config().getString(client_id);
        RequestBuilder request = RestActions.onHTTPUri(config().getString("experience.uri"));
        endpoint.set(systemService.get().getExpAuthenticationEndpoint());
        request = muleService.get().setExperienceAPIAuthHeaders(request,client_id,accessToken.get(),jwsReq.get());
        request.body(expectedRequest.get());
        request.contentType("application/json");
        response.set(cardsSCAService.get().executePost(request, endpoint.get()));
        LogUtil.logAttachment("Actual Response is" , response.get().getBody());

    }
    @When("Requesting the Authenticate Experience API with valid $client_id with other than Post Method")
    public void requestAuthenticationExpApiGetmethod(String client_id) {
        client_id =config().getString(client_id);
        RequestBuilder request = RestActions.onHTTPUri(config().getString("experience.uri"));
        endpoint.set(systemService.get().getExpAuthenticationEndpoint());
        request = muleService.get().setExperienceAPIAuthHeaders(request,client_id,accessToken.get(),jwsReq.get());
        request.body(expectedRequest.get());
        request.contentType("application/json");
        response.set(cardsSCAService.get().executeGet(request, endpoint.get()));
        LogUtil.logAttachment("Actual Response is" , response.get().getBody());

    }

    @When("Requesting the Authenticate Experience API without without one or more mandatory headers $headersToAdd")
    public void requestAuthenticationExpApiWithoutMandatoryHeader(String headersToAdd) {
        RequestBuilder request = RestActions.onHTTPUri(config().getString("experience.uri"));
        endpoint.set(systemService.get().getExpAuthenticationEndpoint());
        request = muleService.get().setMuleHeadersUnauthorize(request, headersToAdd);
        request.body(expectedRequest.get());
        request.contentType("application/json");
        response.set(cardsSCAService.get().executePost(request, endpoint.get()));
        LogUtil.logAttachment("Actual Response is" , response.get().getBody());
    }

    @Then("Authenticate Experience API should return the suceess response with respective $token details")
    public void verifySuccessExpAuthenticate(String token) {
        cardsSCAService.get().verifySucessResponseStatusCode(response.get());
        muleService.get().muleVerifyCorrrerlationID(response.get());
        String actualResponse=response.get().getBody();
        if (token.equalsIgnoreCase("HARD_TOKEN")) {
            String transactionIdResponse = JsonUtils.getJsonValue(actualResponse, "transaction/identifier/transactionId");
           // assertThat("Transaction Id Mismatched!",transactionIdResponse.equalsIgnoreCase(transactionId));
            String deviceTypeResponse = JsonUtils.getJsonValue(actualResponse, "device/general/authenticationType");
            assertThat("Device Type Mismatched!",deviceTypeResponse.equalsIgnoreCase(token));
            String authenticationInputCode = JsonUtils.getJsonValue(actualResponse, "device/general/authenticationInputCode");

        }if (token.equalsIgnoreCase("MOBILE_APP")) {
            String transactionIdResponse = JsonUtils.getJsonValue(actualResponse, "transaction/identifier/transactionId");
          //  assertThat("Transaction Id Mismatched!",transactionIdResponse.equalsIgnoreCase(transactionId));
            String alternativeName = JsonUtils.getJsonValue(actualResponse, "device/identifier/alternativeName");
            String deviceTypeResponse = JsonUtils.getJsonValue(actualResponse, "device/general/authenticationType");
            assertThat("Device Type Mismatched!",deviceTypeResponse.equalsIgnoreCase(token));

        }
        if (token.equalsIgnoreCase("NOT_REGISTERED")) {
            String transactionIdResponse = JsonUtils.getJsonValue(actualResponse, "transaction/identifier/transactionId");
            //assertThat("Transaction Id Mismatched!",transactionIdResponse.equalsIgnoreCase(transactionId));
        }
        LogUtil.logAttachment("Actual Response",actualResponse);
           }


    @Then("Authentication Experience API will return error response with $customizedError")
    public void verifyErrorResponse(String customizedError) {
        if (customizedError.endsWith("misisngClientId")) {
            cardsSCAService.get().verifyErrorResponseStatusCode(response.get(), customizedError);
            assertThat("incorrect Error Response",response.get().getBody().contains("Authentication denied."));
        } else {
            String ErrorCodemessage = config().getString(customizedError);
            String[] error = ErrorCodemessage.split(":");
            String api = error[0];
            String code = error[1];
            String type = error[2];
            String summary = error[3];
            String description = error[4];
            String errordetail = config().getString(description);
            LogUtil.log(errordetail);
            cardsSCAService.get().verifyErrorResponseStatusCode(response.get(), customizedError);
            muleService.get().muleVerifyCorrrerlationID(response.get());
            muleService.get().verifyMuleErrorMessagesAPI(response.get(), endpoint.get(), api, code, type, summary, errordetail);
        }
    }
    @Given("generate client_assertion for $clientId with kid,payload and privatekey")
    public void generateJWS(String clientId) {
        LogUtil.log("client is "+clientId);
        String detachedStatus="False";
        String kid="";
        String privateKey="";
        if(clientId.equals("Broadcom_Credit_ClientId")){
            kid=config().getString("Credit_key_Id");
            privateKey=config().getString("Credit_privateKey");
        }else if (clientId.equals("Broadcom_Debit_ClientId")){
            kid=config().getString("Debit_key_Id");
            privateKey=config().getString("Debit_privateKey");
        }else if (clientId.equals("kidPrivateKeySwap")){
            kid=config().getString("Credit_key_Id");
            privateKey=config().getString("Debit_privateKey");
        }
        LogUtil.log("kid is "+kid);
        LogUtil.log("private key is "+privateKey);
        LogUtil.log("payload is "+accessTokenreqPayload.get().toString());
        String jwsValueForReq=cardsSCAService.get().jwsGeneration(accessTokenreqPayload.get().toString(),kid,privateKey,detachedStatus);
        jwsReq.set(jwsValueForReq);
        muleService.get().setJWS(jwsValueForReq);
        muleService.get().setClientAssertion(jwsValueForReq);
    }

    @Given("User Requesting the GenerateAccessToken Experience API")
    public void constructRequestPayload() {
        cardsSCAService.get().setError(null);
        long IAT = Instant.now().getEpochSecond();
        LogUtil.log("current time in Unix "+IAT);
        String unixTime = Long.toString(IAT);
        String accessTokenPayload=json.get().readTextFileFromPath("AccessToken", "accessTokenPayloadTemp.txt").replace("{time}",unixTime);
        accessTokenreqPayload.set(accessTokenPayload);
        LogUtil.log("payload is "+accessTokenreqPayload.get());
        LogUtil.logAttachment("the accesstoken payload is ",accessTokenPayload);

    }
    @Given("I request GenerateAccessToken Experience API with valid $clientId and $client_assertion")
    public void requestTokenGenerationService(String clientId,String client_assertion) {
        clientId =config().getString(clientId);
        client_assertion =jwsReq.get();
        LogUtil.log(client_assertion);
        RequestBuilder request = RestActions.onHTTPUri(config().getString("experience.uri"));
        endpoint.set(systemService.get().getAccessTokenGenerationExpAPIEndpoint());
        LogUtil.log("************ header below*******");
        request= muleService.get().setAccessTokenRequest(request,clientId,client_assertion);
        request.contentType("application/x-www-form-urlencoded");
        request = muleService.get().setExperienceAPIAuthHeaders(request,clientId);
        response.set(cardsSCAService.get().executePost(request, endpoint.get()));
        LogUtil.logAttachment("Actual Response is ", response.get().getBody());
        LogUtil.logAttachment("Actual Response is ", response.get().getBody());
        String accesstoken = JsonUtils.getJsonValue(response.get().getBody(), "access_token");
        LogUtil.log("access token is "+accesstoken);
        accessToken.set("Bearer"+" "+accesstoken);
        muleService.get().setClientAssertion(accessToken.get());
        muleService.get().setClientId(clientId);
    }
}

