package net.boigroup.cardsSca.steps;

import net.boigroup.bdd.framework.JsonUtils;
import net.boigroup.bdd.framework.LogUtil;
import net.boigroup.bdd.framework.Rest.HttpResponse;
import net.boigroup.bdd.framework.Rest.RequestBuilder;
import net.boigroup.bdd.framework.Rest.RestActions;
import net.boigroup.bdd.framework.StorySteps;
import net.boigroup.cardsSca.service.*;
import org.jbehave.core.annotations.Alias;
import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import sun.rmi.runtime.Log;

import static net.boigroup.bdd.framework.Asserts.assertThat;
import static net.boigroup.bdd.framework.ConfigLoader.config;


@StorySteps
public class OCSPSystemAPISteps {
    ThreadLocal<CardsSCAService> cardsSCAService = new ThreadLocal<CardsSCAService>() {
        @Override
        public CardsSCAService initialValue() {
            return new CardsSCAService();
        }
    };
    ThreadLocal<MuleService> muleService = new ThreadLocal<MuleService>() {
        @Override
        public MuleService initialValue() {
            return new MuleService();
        }
    };
    ThreadLocal<SystemService> systemService = new ThreadLocal<SystemService>() {
        @Override
        public SystemService initialValue() {
            return new SystemService();
        }
    };
    ThreadLocal<ReadXML> xml = new ThreadLocal<ReadXML>() {
        @Override
        public ReadXML initialValue() {
            return new ReadXML();
        }
    };
    ThreadLocal<JsonUtils> jsonUtils = new ThreadLocal<JsonUtils>() {
        @Override
        public JsonUtils initialValue() {
            return new JsonUtils();
        }
    };
    public ThreadLocal<HttpResponse> response = new ThreadLocal<HttpResponse>();
    private ThreadLocal<String> endpoint = new ThreadLocal<>();
    private ThreadLocal<String> requestPayload = new ThreadLocal<>();
    public ThreadLocal<String> responsePayload = new ThreadLocal<>();

    @Given("construct OCSP payload with valid certificate details $cert_id,$responder_url and $version")
    public void constructRequestPayloadOCSP(String certId, String responderUrl, String Version) {
        cardsSCAService.get().setError(null);
        certId = config().getString(certId);
        responderUrl = config().getString(responderUrl);
        requestPayload.set(jsonUtils.get().readTextFileFromPath("OCSP", "OCSPSystemReq.txt"));
        LogUtil.log(requestPayload.get());
        requestPayload.set(requestPayload.get().replace("{cert_id}", certId).replace("{responder_url}", responderUrl));
        requestPayload.set(xml.get().jsonFormat(requestPayload.get()));
        LogUtil.logAttachment("OCSP System API request Payload", requestPayload.get());
    }
    @Given("OCSP System API has technical $error")
    public void setErrorInService(String error) {
        cardsSCAService.get().setError(error);

    }
    @When("I request OCSP System API")
    public void requestOCSPSystemAPI() {
        RequestBuilder request = RestActions.onHTTPUri(config().getString("mule.caching.uri"));
        request = muleService.get().setMuleHeaders(request);
        endpoint.set(systemService.get().getOCSPSystemAPIEndpoint());
        request.body(requestPayload.get());
        request.contentType("application/json");
        response.set(cardsSCAService.get().executePost(request, endpoint.get()));
        LogUtil.logAttachment("Actual Response is" , response.get().getBody());
    }
    @Given("User Requesting OCSP System API without passing $tagValueRemoved parameters for $cert_id and $responderUrl")
    public void requestPayloadOCSPWithoutMandatory(String tagValueRemoved, String certId, String responderUrl) {
        cardsSCAService.get().setError(null);
        certId = config().getString(certId);
        responderUrl = config().getString(responderUrl);
        requestPayload.set(jsonUtils.get().readTextFileFromPath("OCSP", "OCSPSystemReq.txt"));
        requestPayload.set(requestPayload.get().replace("{cert_id}", certId).replace("{responder_url}", responderUrl));
        requestPayload.set(xml.get().jsonFormat(requestPayload.get()));
        requestPayload.set(xml.get().newRemoveJsontagByTagName1(requestPayload.get(), tagValueRemoved));
        requestPayload.set(xml.get().jsonFormat(requestPayload.get()));
        LogUtil.logAttachment("OCSP System API", requestPayload.get());
    }
    @When("I request OCSP System API without one or more mandatory headers $headersToAdd")
    public void requestOCSPServiceWithoutHeader(String headersToAdd) {
        RequestBuilder request = RestActions.onHTTPUri(config().getString("mule.caching.uri"));
        request = muleService.get().setMuleHeadersUnauthorize(request, headersToAdd);
        endpoint.set(systemService.get().getOCSPSystemAPIEndpoint());
        request.body(requestPayload.get());
        request.contentType("application/json");
        response.set(cardsSCAService.get().executePost(request, endpoint.get()));
        LogUtil.logAttachment("Actual Response is ", response.get().getBody());
    }
    @Then("OCSP System API should validate certificate details successfully with proper certificate status $status")
    public void verifySuccessresponseOCSPProcess(String ocsp_status) {
        cardsSCAService.get().verifySucessResponseStatusCode(response.get());
        muleService.get().muleVerifyCorrrerlationID(response.get());
        String Actualocsp_status = JsonUtils.getJsonValue(response.get().getBody(), "ocsp_response");
        assertThat("Invalid OCSPStatus!", Actualocsp_status.equals(ocsp_status));
    }
    @Then("Generate OCSP System API service should get error response with $customizedError")

    public void verifyProcessErrorResponseOCSP(String customizedError) {
        String errorCodemessage = config().getString(customizedError);

        if (customizedError.endsWith("invalidMethod")) {
            cardsSCAService.get().verifyErrorResponseStatusCode(response.get(), customizedError);
            muleService.get().muleVerifyCorrrerlationID(response.get());

        } else {
            cardsSCAService.get().verifyErrorResponseStatusCode(response.get(), customizedError);
            String[] error = errorCodemessage.split(":");
            String api = error[0];
            String code = error[1];
            String type = error[2];
            String summary = error[3];
            String description = error[4];
            String errordetail = config().getString(description);
            cardsSCAService.get().verifyErrorResponseStatusCode(response.get(), customizedError);
            muleService.get().muleVerifyCorrrerlationID(response.get());
            muleService.get().verifyMuleErrorMessagesAPI(response.get(), endpoint.get(), api, code, type, summary, errordetail);

        }
    }
    @When("I request the OCSP System API with Incorrect ContentType")
    public void requestOCSPIncorrectContent() {
        RequestBuilder request = RestActions.onHTTPUri(config().getString("mule.caching.uri"));
        request = muleService.get().setMuleHeaders(request);
        endpoint.set(systemService.get().getOCSPSystemAPIEndpoint());
        request.body(requestPayload.get());
        request.contentType("application/xml");
        response.set(cardsSCAService.get().executePost(request, endpoint.get()));
        LogUtil.logAttachment("Actual Response is" , response.get().getBody());
    }
    @When("I request OCSP System API with Incorrect Method")
    public void requestOCSPinCorrectmethod() {
        RequestBuilder request = RestActions.onHTTPUri(config().getString("mule.caching.uri"));
        request = muleService.get().setMuleHeaders(request);
        endpoint.set(systemService.get().getOCSPSystemAPIEndpoint());
        request.body(requestPayload.get());
        request.contentType("application/json");
        response.set(cardsSCAService.get().executePut(request, endpoint.get()));
        LogUtil.logAttachment("Actual Response is" , response.get().getBody());
    }
}