package net.boigroup.cardsSca.steps;

import net.boigroup.bdd.framework.JsonUtils;
import net.boigroup.bdd.framework.LogUtil;
import net.boigroup.bdd.framework.Rest.HttpResponse;
import net.boigroup.bdd.framework.Rest.RequestBuilder;
import net.boigroup.bdd.framework.Rest.RestActions;
import net.boigroup.bdd.framework.StorySteps;
import net.boigroup.cardsSca.service.CardsSCAService;
import net.boigroup.cardsSca.service.MuleService;
import net.boigroup.cardsSca.service.ReadXML;
import net.boigroup.cardsSca.service.SystemService;
import org.jbehave.core.annotations.Alias;
import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;

import java.io.InputStream;

import static net.boigroup.bdd.framework.Asserts.assertThat;
import static net.boigroup.bdd.framework.ConfigLoader.config;
import static net.boigroup.cardsSca.service.Constants.*;
import static net.boigroup.cardsSca.service.Constants.CLIENT_ID;
import static net.boigroup.cardsSca.service.Constants.CLIENT_SECRET;


@StorySteps
public class AccessTokenGenerationSystemAPISteps {
    ThreadLocal<CardsSCAService> cardsSCAService = new ThreadLocal<CardsSCAService>() {
        @Override
        public CardsSCAService initialValue() {
            return new CardsSCAService();
        }
    };
    ThreadLocal<MuleService> muleService = new ThreadLocal<MuleService>() {
        @Override
        public MuleService initialValue() {
            return new MuleService();
        }
    };
    ThreadLocal<SystemService> systemService = new ThreadLocal<SystemService>() {
        @Override
        public SystemService initialValue() {
            return new SystemService();
        }
    };
    ThreadLocal<ReadXML> xml = new ThreadLocal<ReadXML>() {
        @Override
        public ReadXML initialValue() {
            return new ReadXML();
        }
    };
    ThreadLocal<JsonUtils> jsonUtils = new ThreadLocal<JsonUtils>() {
        @Override
        public JsonUtils initialValue() {
            return new JsonUtils();
        }
    };
    public ThreadLocal<HttpResponse> response = new ThreadLocal<HttpResponse>();
    private ThreadLocal<String> endpoint = new ThreadLocal<>();
    private ThreadLocal<String> requestPayload = new ThreadLocal<>();
    public ThreadLocal<String> responsePayload = new ThreadLocal<>();
    String accessToken ="";

    @Given("User Requesting System API Generate Access Token API")
    public void constructRequestPayload(){
        cardsSCAService.get().setError(null);
    }

    @Given("Generate Access Token System API has technical $error")

    public void setErrorInService(String error) {
        cardsSCAService.get().setError(error);

    }

    @When("I request the Generate Access Token System API with valid $clientId and $clientSecretId")
    public void requestTokenGenerationService(String clientId,String clientSecretId) {
        clientId =config().getString(clientId);
        clientSecretId =config().getString(clientSecretId);
        RequestBuilder request = RestActions.onHTTPUri(config().getString("sys.accessToken.uri"));
        endpoint.set(systemService.get().getAccessTokenGenerationSystemAPIEndpoint());
        request= muleService.get().setAccessTokenSystemRequest(request,clientId,clientSecretId);
        request.contentType("application/x-www-form-urlencoded");
        response.set(cardsSCAService.get().executePost(request, endpoint.get()));
        LogUtil.logAttachment("Actual Response is ", response.get().getBody());
    }
    @When("I request the Generate Access Token System API without header Parameter along with $clientSecretId and $clientId")
    public void requestTokenGenerationServicewithoutHeader(String clientSecretId,String clientId) {
        clientId =config().getString(clientId);
        clientSecretId =config().getString(clientSecretId);
        RequestBuilder request = RestActions.onHTTPUri(config().getString("sys.accessToken.uri"));
        endpoint.set(systemService.get().getAccessTokenGenerationSystemAPIEndpoint());
        request= muleService.get().setAccessTokenSystemRequest(request,clientId,clientSecretId);
        request.contentType("");
        response.set(cardsSCAService.get().executePost(request, endpoint.get()));
        LogUtil.logAttachment("Actual Response is ", response.get().getBody());
    }

    @When("I request the  Access Token System API with valid $clientId and $clientSecretId and $removeTags")
    public void requestTokenGenerationServicewithoutMandtory(String clientId,String clientSecretId,String removeTags ) {
        clientId =config().getString(clientId);
        clientSecretId =config().getString(clientSecretId);
        RequestBuilder request = RestActions.onHTTPUri(config().getString("sys.accessToken.uri"));
        endpoint.set(systemService.get().getAccessTokenGenerationSystemAPIEndpoint());
        request= muleService.get().setAccessTokenRequest(request,clientId,clientSecretId,removeTags);
        LogUtil.log("Request Passed :"+request.toString());
        request.contentType("application/x-www-form-urlencoded");
        response.set(cardsSCAService.get().executePost(request, endpoint.get()));
        LogUtil.logAttachment("Actual Response is ", response.get().getBody());
    }

    @Then("I should get success response with valid access token")
    public void verifySuccessResponse() {
        cardsSCAService.get().verifySucessResponseStatusCode(response.get());
         accessToken = JsonUtils.getJsonValue(response.get().getBody(), "access_token");
        LogUtil.log("AccessToken:" + accessToken);
        responsePayload.set(jsonUtils.get().readTextFileFromPath("AccessTokenGenerationSystemAPI","accessTokenGenerationResponse.txt"));
        responsePayload.set(responsePayload.get().replace("$-{access_token}",accessToken));
        String responseaccessToken = JsonUtils.getJsonValue(responsePayload.get(), "access_token");
        assertThat("Access Token Mismatched!",responseaccessToken.equals(accessToken));
    }

    @Then("Generate Access token service should get error response with $customizedError")
    public void verifyErrorResponse(String customizedError) {
        cardsSCAService.get().verifyErrorResponseStatusCode(response.get(), customizedError);
        String ErrorCodemessage = config().getString(customizedError);
        String[] errors = ErrorCodemessage.split("%");
        String error_description = errors[0];
        String error = errors[1];
        muleService.get().verifyAccessTokenErrorMessagesAPI(response.get(),error_description,error);

    }

    @Given("User Requesting System API  generate Access Token API to get the Access Token with valid $clientId and $clientSecretId")
    public void requestSystemAPIAccessToken(String clientId,String clientSecretId ){
        cardsSCAService.get().setError(null);
        clientId =config().getString(clientId);
        clientSecretId =config().getString(clientSecretId);
        RequestBuilder request = RestActions.onHTTPUri(config().getString("sys.accessToken.uri"));
        endpoint.set(systemService.get().getAccessTokenGenerationSystemAPIEndpoint());
        request= muleService.get().setAccessTokenRequest(request,clientId,clientSecretId);
        request.contentType("application/x-www-form-urlencoded");
        response.set(cardsSCAService.get().executePost(request, endpoint.get()));
        LogUtil.logAttachment("Actual Response is ", response.get().getBody());
        cardsSCAService.get().verifySucessResponseStatusCode(response.get());
         accessToken = JsonUtils.getJsonValue(response.get().getBody(), "access_token");
        LogUtil.log("AccessToken:" + accessToken);
        }
 @Given ("Request the Validate Access Token API after expiry time")
        public void waitStillExpires() throws InterruptedException {
        Thread.sleep(180000);
 }
    @When("I request the Validate Access Token System API with $type accessToken")
    public void requestValidateAccessToken(String type) {
          RequestBuilder request = RestActions.onHTTPUri(config().getString("sys.accessToken.uri"));
        endpoint.set(systemService.get().validateAccessTokenSystemAPIEndpoint());
        if(type.equalsIgnoreCase("valid")) {
            request.header(AUTHORIZATION, "Bearer " + accessToken);
        }
        else{
            request.header(AUTHORIZATION, "Bearer " + accessToken+"123");
            accessToken=accessToken+"123";
        }
        response.set(cardsSCAService.get().executePost(request, endpoint.get()));
        LogUtil.logAttachment("Actual Response is ", response.get().getBody());
    }
    @When("I request the Validate Access Token Process API with $type accessToken")
    public void requestValidateAccessTokenProcessAPI(String type) {
        RequestBuilder request = RestActions.onHTTPUri(config().getString("process.accessToken.uri"));
        endpoint.set(systemService.get().validateAccessTokenProcessAPIEndpoint());
        request = muleService.get().setMuleHeaders(request);
        request.contentType("application/x-www-form-urlencoded");
        if(type.equalsIgnoreCase("valid")) {
            request= muleService.get().setTokenValidationRequest(request,accessToken);
        }
        else{
            request= muleService.get().setTokenValidationRequest(request,accessToken+"123");
        }
        response.set(cardsSCAService.get().executePost(request, endpoint.get()));
        LogUtil.logAttachment("Actual Response is ", response.get().getBody());
    }

    @Then("Access token should be validated and return Success Response")
    public void verifyValidateSuccessResponse() {
        String clientId ="";
        cardsSCAService.get().verifySucessResponseStatusCode(response.get());
       String expiresIn = JsonUtils.getJsonValue(response.get().getBody(), "expires_in");
         clientId = JsonUtils.getJsonValue(response.get().getBody(), "client_id");

        LogUtil.log("Expires In:" + expiresIn);
        LogUtil.log("Client ID:" + clientId);

        responsePayload.set(jsonUtils.get().readTextFileFromPath("AccessTokenGenerationSystemAPI","accessTokenValidateResponse.txt"));
        responsePayload.set(responsePayload.get().replace("$-{expires_in}",expiresIn).replace("$-{client_id}",clientId));
        responsePayload.set(xml.get().jsonFormat(responsePayload.get()));
       LogUtil.logAttachment(" Expected Response :",responsePayload.get());
         }
    @Then("Access token Process should be validated and return Success Response")
    public void verifyValidateTokenSuccessResponse() {
        String clientId ="";
        cardsSCAService.get().verifySucessResponseStatusCode(response.get());
        String expiresIn = JsonUtils.getJsonValue(response.get().getBody(), "expires_in");
        clientId = JsonUtils.getJsonValue(response.get().getBody(), "client_id");
        clientId = JsonUtils.getJsonValue(response.get().getBody(), "scope");
        LogUtil.log("Expires In:" + expiresIn);
        LogUtil.log("Client ID:" + clientId);

    }

    @Then("Validate Access token should be return with error response")
    public void verifyValidateErrorResponse() {
        cardsSCAService.get().verifyErrorResponseStatusCode(response.get(), "Unauthorized");
        responsePayload.set(jsonUtils.get().readTextFileFromPath("AccessTokenGenerationSystemAPI","accessTokenValidationErrorResponse.txt"));

        responsePayload.set(responsePayload.get().replace("$-{access_token}",accessToken));
        LogUtil.logAttachment("Actual Response is ", response.get().getBody());
        LogUtil.logAttachment("Expected Response is ", responsePayload.get());
        responsePayload.set(xml.get().jsonFormat(responsePayload.get()));
assertThat("Response Mismatched", response.get().getBody().contains(responsePayload.get()));
    }
    @Then("validateAccessToken Process API service should get error response with $customizedError")

    public void verifyProcessErrorResponseOCSP(String customizedError) {
        String errorCodemessage = config().getString(customizedError);

        if (customizedError.endsWith("invalidMethod")) {
            cardsSCAService.get().verifyErrorResponseStatusCode(response.get(), customizedError);
            muleService.get().muleVerifyCorrrerlationID(response.get());

        } else {
            cardsSCAService.get().verifyErrorResponseStatusCode(response.get(), customizedError);
            String[] error = errorCodemessage.split(":");
            String api = error[0];
            String code = error[1];
            String type = error[2];
            String summary = error[3];
            String description = error[4];
            String errordetail = config().getString(description);
            cardsSCAService.get().verifyErrorResponseStatusCode(response.get(), customizedError);
            muleService.get().muleVerifyCorrrerlationID(response.get());
            muleService.get().verifyMuleErrorMessagesAPI(response.get(), endpoint.get(), api, code, type, summary, errordetail);

        }
    }

}

