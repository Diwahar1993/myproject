package net.boigroup.cardsSca.steps;

import net.boigroup.bdd.framework.LogUtil;
import net.boigroup.bdd.framework.Rest.HttpResponse;
import net.boigroup.bdd.framework.Rest.RequestBuilder;
import net.boigroup.bdd.framework.Rest.RestActions;
import net.boigroup.bdd.framework.StorySteps;
import net.boigroup.cardsSca.dao.CardsSCADao;
import net.boigroup.cardsSca.service.CardsSCAService;
import net.boigroup.cardsSca.service.ReadXML;
import net.boigroup.cardsSca.service.SystemService;
import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;

import static net.boigroup.bdd.framework.Asserts.assertThat;
import static net.boigroup.bdd.framework.ConfigLoader.config;

@StorySteps
public class CreditCardRetrieveSteps {
	CardsSCADao cardsSCADao = new CardsSCADao();
	private ThreadLocal<String> endpoint = new ThreadLocal<>();
	private ThreadLocal<CardsSCAService> cardsSCAService = new ThreadLocal<net.boigroup.cardsSca.service.CardsSCAService>() {
		@Override
		public net.boigroup.cardsSca.service.CardsSCAService initialValue() {
			return new CardsSCAService();
		}
	};

	ThreadLocal<SystemService> systemService = new ThreadLocal<SystemService>() {
		@Override
		public SystemService initialValue() {
			return new SystemService();
		}


	};
	ReadXML readXML = new ReadXML();
	private ThreadLocal<HttpResponse> response = new ThreadLocal<>();
	private ThreadLocal<String> payload = new ThreadLocal<>();


	@Given("Construct the payload with $CreditcardNumber present in CHANNEL_USER table")
	public void ConstructcreditcardNumber(String creditcardNumber) {
		payload.set(systemService.get().get365CreditPayload(creditcardNumber));
		LogUtil.logAttachment("Expected Payload is ", payload.get().toString());
	}

	@When("I request to retrive the channel USer details API by $CreditcardNumber")
	public void requestingCreditcardNumberUserDetails(String creditcardNumber) {
		RequestBuilder request = RestActions.onDefaultUri();
		endpoint.set(systemService.get().getCreditCardumberEndpoint());
		request = cardsSCAService.get().setHeaders(request);
		request.body(payload.get());
		request.contentType("application/xml");
		response.set(cardsSCAService.get().executePost(request, endpoint.get()));

	}

	@Then("I should get user Details as successful response for $CreditcardNumber")
	public void verifyCreditcardNumber_SuccessResponse(String creditcardNumber) {
		String expectedResponse = systemService.get().get365UserinfoByCreditcardNumber(creditcardNumber);
		String actualResponse = response.get().getBody().toString();
		expectedResponse=readXML.xmlFormat(expectedResponse);
		actualResponse=readXML.xmlFormat(actualResponse);
		LogUtil.logAttachment("Expected response is ", expectedResponse);
		LogUtil.logAttachment("Actual response is ", actualResponse);
		assertThat("Unexpected response !", actualResponse.equals(expectedResponse));
		cardsSCAService.get().verifySucessResponseStatusCode(response.get());
		cardsSCAService.get().verifyCorrrerlationID(response.get());


	}

	@Given("Retrieve user details by CreditcardNumber service has technical $error")
	public void setErroronCreditcardNumber(String error) {
		cardsSCAService.get().setError(error);
	}

	@Then("I should get error response from CreditcardNumber service with $CustomizedError")
	public void verifyErrorCreditCard(String CustomizedError) {
		String errorVal = config().getString(CustomizedError);
		String[] error = errorVal.split(":");
		String code = error[0];
		String message = error[1];
		cardsSCAService.get().verifyCorrrerlationID(response.get());
		cardsSCAService.get().verifyErrorResponseStatusCode(response.get(), CustomizedError);
		cardsSCAService.get().verifyValidationViolationErrorResponse(response.get(), code, message);

	}

	@Then("I should get proper error response from CreditcardNumber service with $CustomizedError")
	public void verifyError(String CustomizedError) {
		String errorVal = config().getString(CustomizedError);
		String[] error = errorVal.split(":");
		String code = error[0];
		String message = error[1];
		cardsSCAService.get().verifyErrorResponseStatusCode(response.get(), CustomizedError);
		cardsSCAService.get().verifyValidationViolationErrorResponse(response.get(), code, message);

	}

	@When("I request  for retriving channel USer details API without $Header by $CreditcardNumber")
	public void WithoutcreditcardMandatoryHeader(String Header, String CreditcardNumber) {
		//Setting mandatory header values as null
		String correlationID = "RANDOM";
		String xBoiplatform = "X-BOI-PLATFORM";
		if (Header.equals("X-CORRELATION-ID")) {
			correlationID = "";
		} else if (Header.equals("X-BOI-PLATFORM")) {
			xBoiplatform = "";
		}
		RequestBuilder request = RestActions.onDefaultUri();
		endpoint.set(systemService.get().getCreditCardumberEndpoint());
		String[] inputHeaders = {correlationID, "", "", xBoiplatform};
		request = cardsSCAService.get().SetFSHeader(request, inputHeaders);
		request.body(payload.get());
		request.contentType("application/xml");
		response.set(cardsSCAService.get().executePost(request, endpoint.get()));

	}

	@Then("Service should return XSD validation $customizedError response with $tagName and $tagValue")
	public void verifyXSDErrorResponseCreditCard(String customizedError, String tagName, String tagValue ) {
		String errorMsg = config().getString(customizedError);
		String tagvalue1 = config().getString(tagValue);
		String[] error = errorMsg.split(":");
		String code = error[0];
		String message = error[1];
		cardsSCAService.get().verifyCorrrerlationID(response.get());
		cardsSCAService.get().verifyErrorResponseStatusCode(response.get(), customizedError);
		cardsSCAService.get().verifyXSDInvalid(response.get(),code,message,tagName,tagvalue1);
	}

	@Then("Service will be returning XSD validation for $CreditcardNumber and returns $customizedError response with $tagName and $tagValue")
	public void verifyXSDErrorResponseInvalidCreditCard(String CreditcardNumber ,String customizedError, String tagName, String tagValue ) {
		String errorMsg = config().getString(customizedError);
		String[] error = errorMsg.split(":");
		String code = error[0];
		String message = error[1];
		cardsSCAService.get().verifyCorrrerlationID(response.get());
		cardsSCAService.get().verifyErrorResponseStatusCode(response.get(), customizedError);
		cardsSCAService.get().verifyXSDInvalid(response.get(),code,message,tagName,CreditcardNumber);
	}
	}