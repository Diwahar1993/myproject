package net.boigroup.cardsSca.steps;

import net.boigroup.bdd.framework.JsonUtils;
import net.boigroup.bdd.framework.LogUtil;
import net.boigroup.bdd.framework.Rest.HttpResponse;
import net.boigroup.bdd.framework.Rest.RequestBuilder;
import net.boigroup.bdd.framework.Rest.RestActions;
import net.boigroup.bdd.framework.StorySteps;
import net.boigroup.cardsSca.service.CardsSCAService;
import net.boigroup.cardsSca.service.MuleService;
import net.boigroup.cardsSca.service.ReadXML;
import net.boigroup.cardsSca.service.SystemService;
import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;

import static net.boigroup.bdd.framework.Asserts.assertThat;
import static net.boigroup.bdd.framework.ConfigLoader.config;

@StorySteps
public class BroadcomSystemAdapterSteps {
    ThreadLocal<CardsSCAService> cardsSCAService = new ThreadLocal<CardsSCAService>() {
        @Override
        public CardsSCAService initialValue() {
            return new CardsSCAService();
        }
    };
    ThreadLocal<MuleService> muleService = new ThreadLocal<MuleService>() {
        @Override
        public MuleService initialValue() {
            return new MuleService();
        }
    };
    ThreadLocal<SystemService> systemService = new ThreadLocal<SystemService>() {
        @Override
        public SystemService initialValue() {
            return new SystemService();
        }
    };
    ThreadLocal<ReadXML> xml = new ThreadLocal<ReadXML>() {
        @Override
        public ReadXML initialValue() {
            return new ReadXML();
        }
    };
    String actualTransactionId;
    String expectedTransactionId;
    private ThreadLocal<HttpResponse> response = new ThreadLocal<HttpResponse>();
    private ThreadLocal<String> endpoint = new ThreadLocal<>();
    private ThreadLocal<String> broadcomRequestPayload = new ThreadLocal<>();

    @Given("User has construct the request $payload to hit the service with the $status")
    public void constructRequestPayload(String payload, String status) {
        broadcomRequestPayload.set(ReadXML.readXlsWithSameTagName(payload, "filepath.broadcom.systemadapter.credit.excelData", "filepath.broadcom.systemadapter.credit.requestTemplate"));
        broadcomRequestPayload.set(xml.get().jsonFormat(broadcomRequestPayload.get()).replace("$-{pinAuthenticationStatus}", status));
        LogUtil.logAttachment("Request Payload is", broadcomRequestPayload.get());
    }

    @Given("User has request $payload with the $status to hit the service with $tagValueRemoved")
    public void getRequestPayloadWithoutMandatoryField(String payload, String status, String tagValueRemoved) {
        broadcomRequestPayload.set(ReadXML.readXlsWithSameTagName(payload, "filepath.broadcom.systemadapter.credit.excelData", "filepath.broadcom.systemadapter.credit.requestTemplate"));
        broadcomRequestPayload.set(xml.get().removeJsontagByTagName(broadcomRequestPayload.get(), tagValueRemoved));
        broadcomRequestPayload.set(xml.get().jsonFormat(broadcomRequestPayload.get()).replace("$-{pinAuthenticationStatus}", status));
        broadcomRequestPayload.set(broadcomRequestPayload.get());
        LogUtil.logAttachment("Request Payload is", broadcomRequestPayload.get());
    }

    @Given("User has request $payload with the $status to hit the broadcom Authentication system adapter service with $tagValueRemoved")
    public void getRequestPayloadWitMandatoryFieldRemoved(String payload, String status, String tagValueRemoved) {
        broadcomRequestPayload.set(ReadXML.readXlsWithSameTagName(payload, "filepath.broadcom.systemadapter.credit.excelData", "filepath.broadcom.systemadapter.credit.requestTemplate"));
        broadcomRequestPayload.set(xml.get().jsonFormat(broadcomRequestPayload.get()).replace("$-{pinAuthenticationStatus}", status));
        String valueToBeRemove = JsonUtils.getJsonValue(broadcomRequestPayload.get(), tagValueRemoved);
        broadcomRequestPayload.set(xml.get().removeJsonTagByValue(broadcomRequestPayload.get(), valueToBeRemove));
        broadcomRequestPayload.set(broadcomRequestPayload.get());
        LogUtil.logAttachment("Request Payload is", broadcomRequestPayload.get());
    }

    @Given("Broadcom system adapter API has technical $error")
    public void setErrorInService(String error) {
        cardsSCAService.get().setError(error);
    }

    @When("requesting the broadcom system adapter $service with given payload")
    public void requestBroadcomSystemAdapter(String service) {
        RequestBuilder request = RestActions.onHTTPUri(config().getString("experience.uri"));
        if (service.equalsIgnoreCase("credit")) {
            endpoint.set(systemService.get().getBroadcomSystemAdaterCreditEndpoint());
        } else if (service.equalsIgnoreCase("debit")) {
            endpoint.set(systemService.get().getBroadcomSystemAdaterDebitEndpoint());
        }
        request.body(broadcomRequestPayload.get());
        request.contentType("application/json");
        request = muleService.get().setMuleHeaders(request);
        response.set(cardsSCAService.get().executePost(request, endpoint.get()));
        LogUtil.logAttachment("Actual Response is ", response.get().getBody());
    }

    @When("requesting the broadcom system adapter $service without one or more mandatory headers $headersToAdd")
    public void requestBroadcomSystemAdapterWIthouMandateHeader(String service, String headersToAdd) {
        RequestBuilder request = RestActions.onHTTPUri(config().getString("experience.uri"));
        if (service.equalsIgnoreCase("credit")) {
            endpoint.set(systemService.get().getBroadcomSystemAdaterCreditEndpoint());
        } else if (service.equalsIgnoreCase("debit")) {
            endpoint.set(systemService.get().getBroadcomSystemAdaterDebitEndpoint());
        }
        request.body(broadcomRequestPayload.get());
        request.contentType("application/json");
        request = muleService.get().setMuleHeadersUnauthorize(request, headersToAdd);
        response.set(cardsSCAService.get().executePost(request, endpoint.get()));
        LogUtil.logAttachment("Actual Response is ", response.get().getBody());
    }

    @When("I request broadcom system adapter $service with unsupported media type")
    public void requestServiceWithSupprtedMediaType(String service) {
        RequestBuilder request = RestActions.onHTTPUri(config().getString("experience.uri"));
        if (service.equalsIgnoreCase("credit")) {
            endpoint.set(systemService.get().getBroadcomSystemAdaterCreditEndpoint());
        } else if (service.equalsIgnoreCase("debit")) {
            endpoint.set(systemService.get().getBroadcomSystemAdaterDebitEndpoint());
        }
        request.body(broadcomRequestPayload.get());
        request.contentType("application/xml");
        request = muleService.get().setMuleHeaders(request);
        response.set(cardsSCAService.get().executePost(request, endpoint.get()));
        LogUtil.logAttachment("Actual Response is ", response.get().getBody());
    }

    @When("I request broadcom system adapter $service with not acceptable type")
    public void requestServiceWithNotAcceptableType(String service) {
        RequestBuilder request = RestActions.onHTTPUri(config().getString("experience.uri"));
        if (service.equalsIgnoreCase("credit")) {
            endpoint.set(systemService.get().getBroadcomSystemAdaterCreditEndpoint());
        } else if (service.equalsIgnoreCase("debit")) {
            endpoint.set(systemService.get().getBroadcomSystemAdaterDebitEndpoint());
        }
        request.body(broadcomRequestPayload.get());
        request.header("Accept", "application/xml");
        request = muleService.get().setMuleHeaders(request);
        response.set(cardsSCAService.get().executePost(request, endpoint.get()));
        LogUtil.logAttachment("Actual Response is ", response.get().getBody());
    }

    @Then("Broadcom Authentication System Adapter service should return success response with valid transactionId")
    public void verifySuccessReponse() {
        cardsSCAService.get().verifySucessResponseStatusCode(response.get());
        muleService.get().muleVerifyCorrrerlationID(response.get());
        actualTransactionId = JsonUtils.getJsonValue(response.get().getBody(), "transaction/identifier/transactionId").trim();
        expectedTransactionId = JsonUtils.getJsonValue(broadcomRequestPayload.get(), "transaction/identifier/transactionId").trim();
        LogUtil.logAttachment("Expected TransactionId is", expectedTransactionId);
        LogUtil.logAttachment("Actual TransactionId is", actualTransactionId);
        assertThat("Unexpected response!", actualTransactionId.equalsIgnoreCase(expectedTransactionId));
    }

    @Then("Broadcom Authentication System Adapter service should return error response with $customizedError")
    public void verifyErrorResponse(String customizedError) {
        String ErrorCodemessage = config().getString(customizedError);
        String[] error = ErrorCodemessage.split(":");
        String api = error[0];
        String code = error[1];
        String type = error[2];
        String summary = error[3];
        String description = error[4];
        String errordetail = config().getString(description);
        LogUtil.log(errordetail);
        cardsSCAService.get().verifyErrorResponseStatusCode(response.get(), customizedError);
        muleService.get().muleVerifyCorrrerlationID(response.get());
        muleService.get().verifyMuleErrorMessagesAPI(response.get(), endpoint.get(), api, code, type, summary, errordetail);
    }
}