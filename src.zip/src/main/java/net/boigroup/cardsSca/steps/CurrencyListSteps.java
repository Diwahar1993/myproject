package net.boigroup.cardsSca.steps;

import net.boigroup.bdd.framework.LogUtil;
import net.boigroup.bdd.framework.Rest.HttpResponse;
import net.boigroup.bdd.framework.Rest.RequestBuilder;
import net.boigroup.bdd.framework.StorySteps;
import net.boigroup.cardsSca.dao.CardsSCADao;
import net.boigroup.cardsSca.service.CardsSCAService;
import net.boigroup.cardsSca.service.ReadXML;
import net.boigroup.cardsSca.service.SystemService;
import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import static net.boigroup.bdd.framework.Asserts.assertThat;
import static net.boigroup.bdd.framework.ConfigLoader.config;
import static net.boigroup.bdd.framework.Rest.matchers.HasStringInContent.hasStringInContent;

@StorySteps
public class CurrencyListSteps {

    private ThreadLocal<CardsSCAService> cardsSCAService = new ThreadLocal<CardsSCAService>() {
        @Override
        public CardsSCAService initialValue() {
            return new CardsSCAService();
        }
    };

    private ThreadLocal<CardsSCADao> cardsSCADao = new ThreadLocal<CardsSCADao>() {
        @Override
        public CardsSCADao initialValue() {
            return new CardsSCADao();
        }
    };

    private ThreadLocal<SystemService> systemService = new ThreadLocal<SystemService>(){
        @Override
        public SystemService initialValue() {
            return new SystemService();
        }
    };

    private ThreadLocal<ReadXML> readXML = new ThreadLocal<ReadXML>(){
        @Override
        public ReadXML initialValue() {
            return new ReadXML();
        }
    };

    ThreadLocal<String> expectedRequest= new ThreadLocal<>()  ;
    public ThreadLocal<HttpResponse> response = new ThreadLocal<HttpResponse>();
    ThreadLocal<String> endpoint= new ThreadLocal<>()  ;

    @Given("Verify the list of ISO Currency list in Country table with $QueryParam")
    public void verifyValidCurrencyList(String QueryParam) {
        cardsSCAService.get().setError(null);
        QueryParam=systemService.get().orderQueryParam(QueryParam);

        systemService.get().verifyValidCurrency(QueryParam);
    }

    @Given("Verify the list of ISO Currency list in Country table")
    public void verifyValidCurrencyListWithoutSort( ) {
        cardsSCAService.get().setError(null);
    }

    @Given("Get Currency List Service has technical $error")
    public void cisUserHasError(String error) {
        cardsSCAService.get().setError(error);
    }

    @When("Requesting the get currency list System API with $QueryParam")
    public void requestCurrencyList(String QueryParam) {
        RequestBuilder request = cardsSCAService.get().defaultRequest();
        endpoint.set(systemService.get().getCurrencyListEndpoint(QueryParam));
        request = cardsSCAService.get().setHeaders(request);
        request = request.contentType("application/xml");
        response.set(cardsSCAService.get().executeGet(request, endpoint.get()));

    }

    @When("Requesting the get currency list System API without Sort Param")
    public void requestCurrencyListWithoutSortParam() {
        RequestBuilder request = cardsSCAService.get().defaultRequest();
        endpoint.set(systemService.get().getCurrencyListEndpointWithoutSort());
        request = cardsSCAService.get().setHeaders(request);
        request = request.contentType("application/xml");
        response.set(cardsSCAService.get().executeGet(request, endpoint.get()));

    }
    @When("I request Get Currency List API with $QueryParam without one or more mandatory headers $headersToAdd")
    public void withoutMandatoryHeader(String QueryParam,String headersToAdd) {
        RequestBuilder request = cardsSCAService.get().defaultRequest();
        endpoint.set(systemService.get().getCurrencyListEndpoint(QueryParam));
        request = cardsSCAService.get().setHeadersBadUnauthorize(request, headersToAdd);
        response.set(cardsSCAService.get().executeGet(request, endpoint.get()));
    }

    @Then("It should return the suceess response with list of Currency details for $QueryParam")
    public void verifySuccessResponse(String QueryParam) {
        cardsSCAService.get().verifySucessResponseStatusCode(response.get());
        cardsSCAService.get().verifyCorrrerlationID(response.get());
        QueryParam=systemService.get().orderQueryParam(QueryParam);
        systemService.get().verifyExpectedSuccessResponse(response.get(),QueryParam);
    }
    @Then("It should return the suceess response with list of Currency details")
    public void ithoutSort( ) {
        cardsSCAService.get().verifySucessResponseStatusCode(response.get());
        cardsSCAService.get().verifyCorrrerlationID(response.get());
        }

    @Then("It should return the $customizedError response for Get Currecny List")
    public void verifyErrorResponseGetCurrecny(String customizedError) {
        String errorMsg = config().getString(customizedError);
        String[] error = errorMsg.split(":");
        String code = error[0];
        String message = error[1];
        cardsSCAService.get().verifyCorrrerlationID(response.get());
        cardsSCAService.get().verifyErrorResponseStatusCode(response.get(), customizedError);
        cardsSCAService.get().verifyValidationViolationErrorResponse(response.get(),code,message);
    }

    @Then("It should return the $customizedError response without correlationID for Get Currecny List")
    public void errorWithoutCorrelationId(String customizedError) {
        String errorMsg = config().getString(customizedError);
        String[] error = errorMsg.split(":");
        String code = error[0];
        String message = error[1];
        cardsSCAService.get().verifyErrorResponseStatusCode(response.get(), customizedError);
        cardsSCAService.get().verifyValidationViolationErrorResponse(response.get(),code,message);
    }


}
