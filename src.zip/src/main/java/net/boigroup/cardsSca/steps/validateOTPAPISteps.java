package net.boigroup.cardsSca.steps;

import net.boigroup.bdd.framework.JsonUtils;
import net.boigroup.bdd.framework.LogUtil;
import net.boigroup.bdd.framework.Rest.HttpResponse;
import net.boigroup.bdd.framework.Rest.RequestBuilder;
import net.boigroup.bdd.framework.Rest.RestActions;
import net.boigroup.bdd.framework.StorySteps;
import net.boigroup.bdd.framework.XMLUtils;
import net.boigroup.cardsSca.service.CardsSCAService;
import net.boigroup.cardsSca.service.MuleService;
import net.boigroup.cardsSca.service.ReadXML;
import net.boigroup.cardsSca.service.SystemService;
import org.jbehave.core.annotations.*;
import sun.rmi.runtime.Log;

import java.time.Instant;

import static net.boigroup.bdd.framework.Asserts.assertThat;
import static net.boigroup.bdd.framework.ConfigLoader.config;

@StorySteps
public class validateOTPAPISteps {
    ReadXML readXML = new ReadXML();

    ThreadLocal<ReadXML> xml = new ThreadLocal<ReadXML>() {
        @Override
        public ReadXML initialValue() {
            return new ReadXML();
        }
    };
    XMLUtils xmlUtils = new XMLUtils();
    ThreadLocal<SystemService> systemService = new ThreadLocal<SystemService>() {
        @Override
        public SystemService initialValue() {
            return new SystemService();
        }
    };
    private ThreadLocal<String> endpoint = new ThreadLocal<>();
    ThreadLocal<MuleService> muleService = new ThreadLocal<MuleService>() {
        @Override
        public MuleService initialValue() {
            return new MuleService();
        }
    };
    private ThreadLocal<HttpResponse> response = new ThreadLocal<>();
    private ThreadLocal<HttpResponse> validateOTPresponse = new ThreadLocal<>();
    private ThreadLocal<HttpResponse> validateChallengeResponseCode = new ThreadLocal<>();
    private ThreadLocal<HttpResponse> generateJWSresponse=new ThreadLocal<>();
    private ThreadLocal<CardsSCAService> cardsSCAService = new ThreadLocal<CardsSCAService>() {
        @Override
        public CardsSCAService initialValue() {
            return new CardsSCAService();
        }
    };
    private ThreadLocal<String> validateOTPReqPayload = new ThreadLocal<>();
    private ThreadLocal<String> validateChallengeRequest = new ThreadLocal<>();
    private ThreadLocal<String> completionStatus = new ThreadLocal<>();
    private ThreadLocal<String> authResult = new ThreadLocal<>();
    private ThreadLocal<String> storedOtpChallenge = new ThreadLocal<>();
    private ThreadLocal<String> updatedotpChallenge = new ThreadLocal<>();
    private ThreadLocal<JsonUtils> json = new ThreadLocal<JsonUtils>() {
        @Override
        public JsonUtils initialValue() {
            return new JsonUtils();
        }
    };
    private ThreadLocal<String> generateJWSRequest = new ThreadLocal<>();
    private ThreadLocal<String> jwsReq = new ThreadLocal<>();
    private ThreadLocal<String> accessToken=new ThreadLocal<>();
    private ThreadLocal<String> accessTokenreqPayload=new ThreadLocal<>();


    @Given("store userId,deviceId and challengeCode from $pockInfo for $transactionId and $domainid")
    public void storePockInformationinCache(String pockInfo,String transactionId,String domainId) {
        String pockInfoReq="";
        pockInfoReq = ReadXML.readXlsWithSameTagName(pockInfo, "filepath.validateOTP.storedcacheInfo", "filepath.validateOTP.pockRequestTemplate");
        pockInfoReq = xml.get().jsonFormat(pockInfoReq);
        LogUtil.logAttachment("Pock_transactionId request payload is",pockInfoReq);
        RequestBuilder request = RestActions.onHTTPUri(config().getString("mule.caching.uri"));
        endpoint.set(systemService.get().getCachePOSTEndpoint().replace("{domain-id}",domainId));
        request = muleService.get().setMuleHeaders(request);
        request.body(pockInfoReq);
        request.contentType("application/json");
        response.set(cardsSCAService.get().executePut(request, endpoint.get()));
        String storedOtp=JsonUtils.getJsonValue(pockInfoReq, "value/challenge_code");
        LogUtil.log("Stored OTP challenge code is -->" + storedOtp);
        storedOtpChallenge.set(storedOtp);

    }
    @Given("store PAN,timestamp,status,merchant and transaction info from $bcReqInfo for $transactionId and $domainId with status as $status")
    public void storeBcReqInformationinCache(String bcReqInfo,String transactionId,String domainId ,String status) {
        LogUtil.log("domain Id is "+domainId);
        String bcReqInfoReq="";
        completionStatus.set(status);
        bcReqInfoReq = ReadXML.readXlsWithSameTagName(bcReqInfo, "filepath.validateOTP.storedcacheInfo", "filepath.validateOTP.bc_reqRequestTemplate").replace("{status}",status);
        bcReqInfoReq = xml.get().jsonFormat(bcReqInfoReq);
        LogUtil.logAttachment("bcReq_transactionId request payload is",bcReqInfoReq);
        RequestBuilder request = RestActions.onHTTPUri(config().getString("mule.caching.uri"));
        endpoint.set(systemService.get().getCachePOSTEndpoint().replace("{domain-id}",domainId));
        request = muleService.get().setMuleHeaders(request);
        request.body(bcReqInfoReq);
        request.contentType("application/json");
        response.set(cardsSCAService.get().executePut(request, endpoint.get()));


    }
    @Given("construct validate OTP  request payload for $transactionId")
    public void constructValidateOTPReq(String transactionId) {
        validateOTPReqPayload.set(ReadXML.readXlsWithSameTagName(transactionId, "filepath.validateOTP.ReqPayloadData", "filepath.validateOTP.validateOTPRequestTemplate"));
        validateOTPReqPayload.set(xml.get().jsonFormat(validateOTPReqPayload.get().toString()));
        LogUtil.logAttachment("bcReq_transactionId request payload is",validateOTPReqPayload.get().toString());


    }
    @When("I request validate OTP API to validate the challenge response code")
    public void ValidateOTPAPI() {
        RequestBuilder request = RestActions.onHTTPUri(config().getString("process.uri"));
        endpoint.set(systemService.get().getValidateOTPEndpoint());
        request = muleService.get().setMuleHeaders(request);
        request.body(validateOTPReqPayload.get());
        request.contentType("application/json");
        validateOTPresponse.set(cardsSCAService.get().executePost(request, endpoint.get()));
        LogUtil.logAttachment("Actual Response is" , validateOTPresponse.get().getBody());
        muleService.get().muleVerifyCorrrerlationID(validateOTPresponse.get());

    }
    @Then("Vaidate OTP API should validate the challenge responsecode with proper authentication $result for $transactionId")
    public void verifySuccessResponse(String result,String transactionId) {
        cardsSCAService.get().verifySucessResponseStatusCode(validateOTPresponse.get());
       String actualResponse=validateOTPresponse.get().getBody().toString();
       String transactionId_mule = JsonUtils.getJsonValue(actualResponse, "transaction/identifier/transactionId");
        LogUtil.log("transactionID returned in response is "+ transactionId_mule);
        String authResult_mule = JsonUtils.getJsonValue(actualResponse, "customer/digitalUserSession/authenticationResult");
        assertThat("incorrect transactionId!", transactionId_mule.equals(transactionId));
        assertThat("incorrect Authentication Result!", authResult_mule.equals(result));

    }
    @Then("caching entry object status has to be updated for $bcReqInfo and $domainId")
    public void verifyCacheGet(String key,String domainId) {
        RequestBuilder request = RestActions.onHTTPUri(config().getString("mule.caching.uri"));
        endpoint.set(systemService.get().getCacheGETEndpoint().replace("{key-id}", key).replace("{domain-id}",domainId));
        request = muleService.get().setMuleHeaders(request);
        response.set(cardsSCAService.get().executeGet(request, endpoint.get()));
        LogUtil.logAttachment("Actual Response is", response.get().getBody());
        //getting the stored completion status
        String beforeStatus = completionStatus.get();
        LogUtil.log("completion status before is -->" + beforeStatus);
        String getCacheResponse=response.get().getBody().toString();
        if(key.contains("bc_cust_auth_req_")) {
            String AfterStatus = JsonUtils.getJsonValue(getCacheResponse, "value/status");
            if (AfterStatus.equals("Complete")) {
                authResult.set("SUCCESS");
                LogUtil.log("completion status After is -->" + AfterStatus);
                assertThat("incorrect completion status!", AfterStatus.equals("Complete"));
            } else if (AfterStatus.equals("Failed")) {
                authResult.set("FAILED");
                LogUtil.log("completion status After is -->" + AfterStatus);
                assertThat("incorrect completion status!", AfterStatus.equals("Failed"));

            }
        }else if(key.contains("HTCC")){
            String updatedOtpChallenge=JsonUtils.getJsonValue(getCacheResponse, "value/challenge_code");
            LogUtil.log("Updated OTP challenge code is -->" + updatedOtpChallenge);
            updatedotpChallenge.set(updatedOtpChallenge);

        }


    }
    @Then("Validate OTP API should return the updated challenge response code in response")
    public void verifyUpdatedChallengeCode() {
       String actualResponse=validateOTPresponse.get().getBody().toString();
       String challengeCodeMule=JsonUtils.getJsonValue(actualResponse, "device/general/authenticationInputCode");
        LogUtil.log("challenge code returned in response --> " + challengeCodeMule);
        assertThat("incorrect challenge code!" + updatedotpChallenge.get() , challengeCodeMule.equals(updatedotpChallenge.get()));

    }
    //error
    @Given("validate OTP API has technical $error")
    public void setErrorInService(String error) {
        cardsSCAService.get().setError(error);
    }

    @Then("validate OTP API will return error response with $customizedError")
    public void verifyErrorResponse(String customizedError) {
        String ErrorCodemessage = config().getString(customizedError);
        String[] error = ErrorCodemessage.split(":");
        String api = error[0];
        String code = error[1];
        String type = error[2];
        String summary = error[3];
        String description = error[4];
        String errordetail = config().getString(description);
        LogUtil.log(errordetail);
        cardsSCAService.get().verifyErrorResponseStatusCode(validateOTPresponse.get(), customizedError);
        muleService.get().muleVerifyCorrrerlationID(validateOTPresponse.get());
        muleService.get().verifyMuleErrorMessagesAPI(validateOTPresponse.get(), endpoint.get(), api, code, type, summary, errordetail);
    }
    @When("I request validate OTP API without one or more mandatory headers $headersToAdd")
    public void withoutMandatoryHeader( String headersToAdd) {
        RequestBuilder request = RestActions.onHTTPUri(config().getString("process.uri"));
        endpoint.set(systemService.get().getValidateOTPEndpoint());
        request = muleService.get().setMuleHeadersUnauthorize(request, headersToAdd);
        request.body(validateOTPReqPayload.get());
        request.contentType("application/json");
        validateOTPresponse.set(cardsSCAService.get().executePost(request, endpoint.get()));
        LogUtil.logAttachment("Actual Response is ", validateOTPresponse.get().getBody());
    }

    //for mandatory tags
    @Given("construct  payload without mandatorytag $mandatoryTag")
    public void MandatoryTagMissing(String mandatorytag) {
        if(mandatorytag.equals("transactionId")){
            String requestPayload = json.get().readTextFileFromPath("validateOTPAPI", "missing_transactionIDTag.json");
            validateOTPReqPayload.set(requestPayload);
            LogUtil.logAttachment("request payload is",validateOTPReqPayload.get().toString());

        }else if (mandatorytag.equals("timestamp")){
            String requestPayload = json.get().readTextFileFromPath("validateOTPAPI", "missing_timestampTag.json");
            validateOTPReqPayload.set(requestPayload);
            LogUtil.logAttachment("request payload is",validateOTPReqPayload.get().toString());

        }else if(mandatorytag.equals("AuthCode")){
            String requestPayload = json.get().readTextFileFromPath("validateOTPAPI", "missing_AuthenticationCodeTag.json");
            validateOTPReqPayload.set(requestPayload);
            LogUtil.logAttachment("request payload is",validateOTPReqPayload.get().toString());

        }


    }





//////// Validate Challenge Response Code Steps //////////////


    @Given("construct validate challenge response code request payload for $transactionId")
    public void constructValidateChallengeRequest(String transactionId) {
        validateChallengeRequest.set(ReadXML.readXlsWithSameTagName(transactionId, "filepath.validateOTP.ReqPayloadData", "filepath.validateOTP.validateChallengeRequestTemplate"));
        validateChallengeRequest.set(xml.get().jsonFormat(validateChallengeRequest.get().toString()));
        LogUtil.logAttachment("Challenge response code request payload is",validateChallengeRequest.get().toString());


    }
    //generate JWS call
    @Given("generate $detachedStatus JWS for the given request payload for client $client")
    public void generateJWS(String status ,String client) {
        String detachedStatus="False";
        String kid="";
        String privateKey="";
        if(status.equals("detached")){
            detachedStatus="True";
        }
        if(client.equals("credit")){
            kid=config().getString("Credit_key_Id");
            privateKey=config().getString("Credit_privateKey");
        }else if (client.equals("debit")){
            kid=config().getString("Debit_key_Id");
            privateKey=config().getString("Debit_privateKey");
        }
        String jwsValueForReq=cardsSCAService.get().jwsGeneration(validateChallengeRequest.get().toString(),kid,privateKey,detachedStatus);
        jwsReq.set(jwsValueForReq);
        LogUtil.log("\n"+jwsValueForReq);
        muleService.get().setJWS(jwsValueForReq);

        ///request and jws
        LogUtil.log("payload used is ********** \n"+validateChallengeRequest.get());
        LogUtil.log("jws is "+status);
        LogUtil.log("jws used for input is ******** \n"+jwsReq.get());

    }
    //verify jws in response
    @Then("jws returned in response should be verified successfully")
    public void verifyJWSResponse() {
        String responseJws=cardsSCAService.get().getJWS(validateChallengeResponseCode.get());
        LogUtil.log("jws returned in response is \n"+responseJws);
        cardsSCAService.get().jwsVerification(responseJws,validateChallengeResponseCode.get().getBody());


    }
    //Access Token Generation
    @Given ("generate access token for valdiate challenge with valid $clientId and $client_assertion")
    public void generateAceessToken(String clientId,String client_assertion){
        clientId =config().getString(clientId);
        client_assertion =config().getString(client_assertion);
        RequestBuilder request = RestActions.onHTTPUri(config().getString("experience.uri"));
        endpoint.set(systemService.get().getAccessTokenGenerationExpAPIEndpoint());
        request= muleService.get().setAccessTokenRequest(request,clientId,client_assertion);
        request.contentType("application/x-www-form-urlencoded");
        request = muleService.get().setExperienceAPIAuthHeaders(request,clientId);
        response.set(cardsSCAService.get().executePost(request, endpoint.get()));
        LogUtil.logAttachment("Actual Response is ", response.get().getBody());
        String accesstoken = JsonUtils.getJsonValue(response.get().getBody(), "access_token");
        LogUtil.log("access token is "+accesstoken);
        accessToken.set("Bearer"+" "+accesstoken);
        muleService.get().setClientAssertion(accessToken.get());
        muleService.get().setClientId(clientId);

    }
    @When("I request validate challenge response code API to validate the challenge response code with $clientId")
    public void ValidateChallengeResponseCodeAPI(String clientId) {
        clientId =config().getString(clientId);
        LogUtil.logAttachment("jws is ",jwsReq.get());
        RequestBuilder request = RestActions.onHTTPUri(config().getString("experience.uri"));
        endpoint.set(systemService.get().getValidateChallengeEndpoint());
        request = muleService.get().setExperienceAPIAuthHeaders(request,clientId,accessToken.get(),jwsReq.get());
        request.body(validateChallengeRequest.get());
        request.contentType("application/json");
        validateChallengeResponseCode.set(cardsSCAService.get().executePost(request, endpoint.get()));
        LogUtil.logAttachment("Actual Response is" , validateChallengeResponseCode.get().getBody());
        //muleService.get().muleVerifyCorrrerlationID(validateChallengeResponseCode.get());


    }
    @When("I request validate challenge response code API with invalid jws $jws to validate the challenge response code")
    public void InvalidJWSValidateChallengeResponseCodeAPI(String jws) {
        LogUtil.logAttachment("jws is ",jwsReq.get());
        RequestBuilder request = RestActions.onHTTPUri(config().getString("experience.uri"));
        endpoint.set(systemService.get().getValidateChallengeEndpoint());
        request = muleService.get().setExperienceAPIAuthHeaders(request,"123456","",jws);
        request.body(validateChallengeRequest.get());
        request.contentType("application/json");
        validateChallengeResponseCode.set(cardsSCAService.get().executePost(request, endpoint.get()));
        LogUtil.logAttachment("Actual Response is" , validateChallengeResponseCode.get().getBody());
        //muleService.get().muleVerifyCorrrerlationID(validateChallengeResponseCode.get());


    }
    @Then("Vaidate Challenge Response Code API should validate the challenge responsecode with proper authentication $result for $transactionId")
    public void verifyChallengeSuccessResponse(String result,String transactionId) {
        cardsSCAService.get().verifySucessResponseStatusCode(validateChallengeResponseCode.get());
        String actualResponse=validateChallengeResponseCode.get().getBody().toString();
        String transactionId_mule = JsonUtils.getJsonValue(actualResponse, "transaction/identifier/transactionId");
        LogUtil.log("transactionID returned in response is "+ transactionId_mule);
        String authResult_mule = JsonUtils.getJsonValue(actualResponse, "customer/digitalUserSession/authenticationResult");
        assertThat("incorrect transactionId!", transactionId_mule.equals(transactionId));
        assertThat("incorrect Authentication Result!", authResult_mule.equals(result));

    }

    @When("I request validate Response Code API without one or more mandatory headers $headersToAdd")
    public void withoutExperienceMandatoryHeader( String headersToAdd) {
        RequestBuilder request = RestActions.onHTTPUri(config().getString("experience.uri"));
        endpoint.set(systemService.get().getValidateChallengeEndpoint());
        request = muleService.get().setMuleHeadersUnauthorize(request, headersToAdd);
        request.body(validateChallengeRequest.get());
        request.contentType("application/json");
        validateChallengeResponseCode.set(cardsSCAService.get().executePost(request, endpoint.get()));
        LogUtil.logAttachment("Actual Response is ", validateChallengeResponseCode.get().getBody());
    }

    @Then("Validate Experience API should return the updated challenge response code in response")
    public void verifyUpdatedChallengeResponseCode() {
        String actualResponse=validateChallengeResponseCode.get().getBody().toString();
        String challengeCodeMule=JsonUtils.getJsonValue(actualResponse, "device/general/authenticationInputCode");
        LogUtil.log("challenge code returned in response --> " + challengeCodeMule);
        assertThat("incorrect challenge code!" + updatedotpChallenge.get() , challengeCodeMule.equals(updatedotpChallenge.get()));

    }

    @Then("Experience Validate OTP API will return error response with $customizedError")
    public void verifyExpErrorResponse(String customizedError) {
        String ErrorCodemessage = config().getString(customizedError);
        String[] error = ErrorCodemessage.split(":");
        String api = error[0];
        String code = error[1];
        String type = error[2];
        String summary = error[3];
        String description = error[4];
        String errordetail = config().getString(description);
        LogUtil.log(errordetail);
        cardsSCAService.get().verifyErrorResponseStatusCode(validateChallengeResponseCode.get(), customizedError);
        //muleService.get().muleVerifyCorrrerlationID(validateChallengeResponseCode.get());
        muleService.get().verifyMuleErrorMessagesAPI(validateChallengeResponseCode.get(), endpoint.get(), api, code, type, summary, errordetail);
    }

    @Given("construct Exp API payload without mandatorytag $mandatoryTag")
    public void ExpMandatoryTagMissing(String mandatorytag) {
        if(mandatorytag.equals("transactionId")){
            String requestPayload = json.get().readTextFileFromPath("validateOTPAPI", "missing_transactionIDTag.json");
            validateChallengeRequest.set(requestPayload);
            LogUtil.logAttachment("request payload is",validateChallengeRequest.get().toString());

        }else if (mandatorytag.equals("timestamp")){
            String requestPayload = json.get().readTextFileFromPath("validateOTPAPI", "missing_timestampTag.json");
            validateChallengeRequest.set(requestPayload);
            LogUtil.logAttachment("request payload is",validateChallengeRequest.get().toString());

        }else if(mandatorytag.equals("AuthCode")){
            String requestPayload = json.get().readTextFileFromPath("validateOTPAPI", "missing_AuthenticationCodeTag.json");
            validateChallengeRequest.set(requestPayload);
            LogUtil.logAttachment("request payload is",validateChallengeRequest.get().toString());

        }}
    @Given("User Requesting the GenerateAccessTokenExperience API")
    public void constructRequestPayload() {
        cardsSCAService.get().setError(null);
        long IAT = Instant.now().getEpochSecond();
        LogUtil.log("current time in Unix "+IAT);
        String unixTime = Long.toString(IAT);
        String accessTokenPayload=json.get().readTextFileFromPath("AccessToken", "accessTokenPayloadTemp.txt").replace("{time}",unixTime);
        accessTokenreqPayload.set(accessTokenPayload);
        LogUtil.log("payload is "+accessTokenreqPayload.get());
        LogUtil.logAttachment("the accesstoken payload is ",accessTokenPayload);

    }
    @Given("generate jwt for $clientId with kid,payload and privatekey")
    public void generateJWS(String clientId) {
        LogUtil.log("client is "+clientId);
        String detachedStatus="False";
        String kid="";
        String privateKey="";
        if(clientId.equals("Broadcom_Credit_ClientId")){
            kid=config().getString("Credit_key_Id");
            privateKey=config().getString("Credit_privateKey");
        }else if (clientId.equals("Broadcom_Debit_ClientId")){
            kid=config().getString("Debit_key_Id");
            privateKey=config().getString("Debit_privateKey");
        }else if (clientId.equals("kidPrivateKeySwap")){
            kid=config().getString("Credit_key_Id");
            privateKey=config().getString("Debit_privateKey");
        }
        LogUtil.log("kid is "+kid);
        LogUtil.log("private key is "+privateKey);
        LogUtil.log("payload is "+accessTokenreqPayload.get().toString());
        String jwsValueForReq=cardsSCAService.get().jwsGeneration(accessTokenreqPayload.get().toString(),kid,privateKey,detachedStatus);
        jwsReq.set(jwsValueForReq);
        muleService.get().setJWS(jwsValueForReq);
        muleService.get().setClientAssertion(jwsValueForReq);
    }
    @Given("I request GenerateAccessTokenExperience API with valid $clientId and $client_assertion")
    public void requestTokenGenerationService(String clientId,String client_assertion) {
        clientId =config().getString(clientId);
        client_assertion =jwsReq.get();
        LogUtil.log(client_assertion);
        RequestBuilder request = RestActions.onHTTPUri(config().getString("experience.uri"));
        endpoint.set(systemService.get().getAccessTokenGenerationExpAPIEndpoint());
        LogUtil.log("************ header below*******");
        request= muleService.get().setAccessTokenRequest(request,clientId,client_assertion);
        request.contentType("application/x-www-form-urlencoded");
        request = muleService.get().setExperienceAPIAuthHeaders(request,clientId);
        response.set(cardsSCAService.get().executePost(request, endpoint.get()));
        LogUtil.logAttachment("Actual Response is ", response.get().getBody());
        LogUtil.logAttachment("Actual Response is ", response.get().getBody());
        String accesstoken = JsonUtils.getJsonValue(response.get().getBody(), "access_token");
        LogUtil.log("access token is "+accesstoken);
        accessToken.set("Bearer"+" "+accesstoken);
        muleService.get().setClientAssertion(accessToken.get());
        muleService.get().setClientId(clientId);
    }

}
