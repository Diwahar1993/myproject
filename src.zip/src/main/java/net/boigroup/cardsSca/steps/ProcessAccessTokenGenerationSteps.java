package net.boigroup.cardsSca.steps;

import net.boigroup.bdd.framework.JsonUtils;
import net.boigroup.bdd.framework.LogUtil;
import net.boigroup.bdd.framework.Rest.HttpResponse;
import net.boigroup.bdd.framework.Rest.RequestBuilder;
import net.boigroup.bdd.framework.Rest.RestActions;
import net.boigroup.bdd.framework.StorySteps;
import net.boigroup.bdd.framework.XMLUtils;
import net.boigroup.cardsSca.service.*;
import org.jbehave.core.annotations.Alias;
import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;

import java.time.Instant;

import static net.boigroup.bdd.framework.Asserts.assertThat;
import static net.boigroup.bdd.framework.ConfigLoader.config;


@StorySteps
public class ProcessAccessTokenGenerationSteps implements Constants {
    ThreadLocal<CardsSCAService> cardsSCAService = new ThreadLocal<CardsSCAService>() {
        @Override
        public CardsSCAService initialValue() {
            return new CardsSCAService();
        }
    };
    ThreadLocal<MuleService> muleService = new ThreadLocal<MuleService>() {
        @Override
        public MuleService initialValue() {
            return new MuleService();
        }
    };
    ThreadLocal<SystemService> systemService = new ThreadLocal<SystemService>() {
        @Override
        public SystemService initialValue() {
            return new SystemService();
        }
    };
    ThreadLocal<ReadXML> xml = new ThreadLocal<ReadXML>() {
        @Override
        public ReadXML initialValue() {
            return new ReadXML();
        }
    };
    ThreadLocal<JsonUtils> jsonUtils = new ThreadLocal<JsonUtils>() {
        @Override
        public JsonUtils initialValue() {
            return new JsonUtils();
        }
    };
    public ThreadLocal<HttpResponse> response = new ThreadLocal<HttpResponse>();
    private ThreadLocal<String> endpoint = new ThreadLocal<>();
    private ThreadLocal<String> requestPayload = new ThreadLocal<>();
    public ThreadLocal<String> responsePayload = new ThreadLocal<>();
    private ThreadLocal<String> accessTokenreqPayload = new ThreadLocal<>();
    private ThreadLocal<HttpResponse> generateJWSresponse=new ThreadLocal<>();
    XMLUtils xmlUtils = new XMLUtils();
    private ThreadLocal<JsonUtils> json = new ThreadLocal<JsonUtils>() {
        @Override
        public JsonUtils initialValue() {
            return new JsonUtils();
        }
    };
    private ThreadLocal<String> jwsReq = new ThreadLocal<>();

    @Given("User Requesting Process API Generate Access Token API for $clientId and $client_assertion")

    public void constructRequestPayloadGenerateAccessToken(String clientId, String client_assertion) {
        cardsSCAService.get().setError(null);
        clientId = config().getString(clientId);
        client_assertion = config().getString(client_assertion);
        requestPayload.set(jsonUtils.get().readTextFileFromPath("AccessTokenGenerationProcessAPI", "accessTokenGenerationProcessRequest.txt"));
        requestPayload.set(requestPayload.get().replace("$-{client_id}", clientId).replace("$-{client_assertion}", client_assertion));
        requestPayload.set(xml.get().jsonFormat(requestPayload.get()));
        LogUtil.logAttachment("Generate Access Token API", requestPayload.get());
    }

    @Given("User Requesting Process Generate Access Token API for $clientId and $client_assertion with $invalidTagValues")
    public void constructInvalidPaylaod(String clientId, String client_assertion, String invalidTagValues) {
        cardsSCAService.get().setError(null);
        clientId = config().getString(clientId);
        client_assertion = config().getString(client_assertion);
        requestPayload.set(jsonUtils.get().readTextFileFromPath("AccessTokenGenerationProcessAPI", "accessTokenGenerationProcessRequest.txt"));
        requestPayload.set(requestPayload.get().replace("$-{client_id}", clientId).replace("$-{client_assertion}", client_assertion));

        if (invalidTagValues.equalsIgnoreCase("grant_type")) {
            requestPayload.set(requestPayload.get().replace("client_credentials", INVALID_VALUES));

        }
        if (invalidTagValues.equalsIgnoreCase("scope")) {
            requestPayload.set(requestPayload.get().replace("cards_sca", INVALID_VALUES));
        }
        requestPayload.set(xml.get().jsonFormat(requestPayload.get()));
        LogUtil.logAttachment("Generate Access Token API", requestPayload.get());

    }

    @Given("User Requesting Process API Generate Access Token API without passing $tagValueRemoved parameters for $clientId and $client_assertion")

    public void requestPayloadGenerateAccessTokenWithoutMandatory(String tagValueRemoved, String clientId, String client_assertion) {
        cardsSCAService.get().setError(null);
        clientId = config().getString(clientId);
        client_assertion = config().getString(client_assertion);
        requestPayload.set(jsonUtils.get().readTextFileFromPath("AccessTokenGenerationProcessAPI", "accessTokenGenerationProcessRequest.txt"));
        requestPayload.set(requestPayload.get().replace("$-{client_id}", clientId).replace("$-{client_assertion}", client_assertion));
        requestPayload.set(xml.get().newRemoveJsontagByTagName1(requestPayload.get(), tagValueRemoved));
        requestPayload.set(xml.get().jsonFormat(requestPayload.get()));
        LogUtil.logAttachment("Generate Access Token API", requestPayload.get());
    }

    @Given("Generate Access Token Process API has technical $error")

    public void setErrorInService(String error) {
        cardsSCAService.get().setError(error);

    }

    @When("I request the Generate Access Token Process API with $clientId and $client_assertion")
    public void requestTokenGenerationService(String clientId,String client_assertion) {
        clientId =config().getString(clientId);
        client_assertion =jwsReq.get();
        RequestBuilder request = RestActions.onHTTPUri(config().getString("process.accessToken.uri"));
        request = muleService.get().setMuleHeaders(request);
        endpoint.set(systemService.get().getAccessTokenGenerationProcessAPIEndpoint());
        request= muleService.get().setAccessTokenRequest(request,clientId,client_assertion);
        response.set(cardsSCAService.get().executePost(request, endpoint.get()));
    }
    @When("I request the  Access Token process API with valid $clientId and $clientAssertion and $removeTags")
    public void requestTokenGenerationServicewithoutMandtory(String clientId,String clientAssertion,String removeTags ) {
        clientId =config().getString(clientId);
        clientAssertion =config().getString(clientAssertion);
        RequestBuilder request = RestActions.onHTTPUri(config().getString("process.accessToken.uri"));
        request = muleService.get().setMuleHeaders(request);
        endpoint.set(systemService.get().getAccessTokenGenerationProcessAPIEndpoint());
        request= muleService.get().setAccessTokenRequest(request,clientId,clientAssertion,removeTags);
        LogUtil.log("Request Passed :"+request.toString());
        request.contentType("application/x-www-form-urlencoded");
        response.set(cardsSCAService.get().executePost(request, endpoint.get()));
        LogUtil.logAttachment("Actual Response is ", response.get().getBody());
    }

    @When("I request the Generate Access Token Process API with Incorrect Method")
    public void requestTokenGenerationServiceinCorrectmethod() {
        RequestBuilder request = RestActions.onHTTPUri(config().getString("process.accessToken.uri"));
        request = muleService.get().setMuleHeaders(request);
        endpoint.set(systemService.get().getAccessTokenGenerationProcessAPIEndpoint());
        request.body(requestPayload.get());
        request.contentType("application/json");
        response.set(cardsSCAService.get().executePut(request, endpoint.get()));
    }

    @When("I request the Generate Access Token Process API with Incorrect ContentType")
    public void requestTokenGenerationServiceIncorrectContent() {
        RequestBuilder request = RestActions.onHTTPUri(config().getString("process.accessToken.uri"));
        request = muleService.get().setMuleHeaders(request);
        endpoint.set(systemService.get().getAccessTokenGenerationProcessAPIEndpoint());
        request.body(requestPayload.get());
        request.contentType("application/xml");
        response.set(cardsSCAService.get().executePost(request, endpoint.get()));
    }

    @When("I request the Generate Access Token Process API without one or more mandatory headers $headersToAdd with $clientId and $client_assertion")
    public void requestTokenGenerationServiceWithoutHeader(String headersToAdd,String clientId,String clientAssertion){
        clientId =config().getString(clientId);
        clientAssertion =config().getString(clientAssertion);
        RequestBuilder request = RestActions.onHTTPUri(config().getString("process.accessToken.uri"));
        request = muleService.get().setMuleHeadersUnauthorize(request, headersToAdd);
        endpoint.set(systemService.get().getAccessTokenGenerationProcessAPIEndpoint());
        request= muleService.get().setAccessTokenRequest(request,clientId,clientAssertion);
        request.contentType("application/x-www-form-urlencoded");
        response.set(cardsSCAService.get().executePost(request, endpoint.get()));
        LogUtil.logAttachment("Actual Response is ", response.get().getBody());
    }



    @Then("Process API Generate Access Token API should return success response with Valid access token")
    public void verifySuccessResponseprocessGenerateToken() {
        cardsSCAService.get().verifySucessResponseStatusCode(response.get());
        muleService.get().muleVerifyCorrrerlationID(response.get());
        String accessToken = JsonUtils.getJsonValue(response.get().getBody(), "access_token");
        LogUtil.log("AccessToken:" + accessToken);
        responsePayload.set(jsonUtils.get().readTextFileFromPath("AccessTokenGenerationProcessAPI", "accessTokenGenerationProcessResponse.txt"));
        responsePayload.set(responsePayload.get().replace("$-{access_token}", accessToken));
        String responseaccessToken = JsonUtils.getJsonValue(responsePayload.get(), "access_token");
        assertThat("Access Token Mismatched!", responseaccessToken.equals(accessToken));
    }

    @Then("Generate Access token Process API service should get error response with $customizedError")

    public void verifyProcessErrorResponseAccessToken(String customizedError) {
        String ErrorCodemessage = config().getString(customizedError);

        if (customizedError.endsWith("MethodNotAllowed")) {
            cardsSCAService.get().verifyErrorResponseStatusCode(response.get(), customizedError);
            muleService.get().muleVerifyCorrrerlationID(response.get());

        } else {
            cardsSCAService.get().verifyErrorResponseStatusCode(response.get(), customizedError);
            // String ErrorCodemessage = config().getString(customizedError);
            String[] error = ErrorCodemessage.split(":");
            String api = error[0];
            String code = error[1];
            String type = error[2];
            String summary = error[3];
            String description = error[4];
            String errordetail = config().getString(description);
            LogUtil.log(errordetail);
            cardsSCAService.get().verifyErrorResponseStatusCode(response.get(), customizedError);
            muleService.get().muleVerifyCorrrerlationID(response.get());
            muleService.get().verifyMuleErrorMessagesAPI(response.get(), endpoint.get(), api, code, type, summary, errordetail);

        }
    }
    @Given("User Requesting the Generate Access Token process API")
    public void constructRequestPayload() {
        cardsSCAService.get().setError(null);
        long IAT = Instant.now().getEpochSecond();
        LogUtil.log("current time in Unix "+IAT);
        String unixTime = Long.toString(IAT);
        String accessTokenPayload=json.get().readTextFileFromPath("AccessToken", "accessTokenPayloadTemp.txt").replace("{time}",unixTime);
        accessTokenreqPayload.set(accessTokenPayload);
        LogUtil.log("payload is "+accessTokenreqPayload.get());
        LogUtil.logAttachment("the accesstoken payload is ",accessTokenPayload);

    }
    @Given("generate clientassertion for $clientId with kid,payload and privatekey")
    public void generateJWS(String clientId) {
        LogUtil.log("client is "+clientId);
        String detachedStatus="False";
        String kid="";
        String privateKey="";
        if(clientId.equals("Broadcom_Credit_ClientId")){
            kid=config().getString("Credit_key_Id");
            privateKey=config().getString("Credit_privateKey");
        }else if (clientId.equals("Broadcom_Debit_ClientId")){
            kid=config().getString("Debit_key_Id");
            privateKey=config().getString("Debit_privateKey");
        }else if (clientId.equals("kidPrivateKeySwap")){
            kid=config().getString("Credit_key_Id");
            privateKey=config().getString("Debit_privateKey");
        }
        LogUtil.log("kid is "+kid);
        LogUtil.log("private key is "+privateKey);
        LogUtil.log("payload is "+accessTokenreqPayload.get().toString());
        String jwsRequest=json.get().readTextFileFromPath("JWS", "generateJWS.txt").replace("$-{requestPayload}",accessTokenreqPayload.get().toString()).replace("$-{detachedStatus}",detachedStatus).replace("$-{kid}",kid).replace("$-{privateKey}",privateKey);

        LogUtil.logAttachment("the generate JWS payload is ",jwsRequest);
        RequestBuilder request = RestActions.onHTTPUri(config().getString("AT.uri"));
        endpoint.set(systemService.get().getGenerateJWSEndpoint());
        request = cardsSCAService.get().setHeaders(request);
        LogUtil.log("the req body is .......\n"+jwsRequest);
        request.body(jwsRequest.replace("-----BEGIN PRIVATE KEY-----","-----BEGIN PRIVATE KEY-----\n").replace("-----END PRIVATE KEY-----","\n-----END PRIVATE KEY-----"));
        request.contentType("application/xml");
        generateJWSresponse.set(cardsSCAService.get().executePost(request, endpoint.get()));
        LogUtil.logAttachment("generate JWS response is ",generateJWSresponse.get().toString());
        String jwsValueForReq = xmlUtils.getTagValue(generateJWSresponse.get().getBody(), "jws", 0);
        jwsReq.set(jwsValueForReq);
        muleService.get().setJWS(jwsValueForReq);
        muleService.get().setClientAssertion(jwsValueForReq);
    }
}