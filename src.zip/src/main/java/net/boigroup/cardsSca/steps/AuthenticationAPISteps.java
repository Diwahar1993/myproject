package net.boigroup.cardsSca.steps;

import net.boigroup.bdd.framework.JsonUtils;
import net.boigroup.bdd.framework.LogUtil;
import net.boigroup.bdd.framework.Rest.HttpResponse;
import net.boigroup.bdd.framework.Rest.RequestBuilder;
import net.boigroup.bdd.framework.Rest.RestActions;
import net.boigroup.bdd.framework.StorySteps;
import net.boigroup.bdd.framework.XMLUtils;
import net.boigroup.cardsSca.dao.CardsSCADao;
import net.boigroup.cardsSca.service.CardsSCAService;
import net.boigroup.cardsSca.service.MuleService;
import net.boigroup.cardsSca.service.ReadXML;
import net.boigroup.cardsSca.service.SystemService;
import net.boigroup.cardsSca.domain.ExpectedResponseRow;
import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;

import java.util.List;
import java.util.Map;

import static net.boigroup.bdd.framework.Asserts.assertThat;
import static net.boigroup.bdd.framework.ConfigLoader.config;
@StorySteps
public class AuthenticationAPISteps {
    private ThreadLocal<ReadXML> readXML = new ThreadLocal<ReadXML>(){
        @Override
        public ReadXML initialValue() {
            return new ReadXML();
        }
    };
    CardsSCADao cardsSCADao = new CardsSCADao();
    ThreadLocal<ReadXML> xml = new ThreadLocal<ReadXML>() {
        @Override
        public ReadXML initialValue() {
            return new ReadXML();
        }
    };
    ThreadLocal<SystemService> systemService = new ThreadLocal<SystemService>() {
        @Override
        public SystemService initialValue() {
            return new SystemService();
        }
    };
    private ThreadLocal<String> endpoint = new ThreadLocal<>();
    private ThreadLocal<String> plaplId = new ThreadLocal<>();
    private ThreadLocal<String> dob = new ThreadLocal<>();
    private ThreadLocal<String> cisUserId = new ThreadLocal<>();
    private ThreadLocal<String> completionStatus = new ThreadLocal<>();
    private ThreadLocal<String> userCode = new ThreadLocal<>();
    ThreadLocal<MuleService> muleService = new ThreadLocal<MuleService>() {
        @Override
        public MuleService initialValue() {
            return new MuleService();
        }
    };
    private ThreadLocal<CardsSCAService> cardsSCAService = new ThreadLocal<CardsSCAService>() {
        @Override
        public CardsSCAService initialValue() {
            return new CardsSCAService();
        }
    };
    private ThreadLocal<HttpResponse> deleteCacheResponse = new ThreadLocal<>();
    private ThreadLocal<HttpResponse> createCacheResponse = new ThreadLocal<>();
    private ThreadLocal<HttpResponse> getCacheResponse = new ThreadLocal<>();
    private ThreadLocal<HttpResponse> userDetailsbyCCNoResponse = new ThreadLocal<>();
    private ThreadLocal<HttpResponse> userDetailsbyDebitNoResponse = new ThreadLocal<>();
    private ThreadLocal<HttpResponse> userDetailsbyCISUserIDResponse = new ThreadLocal<>();
    private ThreadLocal<HttpResponse> authenticationAPIresponse = new ThreadLocal<>();
    private ThreadLocal<HttpResponse> checkBinAPIResponse = new ThreadLocal<>();
    private ThreadLocal<HttpResponse> declickSystemAPIResponse = new ThreadLocal<>();
    private ThreadLocal<HttpResponse> plaplIDDobResponse = new ThreadLocal<>();
    private ThreadLocal<HttpResponse> dskresponse = new ThreadLocal<>();
    private ThreadLocal<String> authenticationRequestPayload = new ThreadLocal<>();
    private ThreadLocal<String> softTokenRequestPayload = new ThreadLocal<>();
    private ThreadLocal<String> challengeCode = new ThreadLocal<>();
    private ThreadLocal<JsonUtils> json = new ThreadLocal<JsonUtils>() {
        @Override
        public JsonUtils initialValue() {
            return new JsonUtils();
        }
    };
    XMLUtils xmlUtils = new XMLUtils();
    @Given("store  $bcReqInfo in cache for $transactionId and $domainId with status as $status")
    public void storeBcReqInformationinCache(String bcReqInfo,String transactionId,String domainId,String status) {
        String bcReqInfoReq="";
        completionStatus.set(status);
        bcReqInfoReq = ReadXML.readXlsWithSameTagName(bcReqInfo, "filepath.validateOTP.storedcacheInfo", "filepath.validateOTP.bc_reqRequestTemplate").replace("{status}",status);
        bcReqInfoReq = xml.get().jsonFormat(bcReqInfoReq);
        LogUtil.logAttachment("bcReq_transactionId request payload is",bcReqInfoReq);
        RequestBuilder request = RestActions.onHTTPUri(config().getString("mule.caching.uri"));
        endpoint.set(systemService.get().getCachePOSTEndpoint());
        request = muleService.get().setMuleHeaders(request);
        request.body(bcReqInfoReq);
        request.contentType("application/json");
        createCacheResponse.set(cardsSCAService.get().executePost(request, endpoint.get().replace("{domain-id}",domainId)));
        LogUtil.logAttachment("Actual Response is" , createCacheResponse.get().getBody());

    }

    @Given("checkBINAPI Indicator is $indicator for $cardNo")
    public void requestCheckBINAPI(String indicator,String cardNo) {
        String BIN=cardNo.substring(0,6);
        LogUtil.log("BIN no is "+BIN);
        RequestBuilder request = RestActions.onHTTPUri(config().getString("mule.system.uri"));
        endpoint.set(systemService.get().getCheckBINAPIEndpoint().replace("{bin-number}", BIN));
        request = muleService.get().setMuleHeaders(request);
        checkBinAPIResponse.set(cardsSCAService.get().executeGet(request, endpoint.get()));
        LogUtil.logAttachment("Actual Response is ", checkBinAPIResponse.get().getBody());
    }
    @Given("checkUserDetailsByCreditCard API returns $status for $cardNo")
    public void requestingCreditcardUserDetails(String status,String creditcardNumber) {
        String userDetailsByCCNopayload=systemService.get().get365CreditPayload(creditcardNumber);
        LogUtil.logAttachment("Expected Payload is ", userDetailsByCCNopayload);
        RequestBuilder request = RestActions.onDefaultUri();
        endpoint.set(systemService.get().getCreditCardumberEndpoint());
        request = cardsSCAService.get().setHeaders(request);
        request.body(userDetailsByCCNopayload);
        request.contentType("application/xml");
        userDetailsbyCCNoResponse.set(cardsSCAService.get().executePost(request, endpoint.get()));
        String customerId = xmlUtils.getTagValue(userDetailsbyCCNoResponse.get().getBody().toString(), "customerId", 0);
        LogUtil.log("customer Id extracted from userDetails by CreditCard is  "+customerId);
        userCode.set(customerId);
    }
    @Given("checkUserDetailsByDebitCard API returns $status for $cardNo")
    public void requestingDebitcardUserDetails(String status,String debitCardNo) {
        String inputPayload=readXML.get().readXML("CisUserDebitCardRequest","CisUserDebitCard");
        inputPayload=inputPayload.replace("$-{cardNumber}", debitCardNo);
        inputPayload= readXML.get().xmlFormat(inputPayload);
        RequestBuilder request = cardsSCAService.get().defaultRequest();
        endpoint.set(systemService.get().getCISUserWithDebitCardNo());
        String[] inputHeaders = {"RANDOM", "B365", "source_System", "userID"};
        request = cardsSCAService.get().SetFSHeader(request, inputHeaders);
        request.body(inputPayload);
        request = request.contentType("application/xml");
        LogUtil.logAttachment("Request Payload: ",inputPayload);
        userDetailsbyDebitNoResponse.set(cardsSCAService.get().executePost(request, endpoint.get()));
        String cisId = xmlUtils.getTagValue(userDetailsbyDebitNoResponse.get().getBody().toString(), "cisUserId", 0);
        LogUtil.log("cis UserID is "+cisId);
        cisUserId.set(cisId);
    }
    @Given("authenticateCISUser API returns $status for the extracted customerId")
    public void userDetailsByCISuser(String status) {
        RequestBuilder request = RestActions.onDefaultUri();
        endpoint.set(systemService.get().getCISUSERAuthEndpoint().replace("{CIS_USER_ID}", cisUserId.get()));
        String[] inputHeaders = {"RANDOM", "BOL", "source_System", "userID"};
        request = cardsSCAService.get().SetFSHeader(request, inputHeaders);
        userDetailsbyCISUserIDResponse.set(cardsSCAService.get().executeGet(request, endpoint.get()));
    }
    @Given("Declick System API returns $status for $cardNo")
    public void declickSystemAPI(String status,String creditCardNo) {
        String requestPayload = json.get().readTextFileFromPath("DeclickSystemAPI", "DeclickSystemAPIRequestTemplate.txt");
        requestPayload = requestPayload.replace("{cardnumber}", creditCardNo);
        requestPayload = json.get().jsonFormat(requestPayload);
        LogUtil.logAttachment("Request Payload is",requestPayload);
        RequestBuilder request = RestActions.onHTTPUri(config().getString("mule.customerProp.url"));
        endpoint.set(systemService.get().getDeclickSystemAPIEndpoint());
        request = muleService.get().setMuleHeaders(request);
        request.body(requestPayload);
        request.contentType("application/json");
        declickSystemAPIResponse.set(cardsSCAService.get().executePost(request, endpoint.get()));
        LogUtil.logAttachment("Actual Response is" , declickSystemAPIResponse.get().getBody());
        String mulePlaplID = JsonUtils.getJsonValue(declickSystemAPIResponse.get().getBody(), "creditCardAccount/identifier/plapplId");
        String muleDOB = JsonUtils.getJsonValue(declickSystemAPIResponse.get().getBody(), "person/general/dateOfBirth");
        plaplId.set(mulePlaplID);
        dob.set(muleDOB);
    }
    @Given("checkUserDetailsByPlaplID_DOB returns $status for $cardNo")
    public void requestingChannelUserDetailsbyPlapplID(String status, String cardNo) {
        String plaplIdDobPayload=readXML.get().xmlFormat(systemService.get().getPlapplIDRequestPayload(plaplId.get(), dob.get()));
        LogUtil.logAttachment("Expected Payload is ", plaplIdDobPayload);
        RequestBuilder request = RestActions.onDefaultUri();
        endpoint.set(systemService.get().getPlapplIDEndpoint());
        request = cardsSCAService.get().setHeaders(request);
        request.body(plaplIdDobPayload);
        request.contentType("application/xml");
        plaplIDDobResponse.set(cardsSCAService.get().executePost(request, endpoint.get()));
        String customerId = xmlUtils.getTagValue(plaplIDDobResponse.get().getBody().toString(), "customerId", 0);
        LogUtil.log("customer Id extacted from plaplId dob is "+customerId);
        userCode.set(customerId);
    }
    @Given("Construct authentication API request payload with necessary details for $cardNo and $transactionId")
    public void authenticationAPIReq(String cardNo ,String transactionId) {
        String requestPayload = json.get().readTextFileFromPath("AuthenticateAPI", "AuthenticateAPIRequest.json").replace("$-{cardNo}",cardNo).replace("$-{transactionId}",transactionId);
        requestPayload = xml.get().jsonFormat(requestPayload);
        authenticationRequestPayload.set(requestPayload);
        requestPayload = xml.get().jsonFormat(requestPayload);
        LogUtil.logAttachment(" authentication request payload is", authenticationRequestPayload.get().toString());
    }
    @Given("Construct authenticationAPI request payload with tag values for $cardNo,$transactionId,$currency and $amount")
    public void authenticationAPIReqIncorrectTagValues(String cardNo ,String transactionId,String currency,String amount) {
        String requestPayload = json.get().readTextFileFromPath("AuthenticateAPI", "AuthenticateAPIRequestTemplate.json").replace("{cardNo}",cardNo).replace("{transactionId}",transactionId).replace("{currency}",currency).replace("{amount}",amount);
        requestPayload = xml.get().jsonFormat(requestPayload);
        authenticationRequestPayload.set(requestPayload);
        requestPayload = xml.get().jsonFormat(requestPayload);
        LogUtil.logAttachment(" authentication request payload is", authenticationRequestPayload.get().toString());
    }
    @Given("Construct authentication API request payload without mandatory tag $tagValueRemoved for $cardNo and $transactionId")
    public void authenticationAPIReqWithoutMandatoryTag(String tagValueRemoved,String cardNo ,String transactionId) {
        LogUtil.log("Tag removed is  :"+tagValueRemoved);
        String requestPayload = json.get().readTextFileFromPath("AuthenticateAPI", "AuthenticateAPIRequest.json").replace("$-{cardNo}",cardNo).replace("$-{transactionId}",transactionId);
        requestPayload = xml.get().jsonFormat(requestPayload);
        requestPayload=readXML.get().newRemoveJsontagByTagName(requestPayload,tagValueRemoved);
        requestPayload = xml.get().jsonFormat(requestPayload);
        LogUtil.log("the updated payload is \n"+requestPayload);
        authenticationRequestPayload.set(requestPayload);
        LogUtil.logAttachment(" authentication request payload is", authenticationRequestPayload.get().toString());
    }

    @Given("dsk procss API returns $status for maskedpanNo $maskedpanNo,sourceClientId $sourceClientId,customerId $customerId and deviceId $deviceId")
    public void requestSoftTokenService(String status,String maskedPan,String sourceClientId,String customerId,String deviceId) {
        String requestPayload = json.get().readTextFileFromPath("AuthenticateAPI", "dskRequestPayload.json");
        requestPayload=requestPayload.replace("$-{maskedPan}",maskedPan)
                .replace("$-{sourceClientId}",sourceClientId)
                .replace("$-{customerId}",customerId)
                .replace("$-{deviceId}",deviceId);
        requestPayload = xml.get().jsonFormat(requestPayload);
        softTokenRequestPayload.set(requestPayload);
        LogUtil.logAttachment("dsk request payload is", softTokenRequestPayload.get().toString());


        RequestBuilder request = RestActions.onHTTPUri(config().getString("process.uri"));
        endpoint.set(systemService.get().getSoftTokenAuthenticationEndpoint());
        request.body(softTokenRequestPayload.get());
        request.contentType("application/json");
        request = muleService.get().setMuleHeaders(request);
        dskresponse.set(cardsSCAService.get().executePost(request, endpoint.get()));
        LogUtil.logAttachment("Actual Response is ", dskresponse.get().getBody());
    }

    @When("I request Authentication API to orchestrate the authentication request")
    public void authenticationAPI() {
        RequestBuilder request = RestActions.onHTTPUri(config().getString("process.uri"));
        endpoint.set(systemService.get().getAuthenticationEndpoint());
        request = muleService.get().setMuleHeaders(request);
        request.body(authenticationRequestPayload.get());
        request.contentType("application/json");
        authenticationAPIresponse.set(cardsSCAService.get().executePost(request, endpoint.get()));
        LogUtil.logAttachment("Actual Response is" , authenticationAPIresponse.get().getBody());
        try {
            String challenge = JsonUtils.getJsonValue(authenticationAPIresponse.get().getBody(), "device/general/authenticationInputCode");
            challengeCode.set(challenge);
        }catch(Exception e){
            LogUtil.log("user is not hardtoken registered (or) the user has no attempts remaining");
        }
    }
    @Then("I should get the Authentication API success response with following feilds:$examplesTable")
    public void thenIShouldGetTheSuccessResponseWithFollowingFeilds(List<ExpectedResponseRow> examplesTable){
        cardsSCAService.get().verifySucessResponseStatusCode(authenticationAPIresponse.get());
        String actualResponse=authenticationAPIresponse.get().getBody().toString();
        for (ExpectedResponseRow example :examplesTable) {
            if(!example.getName().equals(""))
                JsonUtils.verifyJsonValue(actualResponse,example.getValue(),example.getName());
        }

    }
    @Then("bc_Req cache status has to be updated as $status for $keyId and $clientId")
    public void bcreqCacheRetrive(String status,String keyId,String clientId){
        LogUtil.log("expected status is "+status);
        RequestBuilder request = RestActions.onHTTPUri(config().getString("mule.caching.uri"));
        endpoint.set(systemService.get().getCacheGETEndpoint().replace("{key-id}", keyId).replace("{domain-id}",clientId));
        request = muleService.get().setMuleHeaders(request);
        getCacheResponse.set(cardsSCAService.get().executeGet(request, endpoint.get()));
        LogUtil.logAttachment("Actual Response is", getCacheResponse.get().getBody());
        String actualStatus = JsonUtils.getJsonValue(getCacheResponse.get().getBody(), "value/status");
        assertThat("incorrect completion status!", actualStatus.equals(status));

    }
    @Then("Pock cache status has to be updated with new $challengeCode for $keyId and $clientId")
    public void POCKCacheRetrive(String challenge,String keyId,String clientId){
        RequestBuilder request = RestActions.onHTTPUri(config().getString("mule.caching.uri"));
        endpoint.set(systemService.get().getCacheGETEndpoint().replace("{key-id}", keyId).replace("{domain-id}",clientId));
        request = muleService.get().setMuleHeaders(request);
        getCacheResponse.set(cardsSCAService.get().executeGet(request, endpoint.get()));
        LogUtil.logAttachment("Actual Response is", getCacheResponse.get().getBody());
        String updatedKey = JsonUtils.getJsonValue(getCacheResponse.get().getBody(), "value/challenge_code");
        assertThat("incorrect Key!", updatedKey.equals(challengeCode.get()));

    }
    @Then("authentication process API should return error response with $customizedError")
    public void verifyErrorResponse(String customizedError) {
        String ErrorCodemessage = config().getString(customizedError);
        String[] error = ErrorCodemessage.split(":");
        String api = error[0];
        String code = error[1];
        String type = error[2];
        String summary = error[3];
        String description = error[4];
        String errordetail = config().getString(description);
        LogUtil.log(errordetail);
        cardsSCAService.get().verifyErrorResponseStatusCode(authenticationAPIresponse.get(), customizedError);
        muleService.get().muleVerifyCorrrerlationID(authenticationAPIresponse.get());
        muleService.get().verifyMuleErrorMessagesAPI(authenticationAPIresponse.get(), endpoint.get(), api, code, type, summary, errordetail);
    }
    @Given("Authentication API has technical $error")
    public void setErrorInService(String error) {
        cardsSCAService.get().setError(error);
    }

    @When("I request Authentication Process API without without one or more mandatory headers $headersToAdd")
    public void requestAuthenticationApiWithoutMandatoryHeader(String headersToAdd) {
        RequestBuilder request = RestActions.onHTTPUri(config().getString("process.uri"));
        endpoint.set(systemService.get().getAuthenticationEndpoint());
        request = muleService.get().setMuleHeadersUnauthorize(request, headersToAdd);
        request.body(authenticationRequestPayload.get());
        request.contentType("application/json");
        authenticationAPIresponse.set(cardsSCAService.get().executePost(request, endpoint.get()));
        LogUtil.logAttachment("Actual Response is" , authenticationAPIresponse.get().getBody());
    }

}
